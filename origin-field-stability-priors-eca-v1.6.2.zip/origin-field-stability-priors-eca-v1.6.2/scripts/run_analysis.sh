#!/usr/bin/env bash
set -euo pipefail
python src/ofst_eca_analysis.py "$@"
