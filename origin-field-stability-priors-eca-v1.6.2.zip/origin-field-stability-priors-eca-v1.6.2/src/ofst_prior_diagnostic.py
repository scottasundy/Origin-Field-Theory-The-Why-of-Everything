#!/usr/bin/env python3
"""Prior-only and prior-likelihood overlap diagnostics for v1.6.2."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ofst_physical_extension import (
    PhysicalExtensionConfig,
    add_likelihood,
    add_observable_predictions,
    add_stability_prior_components,
    make_candidate_grid,
)

TARGET_LAMBDA = 1.012
TARGET_G = 0.976


def _run_25x21(base_config: PhysicalExtensionConfig | None = None) -> pd.DataFrame:
    base = (base_config or PhysicalExtensionConfig()).validate()
    config = PhysicalExtensionConfig(
        **{
            **base.__dict__,
            "lambda_points": 25,
            "g_points": 21,
        }
    ).validate()
    candidates = make_candidate_grid(config)
    observable_df = add_observable_predictions(candidates, config)
    stability_df = add_stability_prior_components(observable_df, config)
    return add_likelihood(stability_df, config)


def _pivot(df: pd.DataFrame, value_col: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    table = df.pivot(index="g_ratio", columns="lambda_ratio", values=value_col).sort_index()
    return table.columns.to_numpy(dtype=float), table.index.to_numpy(dtype=float), table.to_numpy(dtype=float)


def save_prior_heatmap(df: pd.DataFrame, figures_dir: Path) -> None:
    figures_dir.mkdir(parents=True, exist_ok=True)
    x, y, z = _pivot(df, "prior_weight")
    fig, ax = plt.subplots(figsize=(8, 5.5))
    mesh = ax.pcolormesh(x, y, z, shading="auto")
    ax.set_xscale("log")
    ax.set_xlabel("Lambda / Lambda_obs")
    ax.set_ylabel("G / G_obs")
    ax.set_title("Stability-prior mass over the 25x21 Lambda/G grid")
    cbar = fig.colorbar(mesh, ax=ax)
    cbar.set_label("Prior weight")
    max_row = df.loc[int(df["prior_weight"].idxmax())]
    ax.scatter([float(max_row["lambda_ratio"])], [float(max_row["g_ratio"])], s=70, marker="x", label="prior peak")
    like_row = df.loc[int(df["relative_likelihood"].idxmax())]
    ax.scatter([float(like_row["lambda_ratio"])], [float(like_row["g_ratio"])], s=70, marker="o", facecolors="none", label="likelihood peak")
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(figures_dir / "prior_only_heatmap.png", dpi=180)
    plt.close(fig)


def _distance(a_lambda: float, a_g: float, b_lambda: float, b_g: float) -> float:
    return abs(math.log(a_lambda / b_lambda)) + abs(a_g - b_g)


def _driver_summary(row: pd.Series) -> str:
    components = {
        "curvature": (0.45, float(row["stability_curvature_score"])),
        "moderation": (0.35, float(row["stability_moderation_score"])),
        "expansion_regularity": (0.20, float(row["stability_expansion_regularity_score"])),
    }
    weighted = {name: weight * value for name, (weight, value) in components.items()}
    ordered = sorted(weighted.items(), key=lambda kv: kv[1], reverse=True)
    return ", ".join(f"{name}={value:.6g}" for name, value in ordered)


def build_prior_output(df: pd.DataFrame) -> pd.DataFrame:
    out = df[
        [
            "candidate_id",
            "lambda_ratio",
            "g_ratio",
            "stability_score",
            "stability_prior",
        ]
    ].copy()
    out = out.rename(columns={"stability_prior": "prior_weight"})
    return out


def analyze_overlap(df: pd.DataFrame) -> dict[str, object]:
    prior_peak = df.loc[int(df["stability_prior"].idxmax())]
    likelihood_peak = df.loc[int(df["relative_likelihood"].idxmax())]
    target_nearest = df.iloc[
        int(
            np.argmin(
                [
                    _distance(float(r.lambda_ratio), float(r.g_ratio), TARGET_LAMBDA, TARGET_G)
                    for r in df.itertuples(index=False)
                ]
            )
        )
    ]
    prior_like_distance = _distance(
        float(prior_peak["lambda_ratio"]),
        float(prior_peak["g_ratio"]),
        float(likelihood_peak["lambda_ratio"]),
        float(likelihood_peak["g_ratio"]),
    )
    target_prior_distance = _distance(
        float(prior_peak["lambda_ratio"]),
        float(prior_peak["g_ratio"]),
        TARGET_LAMBDA,
        TARGET_G,
    )
    target_like_distance = _distance(
        float(likelihood_peak["lambda_ratio"]),
        float(likelihood_peak["g_ratio"]),
        TARGET_LAMBDA,
        TARGET_G,
    )
    near_overlap = prior_like_distance <= 0.08
    prior_near_target = target_prior_distance <= 0.08
    likelihood_near_target = target_like_distance <= 0.08

    top_prior = df.sort_values("stability_prior", ascending=False).head(10)
    top_likelihood = df.sort_values("relative_likelihood", ascending=False).head(10)

    return {
        "grid": "25x21",
        "prior_peak": _row_summary(prior_peak),
        "likelihood_peak": _row_summary(likelihood_peak),
        "nearest_grid_point_to_lambda_1p012_g_0p976": _row_summary(target_nearest),
        "distance_prior_peak_to_likelihood_peak": prior_like_distance,
        "distance_prior_peak_to_target": target_prior_distance,
        "distance_likelihood_peak_to_target": target_like_distance,
        "prior_peak_overlaps_likelihood_peak_on_25x21": near_overlap,
        "prior_peak_near_lambda_1p012_g_0p976": prior_near_target,
        "likelihood_peak_near_lambda_1p012_g_0p976": likelihood_near_target,
        "prior_peak_component_drivers": _driver_summary(prior_peak),
        "likelihood_peak_component_drivers": _driver_summary(likelihood_peak),
        "top10_prior_candidates": [_row_summary(r) for _, r in top_prior.iterrows()],
        "top10_likelihood_candidates": [_row_summary(r) for _, r in top_likelihood.iterrows()],
    }


def _row_summary(row: pd.Series) -> dict[str, object]:
    return {
        "candidate_id": str(row["candidate_id"]),
        "lambda_ratio": float(row["lambda_ratio"]),
        "g_ratio": float(row["g_ratio"]),
        "omega_k_derived": float(row["omega_k_derived"]),
        "stability_score": float(row["stability_score"]),
        "prior_weight": float(row["stability_prior"]),
        "curvature_score": float(row["stability_curvature_score"]),
        "moderation_score": float(row["stability_moderation_score"]),
        "expansion_regularity_score": float(row["stability_expansion_regularity_score"]),
        "cmb_shift_R_pred": float(row["cmb_shift_R_pred"]),
        "cmb_shift_residual_sigma": float(row["cmb_shift_residual_sigma"]),
        "relative_likelihood": float(row["relative_likelihood"]),
        "likelihood_value": _safe_exp(float(row["log_likelihood"])),
    }


def _safe_exp(value: float) -> float:
    if not math.isfinite(value):
        return 0.0
    if value < -745.0:
        return 0.0
    return math.exp(value)


def write_overlap_note(summary: dict[str, object], docs_dir: Path) -> None:
    docs_dir.mkdir(parents=True, exist_ok=True)
    prior = summary["prior_peak"]
    like = summary["likelihood_peak"]
    target = summary["nearest_grid_point_to_lambda_1p012_g_0p976"]
    overlap_text = (
        "Yes, on the 25x21 grid the stability-prior peak is close to the likelihood peak."
        if summary["prior_peak_overlaps_likelihood_peak_on_25x21"]
        else "No. On the 25x21 grid the stability-prior peak and likelihood peak are separated."
    )
    target_text = (
        "The prior peak is near the lambda about 1.012, g about 0.976 region."
        if summary["prior_peak_near_lambda_1p012_g_0p976"]
        else "The prior peak is not at the lambda about 1.012, g about 0.976 region on the 25x21 grid."
    )

    lines = [
        "# Prior-Likelihood Overlap Note, v1.6.2",
        "",
        "This note isolates the stability prior from the data likelihood on the 25x21 Lambda/G grid and then compares the prior mass surface with the CMB shift-parameter likelihood surface.",
        "",
        "## Prior concentration",
        "",
        f"The stability prior peaks at candidate {prior['candidate_id']} with lambda={prior['lambda_ratio']:.12g}, g={prior['g_ratio']:.12g}, prior weight={prior['prior_weight']:.12g}, and stability score={prior['stability_score']:.12g}.",
        f"Its weighted component drivers are: {summary['prior_peak_component_drivers']}.",
        "",
        "The score used by the current physical extension is S_w = 0.45 curvature_score + 0.35 moderation_score + 0.20 expansion_regularity_score. The Gibbs prior is P_G proportional to exp(eta times [S_w - max(S_w)]), with eta=8 in the default run.",
        "",
        "The concentration therefore comes from the score construction itself: low absolute derived curvature, closeness to the observed constant ratios in log space, and smooth background expansion. It is not learned from the CMB datum.",
        "",
        "## Likelihood overlap",
        "",
        f"The likelihood peaks at candidate {like['candidate_id']} with lambda={like['lambda_ratio']:.12g}, g={like['g_ratio']:.12g}, relative likelihood={like['relative_likelihood']:.12g}, and residual={like['cmb_shift_residual_sigma']:.12g} sigma.",
        f"The nearest 25x21 grid point to lambda about 1.012, g about 0.976 is candidate {target['candidate_id']} with lambda={target['lambda_ratio']:.12g}, g={target['g_ratio']:.12g}, prior weight={target['prior_weight']:.12g}, and residual={target['cmb_shift_residual_sigma']:.12g} sigma.",
        "",
        overlap_text,
        target_text,
        "",
        "## Physical interpretation",
        "",
        "The overlap is only weakly physically motivated. The curvature and moderation terms favor candidates close to flat geometry and observed-scale constants, so some overlap with a CMB distance observable is expected. However, the exact prior peak is not derived from a cosmological Fisher matrix or from a physical theory of varying constants. It is a declared stability-score prior applied to Lambda/G space.",
        "",
        "That means the Bayes factor should be read as evidence for this score construction under this finite-grid approximation, not as independent evidence that the stability prior is a fundamental cosmological prior. The elevated BF mainly says that the current stability score places more prior mass near the compressed CMB shift-parameter ridge than the Jeffreys proxy does. It does not establish that the score is the true physical prior.",
    ]
    (docs_dir / "prior_likelihood_overlap_note.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def run(base_config: PhysicalExtensionConfig | None = None) -> dict[str, object]:
    config = (base_config or PhysicalExtensionConfig()).validate()
    results_dir = Path(config.results_dir)
    figures_dir = Path(config.figures_dir)
    docs_dir = Path("docs")
    results_dir.mkdir(parents=True, exist_ok=True)
    figures_dir.mkdir(parents=True, exist_ok=True)

    df = _run_25x21(config)
    prior_df = build_prior_output(df)
    prior_df.to_csv(results_dir / "prior_only_weights.csv", index=False)
    save_prior_heatmap(prior_df.merge(df.drop(columns=["stability_score", "stability_prior"], errors="ignore"), on=["candidate_id", "lambda_ratio", "g_ratio"], how="left"), figures_dir)

    summary = analyze_overlap(df)
    (results_dir / "prior_likelihood_overlap_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    write_overlap_note(summary, docs_dir)
    return summary


def main(argv: Iterable[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Run v1.6.2 prior-only and prior-likelihood overlap diagnostics.")
    parser.add_argument("--results-dir", default="results/physical_extension")
    parser.add_argument("--figures-dir", default="figures/physical_extension")
    parser.add_argument("--integration-steps", type=int, default=4096)
    parser.add_argument("--eta", type=float, default=8.0)
    args = parser.parse_args(list(argv) if argv is not None else None)
    config = PhysicalExtensionConfig(
        results_dir=args.results_dir,
        figures_dir=args.figures_dir,
        integration_steps=args.integration_steps,
        stability_eta=args.eta,
    )
    print(json.dumps(run(config), indent=2))


if __name__ == "__main__":
    main()
