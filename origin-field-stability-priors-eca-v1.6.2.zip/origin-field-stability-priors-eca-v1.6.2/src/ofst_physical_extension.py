#!/usr/bin/env python3
"""
Origin Field Stability Prior Physical Extension, v1.6.0.

This module adds rungs 5-8 of the evidence ladder without modifying the
existing ECA pipeline. It defines a finite candidate space over two
fundamental-constant ratios, maps each candidate to a CMB shift-parameter
prediction with analytical background-expansion approximations, evaluates a
finite-grid likelihood against a public Planck 2018 distance-prior datum, and
compares the stability prior with uniform, Jeffreys, and constrained
maximum-entropy baselines.

The calculation is a compressed, background-level demonstration. It is not a
Boltzmann-code analysis and it does not replace Planck likelihood chains.
"""

from __future__ import annotations

import argparse
import csv
import json
import math
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


@dataclass(frozen=True)
class PhysicalExtensionConfig:
    """Configuration for the rung 5-8 physical-extension pipeline."""

    lambda_min: float = 0.05
    lambda_max: float = 3.00
    lambda_points: int = 25
    g_min: float = 0.80
    g_max: float = 1.20
    g_points: int = 21
    omega_m_obs: float = 0.315
    omega_lambda_obs: float = 0.685
    omega_r_obs: float = 9.2e-5
    z_star: float = 1089.46
    cmb_shift_r_obs: float = 1.7429
    cmb_shift_r_sigma: float = 0.0051
    integration_steps: int = 4096
    stability_eta: float = 8.0
    curvature_score_scale: float = 0.25
    results_dir: str = "results/physical_extension"
    figures_dir: str = "figures/physical_extension"

    def validate(self) -> "PhysicalExtensionConfig":
        if self.lambda_min <= 0 or self.lambda_max <= self.lambda_min:
            raise ValueError("lambda bounds must be positive and ordered")
        if self.g_min <= 0 or self.g_max <= self.g_min:
            raise ValueError("G bounds must be positive and ordered")
        if self.lambda_points < 2 or self.g_points < 2:
            raise ValueError("each grid dimension must contain at least two points")
        if self.cmb_shift_r_sigma <= 0:
            raise ValueError("CMB shift-parameter sigma must be positive")
        if self.integration_steps < 256:
            raise ValueError("integration_steps is too small for the CMB integral")
        return self


def _normalise(weights: np.ndarray) -> np.ndarray:
    weights = np.asarray(weights, dtype=float)
    total = float(np.sum(weights))
    if not math.isfinite(total) or total <= 0:
        raise ValueError("cannot normalise nonpositive or nonfinite weights")
    return weights / total


def _logsumexp(log_values: np.ndarray) -> float:
    log_values = np.asarray(log_values, dtype=float)
    finite = log_values[np.isfinite(log_values)]
    if finite.size == 0:
        return -math.inf
    m = float(np.max(finite))
    return m + math.log(float(np.sum(np.exp(finite - m))))


def _cell_widths(values: np.ndarray, *, log_space: bool) -> np.ndarray:
    """Return endpoint-extended one-dimensional cell widths."""

    values = np.asarray(values, dtype=float)
    coordinates = np.log(values) if log_space else values
    edges = np.empty(coordinates.size + 1, dtype=float)
    edges[1:-1] = 0.5 * (coordinates[:-1] + coordinates[1:])
    edges[0] = coordinates[0] - 0.5 * (coordinates[1] - coordinates[0])
    edges[-1] = coordinates[-1] + 0.5 * (coordinates[-1] - coordinates[-2])
    return np.diff(edges)


def make_candidate_grid(config: PhysicalExtensionConfig) -> pd.DataFrame:
    """Rung 5: finite bounded grid over Lambda/Lambda_obs and G/G_obs."""

    lambda_values = np.geomspace(config.lambda_min, config.lambda_max, config.lambda_points)
    g_values = np.linspace(config.g_min, config.g_max, config.g_points)
    rows: list[dict[str, float | int | str | bool]] = []
    for lambda_index, lambda_ratio in enumerate(lambda_values):
        for g_index, g_ratio in enumerate(g_values):
            omega_k = 1.0 - g_ratio * (config.omega_m_obs + config.omega_r_obs) - lambda_ratio * config.omega_lambda_obs
            rows.append(
                {
                    "candidate_id": f"U{lambda_index:02d}_{g_index:02d}",
                    "lambda_index": lambda_index,
                    "g_index": g_index,
                    "lambda_ratio": float(lambda_ratio),
                    "g_ratio": float(g_ratio),
                    "omega_k_derived": float(omega_k),
                    "rung5_grid_admissible": True,
                    "rung5_notes": "finite bounded Lambda/G candidate grid; curvature derived by closure",
                }
            )
    return pd.DataFrame(rows)


def _background_arrays(config: PhysicalExtensionConfig) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    x = np.linspace(0.0, math.log1p(config.z_star), config.integration_steps)
    z = np.expm1(x)
    dz_dx = np.exp(x)
    return x, z, dz_dx


def _e2_of_z(z: np.ndarray, lambda_ratio: float, g_ratio: float, omega_k: float, config: PhysicalExtensionConfig) -> np.ndarray:
    one_plus_z = 1.0 + z
    return (
        g_ratio * config.omega_r_obs * one_plus_z**4
        + g_ratio * config.omega_m_obs * one_plus_z**3
        + omega_k * one_plus_z**2
        + lambda_ratio * config.omega_lambda_obs
    )


def _transverse_comoving_distance(chi: float, omega_k: float) -> tuple[float, float]:
    if omega_k > 1e-12:
        root = math.sqrt(omega_k)
        return math.sinh(root * chi) / root, float("nan")
    if omega_k < -1e-12:
        root = math.sqrt(-omega_k)
        argument = root * chi
        return math.sin(argument) / root, argument
    return chi, float("nan")


def add_observable_predictions(candidates: pd.DataFrame, config: PhysicalExtensionConfig) -> pd.DataFrame:
    """Rung 6: map candidates to a CMB shift-parameter prediction."""

    x, z, dz_dx = _background_arrays(config)
    rows: list[dict[str, float | str | bool]] = []
    for row in candidates.to_dict("records"):
        lambda_ratio = float(row["lambda_ratio"])
        g_ratio = float(row["g_ratio"])
        omega_k = float(row["omega_k_derived"])
        e2 = _e2_of_z(z, lambda_ratio, g_ratio, omega_k, config)
        positive_expansion = bool(np.all(np.isfinite(e2)) and np.min(e2) > 0.0)
        chi = float("nan")
        dm = float("nan")
        closed_argument = float("nan")
        r_pred = float("nan")
        observable_valid = False
        failure_reason = "none"
        expansion_irregularity = float("nan")
        if not positive_expansion:
            failure_reason = "nonpositive_E2_on_0_to_zstar"
        else:
            e = np.sqrt(e2)
            chi = float(np.trapezoid(dz_dx / e, x))
            dm, closed_argument = _transverse_comoving_distance(chi, omega_k)
            if not math.isfinite(dm) or dm <= 0.0:
                failure_reason = "nonpositive_transverse_distance"
            else:
                r_pred = math.sqrt(g_ratio * config.omega_m_obs) * dm
                observable_valid = bool(math.isfinite(r_pred) and r_pred > 0.0)
                if not observable_valid:
                    failure_reason = "nonfinite_shift_parameter"
            log_e = np.log(e)
            d1 = np.gradient(log_e, x)
            d2 = np.gradient(d1, x)
            expansion_irregularity = float(np.mean(np.abs(d2)))
        residual_sigma = (
            (r_pred - config.cmb_shift_r_obs) / config.cmb_shift_r_sigma
            if observable_valid
            else float("nan")
        )
        merged = dict(row)
        merged.update(
            {
                "rung6_observable": "Planck2018_CMB_shift_parameter_R_nonflat_distance_prior",
                "z_star_used": config.z_star,
                "cmb_shift_R_pred": r_pred,
                "cmb_shift_R_obs": config.cmb_shift_r_obs,
                "cmb_shift_R_sigma": config.cmb_shift_r_sigma,
                "cmb_shift_residual_sigma": residual_sigma,
                "chi_dimensionless": chi,
                "transverse_distance_dimensionless": dm,
                "closed_geometry_argument": closed_argument,
                "positive_expansion_history": positive_expansion,
                "observable_valid": observable_valid,
                "observable_failure_reason": failure_reason,
                "expansion_irregularity": expansion_irregularity,
            }
        )
        rows.append(merged)
    return pd.DataFrame(rows)


def add_stability_prior_components(observable_df: pd.DataFrame, config: PhysicalExtensionConfig) -> pd.DataFrame:
    """Construct the physical-grid stability prior without using the data residual."""

    df = observable_df.copy()
    valid = df["observable_valid"].astype(bool).to_numpy()
    irregularity = df["expansion_irregularity"].to_numpy(dtype=float)
    regularity_scale = float(np.nanmedian(irregularity[valid])) if np.any(valid) else 1.0
    if not math.isfinite(regularity_scale) or regularity_scale <= 0:
        regularity_scale = 1.0

    lambda_sigma = (math.log(config.lambda_max) - math.log(config.lambda_min)) / 4.0
    g_sigma = (math.log(config.g_max) - math.log(config.g_min)) / 4.0

    lambda_ratio = df["lambda_ratio"].to_numpy(dtype=float)
    g_ratio = df["g_ratio"].to_numpy(dtype=float)
    omega_k = df["omega_k_derived"].to_numpy(dtype=float)

    curvature_score = np.exp(-np.abs(omega_k) / config.curvature_score_scale)
    moderation_score = np.exp(
        -0.5 * ((np.log(lambda_ratio) / lambda_sigma) ** 2 + (np.log(g_ratio) / g_sigma) ** 2)
    )
    expansion_regularity_score = np.exp(-irregularity / regularity_scale)

    curvature_score[~valid] = 0.0
    moderation_score[~valid] = 0.0
    expansion_regularity_score[~valid] = 0.0

    stability_score = 0.45 * curvature_score + 0.35 * moderation_score + 0.20 * expansion_regularity_score
    stability_score[~valid] = -np.inf
    shifted = stability_score - np.nanmax(stability_score[np.isfinite(stability_score)])
    raw_prior = np.where(valid, np.exp(config.stability_eta * shifted), 0.0)
    stability_prior = _normalise(raw_prior)

    df["stability_curvature_score"] = curvature_score
    df["stability_moderation_score"] = moderation_score
    df["stability_expansion_regularity_score"] = expansion_regularity_score
    df["stability_score"] = stability_score
    df["stability_eta"] = config.stability_eta
    df["stability_prior"] = stability_prior
    df["stability_prior_notes"] = (
        "pre-data Gibbs prior over physical candidates; components are curvature moderation, "
        "parameter moderation, and background-expansion regularity"
    )
    return df


def add_likelihood(stability_df: pd.DataFrame, config: PhysicalExtensionConfig) -> pd.DataFrame:
    """Rung 7: finite-grid likelihood against the CMB shift-parameter datum."""

    df = stability_df.copy()
    valid = df["observable_valid"].astype(bool).to_numpy()
    residual = df["cmb_shift_residual_sigma"].to_numpy(dtype=float)
    chi2 = np.where(valid, residual**2, np.inf)
    log_likelihood = np.where(valid, -0.5 * chi2, -np.inf)
    likelihood_relative = np.where(valid, np.exp(log_likelihood - np.nanmax(log_likelihood[valid])), 0.0)
    df["cmb_shift_chi2"] = chi2
    df["log_likelihood"] = log_likelihood
    df["relative_likelihood"] = likelihood_relative
    df["likelihood_notes"] = (
        "Gaussian grid likelihood using the Planck 2018 non-flat CMB shift-parameter distance prior; "
        "normalization constants cancel in Bayes-factor comparisons over priors"
    )
    return df


def baseline_priors(likelihood_df: pd.DataFrame, config: PhysicalExtensionConfig) -> dict[str, np.ndarray]:
    """Rung 8 baselines over the same finite candidate support."""

    df = likelihood_df
    valid = df["observable_valid"].astype(bool).to_numpy()
    lambda_ratio = df["lambda_ratio"].to_numpy(dtype=float)
    g_ratio = df["g_ratio"].to_numpy(dtype=float)

    uniform = _normalise(np.where(valid, 1.0, 0.0))
    jeffreys_scale_proxy = _normalise(np.where(valid, 1.0 / (lambda_ratio * g_ratio), 0.0))

    lambda_values = np.geomspace(config.lambda_min, config.lambda_max, config.lambda_points)
    g_values = np.linspace(config.g_min, config.g_max, config.g_points)
    lambda_cell_widths = _cell_widths(lambda_values, log_space=True)
    g_cell_widths = _cell_widths(g_values, log_space=True)
    maxent_log_cell = np.zeros(len(df), dtype=float)
    for idx, row in df.iterrows():
        if not bool(row["observable_valid"]):
            continue
        li = int(row["lambda_index"])
        gi = int(row["g_index"])
        maxent_log_cell[idx] = lambda_cell_widths[li] * g_cell_widths[gi]
    constrained_max_entropy_log = _normalise(maxent_log_cell)

    return {
        "stability": df["stability_prior"].to_numpy(dtype=float),
        "uniform": uniform,
        "jeffreys_scale_proxy": jeffreys_scale_proxy,
        "constrained_max_entropy_log": constrained_max_entropy_log,
    }


def evidence_table(likelihood_df: pd.DataFrame, priors: dict[str, np.ndarray]) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Compute evidences, Bayes factors, and posterior masses for each prior."""

    log_likelihood = likelihood_df["log_likelihood"].to_numpy(dtype=float)
    evidence_rows: list[dict[str, float | str]] = []
    posterior_columns: dict[str, np.ndarray] = {}
    for name, prior in priors.items():
        log_prior = np.full_like(prior, -np.inf, dtype=float)
        positive_prior = prior > 0.0
        log_prior[positive_prior] = np.log(prior[positive_prior])
        log_terms = log_prior + log_likelihood
        log_evidence = _logsumexp(log_terms)
        posterior = np.exp(log_terms - log_evidence) if math.isfinite(log_evidence) else np.zeros_like(prior)
        posterior_columns[f"posterior_{name}"] = posterior
        evidence_rows.append(
            {
                "prior_name": name,
                "log_evidence": log_evidence,
                "evidence": math.exp(log_evidence) if math.isfinite(log_evidence) else 0.0,
                "effective_prior_models_ipr": 1.0 / float(np.sum(prior**2)),
                "posterior_top_candidate": str(likelihood_df.iloc[int(np.argmax(posterior))]["candidate_id"]),
                "posterior_top_mass": float(np.max(posterior)),
            }
        )
    evidence_df = pd.DataFrame(evidence_rows)
    stability_logz = float(evidence_df.loc[evidence_df["prior_name"] == "stability", "log_evidence"].iloc[0])
    for idx, row in evidence_df.iterrows():
        logz = float(row["log_evidence"])
        evidence_df.loc[idx, "log_bayes_factor_vs_stability"] = logz - stability_logz
        evidence_df.loc[idx, "bayes_factor_vs_stability"] = math.exp(logz - stability_logz)
        evidence_df.loc[idx, "log_bayes_factor_stability_vs_prior"] = stability_logz - logz
        evidence_df.loc[idx, "bayes_factor_stability_vs_prior"] = math.exp(stability_logz - logz)
    posterior_df = likelihood_df.copy()
    for column, values in posterior_columns.items():
        posterior_df[column] = values
    return evidence_df, posterior_df


def _pivot(df: pd.DataFrame, value_col: str) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    table = df.pivot(index="g_ratio", columns="lambda_ratio", values=value_col).sort_index()
    x = table.columns.to_numpy(dtype=float)
    y = table.index.to_numpy(dtype=float)
    z = table.to_numpy(dtype=float)
    return x, y, z


def _save_heatmap(df: pd.DataFrame, value_col: str, title: str, cbar_label: str, path: Path) -> None:
    x, y, z = _pivot(df, value_col)
    fig, ax = plt.subplots(figsize=(8, 5.5))
    mesh = ax.pcolormesh(x, y, z, shading="auto")
    ax.set_xscale("log")
    ax.set_xlabel(r"$\Lambda/\Lambda_{obs}$")
    ax.set_ylabel(r"$G/G_{obs}$")
    ax.set_title(title)
    cbar = fig.colorbar(mesh, ax=ax)
    cbar.set_label(cbar_label)
    fig.tight_layout()
    fig.savefig(path, dpi=180)
    plt.close(fig)


def make_figures(full_df: pd.DataFrame, evidence_df: pd.DataFrame, figures_dir: Path) -> None:
    figures_dir.mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(8, 5.5))
    valid = full_df["observable_valid"].astype(bool)
    ax.scatter(full_df.loc[valid, "lambda_ratio"], full_df.loc[valid, "g_ratio"], s=24, label="observable-valid")
    ax.scatter(full_df.loc[~valid, "lambda_ratio"], full_df.loc[~valid, "g_ratio"], s=24, marker="x", label="invalid observable")
    ax.set_xscale("log")
    ax.set_xlabel(r"$\Lambda/\Lambda_{obs}$")
    ax.set_ylabel(r"$G/G_{obs}$")
    ax.set_title("Rung 5 finite physical candidate grid")
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(figures_dir / "rung5_candidate_grid.png", dpi=180)
    plt.close(fig)

    _save_heatmap(
        full_df,
        "cmb_shift_R_pred",
        "Rung 6 CMB shift-parameter observable map",
        r"Predicted $R$",
        figures_dir / "rung6_cmb_shift_observable_map.png",
    )

    chi_df = full_df.copy()
    chi_df["cmb_shift_chi2_capped"] = np.minimum(chi_df["cmb_shift_chi2"].replace(np.inf, np.nan), 100.0)
    _save_heatmap(
        chi_df,
        "cmb_shift_chi2_capped",
        "Rung 7 grid likelihood diagnostic",
        r"$\chi^2$ capped at 100",
        figures_dir / "rung7_likelihood_chi2_heatmap.png",
    )

    fig, ax = plt.subplots(figsize=(8, 5.5))
    plot_df = evidence_df[evidence_df["prior_name"] != "stability"].copy()
    ax.bar(plot_df["prior_name"], plot_df["bayes_factor_stability_vs_prior"])
    ax.set_yscale("log")
    ax.set_ylabel("Bayes factor: stability prior / baseline")
    ax.set_title("Rung 8 evidence comparison")
    ax.tick_params(axis="x", rotation=20)
    fig.tight_layout()
    fig.savefig(figures_dir / "rung8_bayes_factor_comparison.png", dpi=180)
    plt.close(fig)


def write_notes(config: PhysicalExtensionConfig, results_dir: Path) -> None:
    text = f"""# Physical extension notes, v1.6.0

This extension adds rungs 5-8 without modifying the existing ECA pipeline.

## Rung 5 candidate space

The candidate space is the finite bounded grid U_i = (Lambda/Lambda_obs, G/G_obs), with Lambda/Lambda_obs in [{config.lambda_min}, {config.lambda_max}] over {config.lambda_points} log-spaced points and G/G_obs in [{config.g_min}, {config.g_max}] over {config.g_points} linearly spaced points. Curvature is derived by closure as omega_k = 1 - g(omega_m + omega_r) - lambda omega_Lambda.

## Rung 6 observable map

The observable is the CMB shift parameter R using a background-level FRW distance approximation. This is an analytical/semianalytical distance-prior calculation, not a full CMB simulation.

## Rung 7 dataset and likelihood

The likelihood uses the Planck 2018 non-flat CMB distance-prior shift parameter R = {config.cmb_shift_r_obs} +/- {config.cmb_shift_r_sigma} at z_star = {config.z_star}. The likelihood is a finite-grid Gaussian likelihood in R. This is a compressed public observational datum, not the raw Planck map likelihood or a Planck MCMC chain.

## Rung 8 baselines

Baselines are uniform model mass over valid finite candidates, a discrete scale-parameter Jeffreys proxy proportional to 1/(lambda g), and a constrained maximum-entropy baseline defined as uniform density over bounded log Lambda and log G support and discretized by log-cell area.

## Domain-expertise and data-change notes

A domain cosmologist would normally replace this module with a Boltzmann solver such as CAMB or CLASS, vary the full cosmological parameter vector, include nuisance parameters, and use the full Planck likelihood or public chains rather than a one-number distance prior.

The G-variation treatment here is background-level only. A real varying-G cosmology would alter recombination, perturbation growth, the sound horizon, and possibly BBN; those effects are intentionally not modeled here.

The stability prior is a declared pre-data physical-grid proxy. It is not derived from a known law of nature. It favors curvature moderation, parameter moderation around the observed nondimensional reference point, and smooth background expansion. Different stability definitions could materially change the evidence comparison.

The non-flat shift-parameter prior is used because the grid derives omega_k by closure. Using the flat value R = 1.7502 +/- 0.0046, using the full three-parameter CMB distance-prior covariance, or using full Planck likelihoods would change numerical Bayes factors.
"""
    (results_dir / "physical_extension_notes.md").write_text(text, encoding="utf-8")


def write_dataset_file(config: PhysicalExtensionConfig, results_dir: Path) -> None:
    rows = [
        {
            "dataset_name": "Planck2018_CMB_distance_prior_nonflat_shift_parameter",
            "observable": "R",
            "value": config.cmb_shift_r_obs,
            "sigma_68": config.cmb_shift_r_sigma,
            "z_star": config.z_star,
            "source_note": "Chen, Huang, and Wang distance priors derived from final Planck 2018 TT,TE,EE+lowE data; non-flat case used because omega_k is derived in this extension.",
        }
    ]
    pd.DataFrame(rows).to_csv(results_dir / "planck2018_distance_prior_dataset.csv", index=False)


def run(config: PhysicalExtensionConfig | None = None) -> dict[str, object]:
    config = (config or PhysicalExtensionConfig()).validate()
    results_dir = Path(config.results_dir)
    figures_dir = Path(config.figures_dir)
    results_dir.mkdir(parents=True, exist_ok=True)
    figures_dir.mkdir(parents=True, exist_ok=True)

    candidates = make_candidate_grid(config)
    observable_df = add_observable_predictions(candidates, config)
    stability_df = add_stability_prior_components(observable_df, config)
    likelihood_df = add_likelihood(stability_df, config)
    priors = baseline_priors(likelihood_df, config)
    evidence_df, posterior_df = evidence_table(likelihood_df, priors)

    candidates.to_csv(results_dir / "rung5_candidate_grid.csv", index=False)
    observable_df.to_csv(results_dir / "rung6_observable_predictions.csv", index=False)
    likelihood_df.to_csv(results_dir / "rung7_likelihood_grid.csv", index=False)
    evidence_df.to_csv(results_dir / "rung8_evidence_bayes_factors.csv", index=False)
    posterior_df.to_csv(results_dir / "rung8_posteriors_by_prior.csv", index=False)
    write_dataset_file(config, results_dir)
    write_notes(config, results_dir)
    make_figures(likelihood_df, evidence_df, figures_dir)

    summary = {
        "version": "1.6.0",
        "extension": "physical_rungs_5_to_8",
        "n_candidates_total": int(len(candidates)),
        "n_observable_valid_candidates": int(likelihood_df["observable_valid"].sum()),
        "candidate_space": {
            "lambda_min": config.lambda_min,
            "lambda_max": config.lambda_max,
            "lambda_points": config.lambda_points,
            "g_min": config.g_min,
            "g_max": config.g_max,
            "g_points": config.g_points,
        },
        "dataset": {
            "observable": "CMB shift parameter R",
            "R_obs": config.cmb_shift_r_obs,
            "R_sigma": config.cmb_shift_r_sigma,
            "z_star": config.z_star,
        },
        "evidence": evidence_df.to_dict("records"),
        "claim_boundary": "background-level compressed-data demonstration; not a full CMB likelihood analysis",
    }
    (results_dir / "physical_extension_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    return summary


def main(argv: Iterable[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Run OFST physical extension rungs 5-8.")
    parser.add_argument("--results-dir", default="results/physical_extension")
    parser.add_argument("--figures-dir", default="figures/physical_extension")
    parser.add_argument("--integration-steps", type=int, default=4096)
    parser.add_argument("--eta", type=float, default=8.0, help="Gibbs concentration for the stability prior")
    args = parser.parse_args(list(argv) if argv is not None else None)
    config = PhysicalExtensionConfig(
        results_dir=args.results_dir,
        figures_dir=args.figures_dir,
        integration_steps=args.integration_steps,
        stability_eta=args.eta,
    )
    summary = run(config)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
