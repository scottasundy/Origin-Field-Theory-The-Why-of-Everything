#!/usr/bin/env python3
"""
Origin Field Stability Prior ECA Analysis

Finite ensemble: all 256 elementary cellular automata (ECA).
Purpose: implement a declared stability-weighted Gibbs prior over a complete finite toy-model ensemble.

This script produces:
  - results/config_snapshot.json
  - results/eca_metrics.csv
  - results/ofst_rankings.csv
  - results/top20_ofst.csv
  - results/ofst_class_rankings.csv
  - results/metric_robustness_rules.csv
  - results/metric_robustness_classes.csv
  - results/hyperparameter_combo_summary.csv
  - results/trajectory_holdout_validation.csv
  - results/claim_ledger.md
  - results/run_summary.json
  - results/uncertainty_summary.csv
  - figures/*.png

Run from the repository root:
    python src/ofst_eca_analysis.py

Common overrides:
    python src/ofst_eca_analysis.py --n-cells 128 --n-steps 128 --eta 6
    python src/ofst_eca_analysis.py --weights C=0.10,A=0.15,O=0.65,R=0.10
"""

from __future__ import annotations

import argparse
import gzip
import json
import math
import os
import platform
import sys
from datetime import datetime, timezone
from dataclasses import asdict, dataclass, field, replace
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

os.environ["MPLBACKEND"] = "Agg"
import matplotlib

matplotlib.use("Agg", force=True)
import matplotlib.pyplot as plt


DEFAULT_SEED = 20260516
DEFAULT_N_CELLS = 96
DEFAULT_N_STEPS = 96
DEFAULT_N_RANDOM_SEEDS = 20
DEFAULT_N_FRAGILITY_SEEDS = 8
DEFAULT_ETA = 8.0
DEFAULT_LOCAL_SENSITIVITY_DRAWS = 300
DEFAULT_GLOBAL_SENSITIVITY_DRAWS = 2000
DEFAULT_SEED_SENSITIVITY_RUNS = 3
DEFAULT_SIZE_SENSITIVITY_SCALES = [(64, 64), (96, 96), (128, 128)]
DEFAULT_MODEL_AVERAGING_WEIGHT_DRAWS = 32
DEFAULT_MODEL_AVERAGING_ETA_GRID = [0.0, 1.0, 2.0, 4.0, 8.0, 16.0]
DEFAULT_NULL_MODEL_DRAWS = 256
DEFAULT_BOOTSTRAP_DRAWS = 512
DEFAULT_RUN_PROFILE = "default"

# Stability weights: C consistency, A finite-trajectory compressibility,
# O persistent-structure proxy, R fragility penalty.
DEFAULT_WEIGHTS = {
    "C": 0.10,
    "A": 0.15,
    "O": 0.65,
    "R": 0.10,
}

DEFAULT_SELECTED_FIGURE_RULES = [1, 30, 56, 98, 110, 177, 184, 227]


# Backward-compatible module constants used by older notebooks/tests.
SEED = DEFAULT_SEED
N_CELLS = DEFAULT_N_CELLS
N_STEPS = DEFAULT_N_STEPS
N_RANDOM_SEEDS = DEFAULT_N_RANDOM_SEEDS
N_FRAGILITY_SEEDS = DEFAULT_N_FRAGILITY_SEEDS
ETA = DEFAULT_ETA
GLOBAL_SENSITIVITY_DRAWS = DEFAULT_GLOBAL_SENSITIVITY_DRAWS
SEED_SENSITIVITY_RUNS = DEFAULT_SEED_SENSITIVITY_RUNS
SIZE_SENSITIVITY_SCALES = DEFAULT_SIZE_SENSITIVITY_SCALES.copy()
MODEL_AVERAGING_WEIGHT_DRAWS = DEFAULT_MODEL_AVERAGING_WEIGHT_DRAWS
MODEL_AVERAGING_ETA_GRID = DEFAULT_MODEL_AVERAGING_ETA_GRID.copy()
NULL_MODEL_DRAWS = DEFAULT_NULL_MODEL_DRAWS
BOOTSTRAP_DRAWS = DEFAULT_BOOTSTRAP_DRAWS
RUN_PROFILE = DEFAULT_RUN_PROFILE
WEIGHTS = DEFAULT_WEIGHTS.copy()
SELECTED_FIGURE_RULES = DEFAULT_SELECTED_FIGURE_RULES.copy()


@dataclass(frozen=True)
class RunConfig:
    """Complete configuration for one reproducible OFST finite-ensemble run."""

    seed: int = DEFAULT_SEED
    n_cells: int = DEFAULT_N_CELLS
    n_steps: int = DEFAULT_N_STEPS
    n_random_initial_conditions: int = DEFAULT_N_RANDOM_SEEDS
    n_fragility_initial_conditions: int = DEFAULT_N_FRAGILITY_SEEDS
    weights: dict[str, float] = field(default_factory=lambda: DEFAULT_WEIGHTS.copy())
    eta: float = DEFAULT_ETA
    local_sensitivity_draws: int = DEFAULT_LOCAL_SENSITIVITY_DRAWS
    global_sensitivity_draws: int = DEFAULT_GLOBAL_SENSITIVITY_DRAWS
    seed_sensitivity_runs: int = DEFAULT_SEED_SENSITIVITY_RUNS
    model_averaging_weight_draws: int = DEFAULT_MODEL_AVERAGING_WEIGHT_DRAWS
    model_averaging_eta_grid: list[float] = field(default_factory=lambda: DEFAULT_MODEL_AVERAGING_ETA_GRID.copy())
    null_model_draws: int = DEFAULT_NULL_MODEL_DRAWS
    bootstrap_draws: int = DEFAULT_BOOTSTRAP_DRAWS
    run_profile: str = DEFAULT_RUN_PROFILE
    selected_figure_rules: list[int] = field(default_factory=lambda: DEFAULT_SELECTED_FIGURE_RULES.copy())
    output_results_dir: str = "results"
    output_figures_dir: str = "figures"

    def validate(self) -> "RunConfig":
        """Validate dimensions, weights, and numerical parameters."""
        if self.n_cells <= 0:
            raise ValueError("n_cells must be positive.")
        if self.n_steps <= 1:
            raise ValueError("n_steps must be greater than 1.")
        if self.n_random_initial_conditions <= 0:
            raise ValueError("n_random_initial_conditions must be positive.")
        if self.n_fragility_initial_conditions <= 0:
            raise ValueError("n_fragility_initial_conditions must be positive.")
        if self.eta < 0:
            raise ValueError("eta must be nonnegative.")
        if self.local_sensitivity_draws <= 0:
            raise ValueError("local_sensitivity_draws must be positive.")
        if self.global_sensitivity_draws <= 0:
            raise ValueError("global_sensitivity_draws must be positive.")
        if self.seed_sensitivity_runs <= 0:
            raise ValueError("seed_sensitivity_runs must be positive.")
        if self.model_averaging_weight_draws <= 0:
            raise ValueError("model_averaging_weight_draws must be positive.")
        if len(self.model_averaging_eta_grid) == 0:
            raise ValueError("model_averaging_eta_grid must contain at least one eta value.")
        if self.null_model_draws < 0:
            raise ValueError("null_model_draws must be nonnegative.")
        if self.bootstrap_draws < 0:
            raise ValueError("bootstrap_draws must be nonnegative.")
        if self.run_profile not in {"default", "ci", "tiny", "custom"}:
            raise ValueError("run_profile must be one of: default, ci, tiny, custom.")
        if any((not np.isfinite(v)) or v < 0 for v in self.model_averaging_eta_grid):
            raise ValueError("model_averaging_eta_grid values must be finite and nonnegative.")

        expected = {"C", "A", "O", "R"}
        if set(self.weights) != expected:
            raise ValueError(f"weights must define exactly {sorted(expected)}.")
        if any((not np.isfinite(v)) or v < 0 for v in self.weights.values()):
            raise ValueError("all weights must be finite and nonnegative.")
        if sum(self.weights.values()) <= 0:
            raise ValueError("at least one weight must be positive.")
        for rule in self.selected_figure_rules:
            if not 0 <= int(rule) <= 255:
                raise ValueError("selected ECA figure rules must be in 0..255.")
        return self


def parse_weights(text: str) -> dict[str, float]:
    """Parse C=...,A=...,O=...,R=... weight strings."""
    parts = [part.strip() for part in text.split(",") if part.strip()]
    weights: dict[str, float] = {}
    for part in parts:
        if "=" not in part:
            raise argparse.ArgumentTypeError("weights must have form C=0.1,A=0.15,O=0.65,R=0.1")
        key, value = [x.strip() for x in part.split("=", 1)]
        if key not in {"C", "A", "O", "R"}:
            raise argparse.ArgumentTypeError(f"unknown weight key {key!r}; expected C,A,O,R")
        try:
            weights[key] = float(value)
        except ValueError as exc:
            raise argparse.ArgumentTypeError(f"invalid numeric weight for {key}: {value!r}") from exc

    if set(weights) != {"C", "A", "O", "R"}:
        raise argparse.ArgumentTypeError("weights must define exactly C,A,O,R")
    return weights


def parse_rule_list(text: str) -> list[int]:
    """Parse comma-separated ECA rule IDs."""
    try:
        return [int(part.strip()) for part in text.split(",") if part.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("selected rules must be comma-separated integers") from exc


def parse_float_list(text: str) -> list[float]:
    """Parse comma-separated nonnegative floating-point values."""
    try:
        values = [float(part.strip()) for part in text.split(",") if part.strip()]
    except ValueError as exc:
        raise argparse.ArgumentTypeError("values must be comma-separated numbers") from exc
    if not values:
        raise argparse.ArgumentTypeError("at least one value is required")
    if any((not np.isfinite(v)) or v < 0 for v in values):
        raise argparse.ArgumentTypeError("all values must be finite and nonnegative")
    return values


def build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--profile", choices=["default", "ci", "tiny"], default=DEFAULT_RUN_PROFILE, help="Run-size preset. Explicit numeric flags still override defaults.")
    parser.add_argument("--seed", type=int, default=DEFAULT_SEED)
    parser.add_argument("--n-cells", type=int, default=DEFAULT_N_CELLS)
    parser.add_argument("--n-steps", type=int, default=DEFAULT_N_STEPS)
    parser.add_argument("--n-random-initial-conditions", type=int, default=DEFAULT_N_RANDOM_SEEDS)
    parser.add_argument("--n-fragility-initial-conditions", type=int, default=DEFAULT_N_FRAGILITY_SEEDS)
    parser.add_argument("--weights", type=parse_weights, default=DEFAULT_WEIGHTS.copy())
    parser.add_argument("--eta", type=float, default=DEFAULT_ETA)
    parser.add_argument("--local-sensitivity-draws", type=int, default=DEFAULT_LOCAL_SENSITIVITY_DRAWS)
    parser.add_argument("--global-sensitivity-draws", type=int, default=DEFAULT_GLOBAL_SENSITIVITY_DRAWS)
    parser.add_argument("--seed-sensitivity-runs", type=int, default=DEFAULT_SEED_SENSITIVITY_RUNS)
    parser.add_argument("--model-averaging-weight-draws", type=int, default=DEFAULT_MODEL_AVERAGING_WEIGHT_DRAWS)
    parser.add_argument("--model-averaging-eta-grid", type=parse_float_list, default=DEFAULT_MODEL_AVERAGING_ETA_GRID.copy())
    parser.add_argument("--null-model-draws", type=int, default=DEFAULT_NULL_MODEL_DRAWS)
    parser.add_argument("--bootstrap-draws", type=int, default=DEFAULT_BOOTSTRAP_DRAWS)
    parser.add_argument("--selected-figure-rules", type=parse_rule_list, default=DEFAULT_SELECTED_FIGURE_RULES.copy())
    parser.add_argument("--results-dir", default="results")
    parser.add_argument("--figures-dir", default="figures")
    return parser


def config_from_args(argv: list[str] | None = None) -> RunConfig:
    parser = build_arg_parser()
    args = parser.parse_args(argv)

    # Profiles are convenience presets. They only replace parser defaults, so
    # explicit numeric flags continue to override the profile.
    profile_overrides = {
        "ci": {
            "n_cells": 32,
            "n_steps": 32,
            "n_random_initial_conditions": 6,
            "n_fragility_initial_conditions": 3,
            "local_sensitivity_draws": 12,
            "global_sensitivity_draws": 16,
            "seed_sensitivity_runs": 2,
            "model_averaging_weight_draws": 6,
            "model_averaging_eta_grid": [0.0, 2.0, 8.0],
            "null_model_draws": 24,
            "bootstrap_draws": 128,
            "selected_figure_rules": [],
        },
        "tiny": {
            "n_cells": 16,
            "n_steps": 16,
            "n_random_initial_conditions": 3,
            "n_fragility_initial_conditions": 2,
            "local_sensitivity_draws": 5,
            "global_sensitivity_draws": 7,
            "seed_sensitivity_runs": 2,
            "model_averaging_weight_draws": 5,
            "model_averaging_eta_grid": [0.0, 2.0],
            "null_model_draws": 8,
            "bootstrap_draws": 64,
            "selected_figure_rules": [],
        },
    }
    if args.profile in profile_overrides:
        defaults = {action.dest: action.default for action in parser._actions}
        for key, value in profile_overrides[args.profile].items():
            if getattr(args, key) == defaults.get(key):
                setattr(args, key, value)

    return RunConfig(
        seed=args.seed,
        n_cells=args.n_cells,
        n_steps=args.n_steps,
        n_random_initial_conditions=args.n_random_initial_conditions,
        n_fragility_initial_conditions=args.n_fragility_initial_conditions,
        weights=args.weights,
        eta=args.eta,
        local_sensitivity_draws=args.local_sensitivity_draws,
        global_sensitivity_draws=args.global_sensitivity_draws,
        seed_sensitivity_runs=args.seed_sensitivity_runs,
        model_averaging_weight_draws=args.model_averaging_weight_draws,
        model_averaging_eta_grid=args.model_averaging_eta_grid,
        null_model_draws=args.null_model_draws,
        bootstrap_draws=args.bootstrap_draws,
        run_profile=args.profile,
        selected_figure_rules=args.selected_figure_rules,
        output_results_dir=args.results_dir,
        output_figures_dir=args.figures_dir,
    ).validate()


def eca_step_batch(states: np.ndarray, rule: int) -> np.ndarray:
    """Apply one elementary cellular automaton update step to a batch of states."""
    idx = (np.roll(states, 1, axis=1) * 4 + states * 2 + np.roll(states, -1, axis=1)).astype(np.uint8)
    return ((rule >> idx) & 1).astype(np.uint8)


def run_eca_batch(rule: int, initials: np.ndarray, steps: int) -> np.ndarray:
    """Return histories with shape (n_initials, steps, n_cells)."""
    states = initials.copy()
    hist = np.empty((initials.shape[0], steps, initials.shape[1]), dtype=np.uint8)
    for t in range(steps):
        hist[:, t, :] = states
        states = eca_step_batch(states, rule)
    return hist


def binary_entropy(p: float) -> float:
    """Binary entropy in bits."""
    p = float(p)
    if p <= 1e-15 or p >= 1 - 1e-15:
        return 0.0
    return -(p * math.log2(p) + (1 - p) * math.log2(1 - p))


def normalized_mi_binary(x: np.ndarray, y: np.ndarray) -> float:
    """Normalized mutual information for binary arrays."""
    x = x.astype(np.uint8).ravel()
    y = y.astype(np.uint8).ravel()
    n = len(x)
    if n == 0:
        return 0.0

    counts = np.bincount((2 * x + y).astype(np.uint8), minlength=4).reshape(2, 2).astype(float)
    probs = counts / n
    px = probs.sum(axis=1)
    py = probs.sum(axis=0)

    mi = 0.0
    for i in range(2):
        for j in range(2):
            p = probs[i, j]
            if p > 0 and px[i] > 0 and py[j] > 0:
                mi += p * math.log2(p / (px[i] * py[j]))

    denom = max(min(binary_entropy(px[1]), binary_entropy(py[1])), 1e-12)
    return float(max(0.0, min(1.0, mi / denom)))



def normalized_block_entropy(bits: np.ndarray, block_size: int) -> float:
    """Normalized Shannon entropy of contiguous binary blocks.

    The block string is flattened across the finite trajectory. This is a
    symbolic-dynamics diagnostic, not a physical observer measure.
    """
    flat = bits.astype(np.uint8).ravel()
    n = int(flat.size)
    k = int(block_size)
    if k <= 0 or n < k:
        return 0.0
    codes = np.zeros(n - k + 1, dtype=np.uint16)
    for j in range(k):
        codes = (codes << 1) | flat[j : j + n - k + 1]
    counts = np.bincount(codes, minlength=2**k).astype(float)
    probs = counts[counts > 0] / counts.sum()
    entropy = float(-(probs * np.log2(probs)).sum())
    return float(min(1.0, max(0.0, entropy / k)))


def lz76_complexity_sample(bits: np.ndarray, max_bits: int = 2048) -> float:
    """Approximate normalized Lempel-Ziv 76 phrase complexity on a initial-segment sample.

    This intentionally uses a bounded initial segment to keep the full 256-rule ensemble
    analysis reproducible on ordinary hardware. The output is a diagnostic in
    [0, 1] after normalization by n/log2(n).
    """
    flat = bits.astype(np.uint8).ravel()
    if flat.size == 0:
        return 0.0
    if flat.size > max_bits:
        flat = flat[:max_bits]
    s = "".join("1" if b else "0" for b in flat)
    n = len(s)
    if n < 2:
        return 0.0

    phrases: set[str] = set()
    i = 0
    complexity = 0
    while i < n:
        j = i + 1
        while j <= n and s[i:j] in phrases:
            j += 1
        phrases.add(s[i:j])
        complexity += 1
        i = j

    normalizer = n / max(1.0, math.log2(n))
    return float(min(1.0, max(0.0, complexity / normalizer)))


def metrics_for_histories(histories: np.ndarray) -> dict[str, float]:
    """Compute predeclared toy-universe metrics from generated histories."""
    H = histories
    density = float(H.mean())
    entropy = float(binary_entropy(density))

    activity = float(np.logical_xor(H[:, 1:, :], H[:, :-1, :]).mean()) if H.shape[1] > 1 else 0.0
    activity_balance = float(4 * activity * (1 - activity))

    spatial_mi = normalized_mi_binary(H, np.roll(H, -1, axis=2))
    time_mi = normalized_mi_binary(H[:, :-1, :], H[:, 1:, :]) if H.shape[1] > 1 else 0.0

    lag = 5
    lag5_mi = normalized_mi_binary(H[:, :-lag, :], H[:, lag:, :]) if H.shape[1] > lag else 0.0

    edge_density = float(np.logical_xor(H, np.roll(H, -1, axis=2)).mean())
    edge_balance = float(4 * edge_density * (1 - edge_density))

    block_entropy_2 = normalized_block_entropy(H, 2)
    block_entropy_3 = normalized_block_entropy(H, 3)
    block_entropy_4 = normalized_block_entropy(H, 4)
    lz_complexity = lz76_complexity_sample(H)
    temporal_excess_entropy_proxy = float(min(1.0, max(0.0, 0.5 * (spatial_mi + time_mi) + 0.25 * lag5_mi)))

    packed = np.packbits(H.reshape(-1).astype(np.uint8)).tobytes()
    compression_ratio = len(gzip.compress(packed, compresslevel=9)) / max(1, len(packed))

    return {
        "density": density,
        "entropy": entropy,
        "activity": activity,
        "activity_balance": activity_balance,
        "spatial_mi": float(spatial_mi),
        "time_mi": float(time_mi),
        "lag5_mi": float(lag5_mi),
        "edge_density": edge_density,
        "edge_balance": edge_balance,
        "block_entropy_2": float(block_entropy_2),
        "block_entropy_3": float(block_entropy_3),
        "block_entropy_4": float(block_entropy_4),
        "lz_complexity": float(lz_complexity),
        "temporal_excess_entropy_proxy": float(temporal_excess_entropy_proxy),
        "compression_ratio": float(compression_ratio),
    }


def macro_vector(m: dict[str, float]) -> np.ndarray:
    """Coarse macrostructure vector used for fragility scoring."""
    return np.array(
        [
            m["density"],
            m["entropy"],
            m["activity"],
            m["spatial_mi"],
            m["time_mi"],
            m["lag5_mi"],
            m["edge_density"],
        ],
        dtype=float,
    )


def _info_components(row: pd.Series) -> dict[str, float]:
    """Reusable components for persistent-structure variants.

    The base O(U) metric intentionally does not use gzip compression. Gzip-derived
    compressibility is reserved for A(U) and for explicitly labeled sensitivity
    variants so the base score does not double-count the same compression signal.
    """
    info_persistence = 0.65 * row["time_mi"] + 0.35 * row["lag5_mi"]
    structured_nontrivial = math.sqrt(max(0.0, row["spatial_mi"]) * max(0.0, row["edge_balance"]))
    compression_window = row.get("compression_window", row.get("complexity_window", 1.0))
    late_info_persistence = 0.65 * row.get("late_time_mi", row["time_mi"]) + 0.35 * row.get("late_lag5_mi", row["lag5_mi"])
    early_late_stability = row.get("early_late_macro_stability", 1.0)
    return {
        "entropy": max(1e-9, float(row["entropy"])),
        "activity_balance": max(1e-9, float(row["activity_balance"])),
        "info_persistence": max(1e-9, float(info_persistence)),
        "structured_nontrivial": max(1e-9, float(structured_nontrivial)),
        "compression_window": max(1e-9, float(compression_window)),
        "edge_balance": max(1e-9, float(row["edge_balance"])),
        "spatial_mi": max(1e-9, float(row["spatial_mi"])),
        "time_mi": max(1e-9, float(row["time_mi"])),
        "lag5_mi": max(1e-9, float(row["lag5_mi"])),
        "late_info_persistence": max(1e-9, float(late_info_persistence)),
        "early_late_macro_stability": max(1e-9, float(early_late_stability)),
        "block_entropy_2": max(1e-9, float(row.get("block_entropy_2", row["entropy"]))),
        "block_entropy_3": max(1e-9, float(row.get("block_entropy_3", row["entropy"]))),
        "block_entropy_4": max(1e-9, float(row.get("block_entropy_4", row["entropy"]))),
        "lz_complexity": max(1e-9, float(row.get("lz_complexity", row.get("compression_window", 1.0)))),
        "temporal_excess_entropy_proxy": max(1e-9, float(row.get("temporal_excess_entropy_proxy", info_persistence))),
    }


def _geometric_mean(values: Iterable[float]) -> float:
    """Stable geometric mean for nonnegative bounded metrics."""
    arr = np.array([max(1e-12, float(v)) for v in values], dtype=float)
    return float(np.exp(np.mean(np.log(arr))))


def _harmonic_mean(values: Iterable[float]) -> float:
    """Stable harmonic mean for positive bounded metrics."""
    arr = np.array([max(1e-12, float(v)) for v in values], dtype=float)
    return float(len(arr) / np.sum(1.0 / arr))


def structural_persistence_proxy(row: pd.Series, compression_window: float | None = None) -> float:
    """
    Predeclared operational proxy for persistent structural information.

    The base proxy rewards finite histories that are:
      - nontrivial in state occupancy,
      - dynamically active without becoming pure noise,
      - temporally information-preserving,
      - spatially structured.

    The base proxy excludes gzip-derived compression so that O(U) is not
    mechanically coupled to the separate compressibility term A(U). Compression
    enters only through explicitly named sensitivity variants.
    """
    row = row.copy()
    if compression_window is not None:
        row["compression_window"] = compression_window
        row["complexity_window"] = compression_window
    c = _info_components(row)
    components = [
        c["entropy"],
        c["activity_balance"],
        c["info_persistence"],
        c["structured_nontrivial"],
    ]
    return _geometric_mean(components)


def observer_support_proxy(row: pd.Series, compression_window: float | None = None) -> float:
    """Backward-compatible alias for structural_persistence_proxy."""
    return structural_persistence_proxy(row, compression_window=compression_window)


def metric_registry() -> dict[str, dict]:
    """
    Preregistered O(U) metric family used for robustness analysis.

    The metric family deliberately separates non-compression structural proxies
    from compression-inclusive stress tests and from trajectory-holdout variants.
    Robustness claims should survive across this bounded family; when they do
    not, the generated claim ledger reports the limitation directly.
    """
    return {
        "base_geometric": {
            "description": "Geometric mean of entropy, activity balance, temporal persistence, and spatial structure; excludes gzip compression.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "with_compression_window_geometric": {
            "description": "Base geometric structural proxy with an added gzip-derived nontriviality window; included only as a sensitivity variant.",
            "uses_compression_window": True,
            "uses_holdout_feature": False,
        },
        "arithmetic_mean": {
            "description": "Arithmetic instead of geometric aggregation of the non-compression base components.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "harmonic_mean_guardrail": {
            "description": "Harmonic aggregation of the non-compression base components; strongly penalizes any missing component.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "min_component_guardrail": {
            "description": "Minimum of the non-compression base components; extremely conservative bottleneck proxy.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "information_heavy_geometric": {
            "description": "Geometric proxy with extra weight on temporal persistence and spatial mutual information.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "structure_heavy_geometric": {
            "description": "Geometric proxy with extra weight on spatially structured nontriviality.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "entropy_activity_geometric": {
            "description": "Minimal nontriviality proxy using only entropy and activity balance.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "persistence_structure_geometric": {
            "description": "Proxy emphasizing temporal persistence and spatial structure over occupancy/activity.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "spatial_temporal_balance": {
            "description": "Proxy requiring both spatial organization and temporal information retention.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "edge_temporal_geometric": {
            "description": "Proxy combining edge-balance structure with short- and medium-lag temporal mutual information.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "late_holdout_geometric": {
            "description": "Holdout proxy computed from late-trajectory information features where available.",
            "uses_compression_window": False,
            "uses_holdout_feature": True,
        },
        "predictive_stability_geometric": {
            "description": "Proxy including early-to-late macrostructure stability as an explicitly labeled holdout term.",
            "uses_compression_window": False,
            "uses_holdout_feature": True,
        },
        "block_entropy_geometric": {
            "description": "Base non-compression structural proxy plus normalized 4-block symbolic entropy.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "lz_complexity_geometric": {
            "description": "Base non-compression structural proxy plus bounded initial-segment Lempel-Ziv complexity diagnostic.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "symbolic_dynamics_geometric": {
            "description": "Base structural proxy plus block entropies and Lempel-Ziv complexity diagnostics.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "excess_entropy_geometric": {
            "description": "Base structural proxy plus a temporal/spatial excess-entropy-style mutual-information proxy.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "multi_complexity_geometric": {
            "description": "Base structural proxy plus symbolic-dynamics, Lempel-Ziv, and excess-entropy-style diagnostics.",
            "uses_compression_window": False,
            "uses_holdout_feature": False,
        },
        "compression_only_window": {
            "description": "Compression-window-only stress test; included to quantify sensitivity to the A(U)-adjacent signal.",
            "uses_compression_window": True,
            "uses_holdout_feature": False,
        },
    }


def alternative_o_score(row: pd.Series, variant: str) -> float:
    """Compute alternative O(U) metrics used as robustness checks."""
    c = _info_components(row)
    base = np.array(
        [
            c["entropy"],
            c["activity_balance"],
            c["info_persistence"],
            c["structured_nontrivial"],
        ],
        dtype=float,
    )

    if variant == "base_geometric":
        return structural_persistence_proxy(row)
    if variant == "with_compression_window_geometric":
        return _geometric_mean([*base, c["compression_window"]])
    if variant == "arithmetic_mean":
        return float(np.mean(base))
    if variant == "harmonic_mean_guardrail":
        return _harmonic_mean(base)
    if variant == "min_component_guardrail":
        return float(np.min(base))
    if variant == "information_heavy_geometric":
        extended = np.array([c["entropy"], c["activity_balance"], c["info_persistence"], c["structured_nontrivial"], c["spatial_mi"]], dtype=float)
        exponents = np.array([0.12, 0.12, 0.38, 0.20, 0.18], dtype=float)
        return float(np.prod(extended ** exponents))
    if variant == "structure_heavy_geometric":
        extended = np.array([c["entropy"], c["activity_balance"], c["info_persistence"], c["structured_nontrivial"], c["edge_balance"]], dtype=float)
        exponents = np.array([0.12, 0.12, 0.18, 0.40, 0.18], dtype=float)
        return float(np.prod(extended ** exponents))
    if variant == "entropy_activity_geometric":
        return _geometric_mean([c["entropy"], c["activity_balance"]])
    if variant == "persistence_structure_geometric":
        return _geometric_mean([c["info_persistence"], c["structured_nontrivial"]])
    if variant == "spatial_temporal_balance":
        return _geometric_mean([c["spatial_mi"], c["time_mi"], c["lag5_mi"], c["edge_balance"]])
    if variant == "edge_temporal_geometric":
        return _geometric_mean([c["edge_balance"], c["time_mi"], c["lag5_mi"]])
    if variant == "late_holdout_geometric":
        late_structured = math.sqrt(
            max(1e-9, float(row.get("late_spatial_mi", row["spatial_mi"])))
            * max(1e-9, float(row.get("late_edge_balance", row["edge_balance"])))
        )
        return _geometric_mean(
            [
                row.get("late_entropy", row["entropy"]),
                row.get("late_activity_balance", row["activity_balance"]),
                c["late_info_persistence"],
                late_structured,
            ]
        )
    if variant == "predictive_stability_geometric":
        return _geometric_mean([*base, c["early_late_macro_stability"]])
    if variant == "block_entropy_geometric":
        return _geometric_mean([*base, c["block_entropy_4"]])
    if variant == "lz_complexity_geometric":
        return _geometric_mean([*base, c["lz_complexity"]])
    if variant == "symbolic_dynamics_geometric":
        return _geometric_mean([*base, c["block_entropy_2"], c["block_entropy_3"], c["block_entropy_4"], c["lz_complexity"]])
    if variant == "excess_entropy_geometric":
        return _geometric_mean([*base, c["temporal_excess_entropy_proxy"]])
    if variant == "multi_complexity_geometric":
        return _geometric_mean([*base, c["block_entropy_3"], c["block_entropy_4"], c["lz_complexity"], c["temporal_excess_entropy_proxy"]])
    if variant == "compression_only_window":
        return float(c["compression_window"])

    raise ValueError(f"unknown O metric variant {variant!r}")


def compute_metrics(config: RunConfig | None = None) -> tuple[pd.DataFrame, dict[int, np.ndarray]]:
    """Compute all scores for the complete ECA ensemble."""
    if config is None:
        config = RunConfig().validate()
    else:
        config = config.validate()

    rng = np.random.default_rng(config.seed)

    initials = rng.integers(0, 2, size=(config.n_random_initial_conditions, config.n_cells), dtype=np.uint8)

    frag_initials = rng.integers(0, 2, size=(config.n_fragility_initial_conditions, config.n_cells), dtype=np.uint8)
    frag_perturbed = frag_initials.copy()
    bit_positions = rng.integers(0, config.n_cells, size=config.n_fragility_initial_conditions)
    frag_perturbed[np.arange(config.n_fragility_initial_conditions), bit_positions] ^= 1

    raw_rows = []
    sample_histories: dict[int, np.ndarray] = {}

    for rule in range(256):
        histories = run_eca_batch(rule, initials, config.n_steps)
        m = metrics_for_histories(histories)

        # External-validation features: measure whether early-run structure predicts later-run structure.
        # These fields are not used by the base OFST score, except by the explicitly named
        # predictive_stability O-variant in the robustness ensemble.
        mid = max(1, config.n_steps // 2)
        early_m = metrics_for_histories(histories[:, :mid, :])
        late_m = metrics_for_histories(histories[:, mid:, :]) if mid < config.n_steps else early_m.copy()
        early_late_macro_distance = float(np.mean(np.abs(macro_vector(early_m) - macro_vector(late_m))))
        early_late_macro_stability = float(1.0 - min(1.0, 2.0 * early_late_macro_distance))

        H0 = run_eca_batch(rule, frag_initials, config.n_steps)
        H1 = run_eca_batch(rule, frag_perturbed, config.n_steps)
        m0 = metrics_for_histories(H0)
        m1 = metrics_for_histories(H1)

        macro_dist = float(np.mean(np.abs(macro_vector(m0) - macro_vector(m1))))
        final_divergence = float(np.logical_xor(H0[:, -1, :], H1[:, -1, :]).mean())
        fragility = float(0.75 * min(1.0, macro_dist * 4.0) + 0.25 * final_divergence)

        row = {
            "rule": rule,
            "C": 1.0,
            "R": fragility,
            **m,
            **{f"early_{k}": v for k, v in early_m.items()},
            **{f"late_{k}": v for k, v in late_m.items()},
            "early_late_macro_distance": early_late_macro_distance,
            "early_late_macro_stability": early_late_macro_stability,
        }
        raw_rows.append(row)

        if rule in config.selected_figure_rules:
            impulse = np.zeros((1, config.n_cells), dtype=np.uint8)
            impulse[0, config.n_cells // 2] = 1
            sample_histories[rule] = run_eca_batch(rule, impulse, config.n_steps)[0]

    df = pd.DataFrame(raw_rows)

    # Finite-trajectory gzip-compressibility score A from normalized gzip compression ratio.
    # Lower ratio means more compressible; A=1 is most compressible in this finite ensemble.
    ratio_min = df["compression_ratio"].min()
    ratio_max = df["compression_ratio"].max()
    compression_norm = (df["compression_ratio"] - ratio_min) / (ratio_max - ratio_min + 1e-12)
    df["A"] = 1.0 - compression_norm

    # Compression-window diagnostic prevents gzip-derived variants from favoring
    # frozen triviality or near-random incompressibility. It is not used in the
    # base O(U) score, which keeps A(U) and O(U) decoupled.
    df["compression_window"] = 4.0 * compression_norm * (1.0 - compression_norm)
    df["complexity_window"] = df["compression_window"]  # retained as a legacy alias for older CSV readers

    df["O"] = df.apply(observer_support_proxy, axis=1)

    weights = config.weights
    df["S"] = (
        weights["C"] * df["C"]
        + weights["A"] * df["A"]
        + weights["O"] * df["O"]
        - weights["R"] * df["R"]
    )

    exp_scores = np.exp(config.eta * (df["S"] - df["S"].max()))
    df["gibbs_weight"] = exp_scores / exp_scores.sum()

    df["rank_OFST"] = df["S"].rank(ascending=False, method="first").astype(int)
    df["rank_A_only"] = df["A"].rank(ascending=False, method="first").astype(int)
    df["rank_O_only"] = df["O"].rank(ascending=False, method="first").astype(int)
    df["rank_low_fragility"] = df["R"].rank(ascending=True, method="first").astype(int)

    return df.sort_values("rule").reset_index(drop=True), sample_histories


def _weight_vector(config: RunConfig) -> np.ndarray:
    return np.array([config.weights["C"], config.weights["A"], config.weights["O"], config.weights["R"]], dtype=float)


def sensitivity_analysis(
    df: pd.DataFrame, draws: int | None = None, config: RunConfig | None = None
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Perturb weights around the base vector and measure top-20 stability."""
    if config is None:
        config = RunConfig().validate()
    if draws is None:
        draws = config.local_sensitivity_draws
    rng = np.random.default_rng(config.seed + 1)

    base_top20 = set(df.sort_values("S", ascending=False).head(20)["rule"].tolist())
    rows = []
    frequency = {rule: 0 for rule in df["rule"].tolist()}

    base_vec = _weight_vector(config)

    for i in range(draws):
        multiplier = rng.uniform(0.75, 1.25, size=4)
        w = base_vec * multiplier
        w = w / w.sum()

        score = w[0] * df["C"] + w[1] * df["A"] + w[2] * df["O"] - w[3] * df["R"]
        top20 = set(df.assign(score=score).sort_values("score", ascending=False).head(20)["rule"].tolist())

        for rule in top20:
            frequency[int(rule)] += 1

        rows.append(
            {
                "draw": i,
                "w_C": w[0],
                "w_A": w[1],
                "w_O": w[2],
                "w_R": w[3],
                "top20_overlap_with_base": len(base_top20 & top20) / 20.0,
            }
        )

    sens = pd.DataFrame(rows)
    freq = (
        pd.DataFrame([{"rule": rule, "top20_frequency": count / draws} for rule, count in frequency.items()])
        .sort_values(["top20_frequency", "rule"], ascending=[False, True])
        .reset_index(drop=True)
    )

    return sens, freq


def global_simplex_sensitivity(
    df: pd.DataFrame, draws: int | None = None, config: RunConfig | None = None
) -> pd.DataFrame:
    """
    Sample stability weights broadly over the four-component simplex.

    This is intentionally harsher than the local ±25% perturbation test. It
    checks whether the base base-score top-20 set remains stable under unconstrained
    positive weights for C, A, O, and R. A low overlap here does not invalidate
    the base toy demonstration; it shows that robustness is local to the stated
    theory-prior regime rather than global across all possible weight choices.
    """
    if config is None:
        config = RunConfig().validate()
    if draws is None:
        draws = config.global_sensitivity_draws
    rng = np.random.default_rng(config.seed + 2)
    base_top20 = set(df.sort_values("S", ascending=False).head(20)["rule"].astype(int).tolist())

    rows = []
    for i in range(draws):
        w = rng.dirichlet(np.ones(4))
        score = w[0] * df["C"] + w[1] * df["A"] + w[2] * df["O"] - w[3] * df["R"]
        top20 = set(df.assign(score=score).sort_values("score", ascending=False).head(20)["rule"].astype(int).tolist())
        rows.append(
            {
                "draw": i,
                "w_C": float(w[0]),
                "w_A": float(w[1]),
                "w_O": float(w[2]),
                "w_R": float(w[3]),
                "top20_overlap_with_base": len(base_top20 & top20) / 20.0,
            }
        )

    return pd.DataFrame(rows)


def ablation_analysis(df: pd.DataFrame, config: RunConfig | None = None) -> pd.DataFrame:
    """
    Remove or isolate score components to expose which terms drive the ranking.

    This is a diagnostic, not an independent confirmation. It is included so
    users can see when the toy result depends on information architecture,
    trajectory compressibility, or fragility penalties.
    """
    if config is None:
        config = RunConfig().validate()
    base_vec = _weight_vector(config)
    components = ["C", "A", "O", "R"]

    rows = []

    def add_case(case: str, w: np.ndarray) -> None:
        score = w[0] * df["C"] + w[1] * df["A"] + w[2] * df["O"] - w[3] * df["R"]
        top10 = df.assign(score=score).sort_values("score", ascending=False).head(10)["rule"].astype(int).tolist()
        rows.append(
            {
                "case": case,
                "w_C": float(w[0]),
                "w_A": float(w[1]),
                "w_O": float(w[2]),
                "w_R": float(w[3]),
                "top10_rules": json.dumps(top10),
            }
        )

    add_case("base_OFST", base_vec)

    for i, name in enumerate(components):
        w = base_vec.copy()
        w[i] = 0.0
        if w.sum() > 0:
            w = w / w.sum()
        add_case(f"without_{name}", w)

    add_case("A_only", np.array([0.0, 1.0, 0.0, 0.0]))
    add_case("O_only", np.array([0.0, 0.0, 1.0, 0.0]))
    add_case("low_R_only", np.array([0.0, 0.0, 0.0, 1.0]))

    return pd.DataFrame(rows)


def o_metric_sensitivity(df: pd.DataFrame, config: RunConfig | None = None) -> pd.DataFrame:
    """
    Re-score the same ensemble under the preregistered O(U) metric family.

    This is retained as a human-readable diagnostic. The complementary global
    sensitivity diagnostic is hyperparameter_model_averaging(), which integrates
    over this metric family, weights, eta values, and base-prior choices.
    """
    if config is None:
        config = RunConfig().validate()

    variants = list(metric_registry().keys())
    weights = config.weights
    base_top20 = set(df.sort_values("S", ascending=False).head(20)["rule"].astype(int).tolist())

    rows = []
    for variant in variants:
        tmp = df.copy()
        tmp["O_variant"] = tmp.apply(lambda row: alternative_o_score(row, variant), axis=1)
        tmp["S_variant"] = (
            weights["C"] * tmp["C"]
            + weights["A"] * tmp["A"]
            + weights["O"] * tmp["O_variant"]
            - weights["R"] * tmp["R"]
        )
        top20 = tmp.sort_values("S_variant", ascending=False).head(20)
        top10 = top20.head(10)["rule"].astype(int).tolist()
        if "symmetry_class" in tmp:
            top_classes = (
                top20.groupby("symmetry_class")["S_variant"]
                .max()
                .sort_values(ascending=False)
                .head(5)
                .index.astype(int)
                .tolist()
            )
        else:
            top_classes = []

        rows.append(
            {
                "variant": variant,
                "top10_rules": json.dumps(top10),
                "top5_symmetry_classes": json.dumps(top_classes),
                "top20_overlap_with_base_O": len(base_top20 & set(top20["rule"].astype(int).tolist())) / 20.0,
                "mean_O_variant": float(tmp["O_variant"].mean()),
                "max_O_variant": float(tmp["O_variant"].max()),
            }
        )
    return pd.DataFrame(rows)


def robustness_label(probability: float) -> str:
    """Label top-k robustness probabilities with conservative thresholds."""
    p = float(probability)
    if p > 0.90:
        return "highly_robust"
    if p > 0.70:
        return "robust"
    if p > 0.50:
        return "suggestive"
    if p > 0.25:
        return "weak"
    return "not_robust"


def _normalize_weights(weights: np.ndarray) -> np.ndarray:
    weights = np.asarray(weights, dtype=float)
    total = float(weights.sum())
    if total <= 0:
        raise ValueError("weight vector must have positive sum")
    return weights / total


def model_averaging_weight_draws(config: RunConfig) -> pd.DataFrame:
    """
    Deterministic mixture of local and broad weight draws for model averaging.

    Half the draws come from a concentrated Dirichlet centered near the declared
    OFST weights. Half come from a broad Dirichlet over the simplex. The base
    declared weight vector is included explicitly as draw 0.
    """
    rng = np.random.default_rng(config.seed + 17)
    base = _normalize_weights(_weight_vector(config))
    rows = [
        {
            "draw": 0,
            "draw_family": "declared_base",
            "w_C": float(base[0]),
            "w_A": float(base[1]),
            "w_O": float(base[2]),
            "w_R": float(base[3]),
        }
    ]

    remaining = max(0, config.model_averaging_weight_draws - 1)
    local_n = remaining // 2
    broad_n = remaining - local_n

    local_alpha = np.maximum(base * 64.0, 1e-6)
    for i in range(local_n):
        w = rng.dirichlet(local_alpha)
        rows.append(
            {
                "draw": len(rows),
                "draw_family": "local_dirichlet_around_declared",
                "w_C": float(w[0]),
                "w_A": float(w[1]),
                "w_O": float(w[2]),
                "w_R": float(w[3]),
            }
        )

    for i in range(broad_n):
        w = rng.dirichlet(np.ones(4))
        rows.append(
            {
                "draw": len(rows),
                "draw_family": "broad_simplex_dirichlet",
                "w_C": float(w[0]),
                "w_A": float(w[1]),
                "w_O": float(w[2]),
                "w_R": float(w[3]),
            }
        )

    return pd.DataFrame(rows)


def base_prior_vectors(df: pd.DataFrame) -> dict[str, np.ndarray]:
    """Return raw-uniform and symmetry-class-uniform base priors over rules."""
    n = len(df)
    priors = {"uniform_raw_rules": np.ones(n, dtype=float) / n}
    if "symmetry_class" in df.columns:
        class_sizes = df.groupby("symmetry_class")["rule"].transform("count").to_numpy(dtype=float)
        n_classes = int(df["symmetry_class"].nunique())
        priors["uniform_symmetry_classes"] = 1.0 / (n_classes * class_sizes)
    return priors


def _gibbs_from_score(score: np.ndarray, eta: float, base_prior: np.ndarray) -> np.ndarray:
    shifted = np.asarray(score, dtype=float) - float(np.max(score))
    unnorm = np.asarray(base_prior, dtype=float) * np.exp(float(eta) * shifted)
    total = float(unnorm.sum())
    if total <= 0 or not np.isfinite(total):
        raise ValueError("invalid Gibbs normalization")
    return unnorm / total


def _rank_positions(order: np.ndarray, n: int) -> np.ndarray:
    ranks = np.empty(n, dtype=float)
    ranks[order] = np.arange(1, n + 1, dtype=float)
    return ranks


def wilson_interval(successes: float, trials: float, z: float = 1.959963984540054) -> tuple[float, float]:
    """Return a Wilson score interval for a binomial proportion."""
    if trials <= 0:
        return (math.nan, math.nan)
    p = float(successes) / float(trials)
    denom = 1.0 + z * z / trials
    centre = (p + z * z / (2.0 * trials)) / denom
    radius = z * math.sqrt((p * (1.0 - p) / trials) + (z * z / (4.0 * trials * trials))) / denom
    lo = max(0.0, centre - radius)
    hi = min(1.0, centre + radius)
    if abs(lo) < 1e-12:
        lo = 0.0
    if abs(hi) < 1e-12:
        hi = 0.0
    return (float(lo), float(hi))


def bootstrap_mean_interval(
    values: Iterable[float],
    rng: np.random.Generator,
    draws: int,
    confidence: float = 0.95,
) -> tuple[float, float]:
    """Nonparametric bootstrap interval for the sample mean."""
    arr = np.asarray(list(values), dtype=float)
    arr = arr[np.isfinite(arr)]
    if len(arr) == 0:
        return (math.nan, math.nan)
    if draws <= 0 or len(arr) == 1:
        mean = float(arr.mean())
        return (mean, mean)
    idx = rng.integers(0, len(arr), size=(draws, len(arr)))
    means = arr[idx].mean(axis=1)
    alpha = (1.0 - confidence) / 2.0
    return (float(np.quantile(means, alpha)), float(np.quantile(means, 1.0 - alpha)))


def uncertainty_summary_table(
    sensitivity_draws: pd.DataFrame,
    global_sensitivity_draws: pd.DataFrame,
    hyperparameter_combos: pd.DataFrame,
    null_model_draws: pd.DataFrame,
    config: RunConfig,
) -> pd.DataFrame:
    """Summarize interval estimates used to interpret finite diagnostic runs."""
    rng = np.random.default_rng(config.seed + 919)
    rows: list[dict[str, object]] = []

    def add_mean_interval(source: str, metric: str, values: Iterable[float]) -> None:
        arr = np.asarray(list(values), dtype=float)
        arr = arr[np.isfinite(arr)]
        lo, hi = bootstrap_mean_interval(arr, rng, config.bootstrap_draws)
        rows.append(
            {
                "source": source,
                "metric": metric,
                "n": int(len(arr)),
                "estimate": float(arr.mean()) if len(arr) else math.nan,
                "ci_method": "nonparametric_bootstrap_mean_95",
                "ci_low": lo,
                "ci_high": hi,
            }
        )

    if not sensitivity_draws.empty:
        add_mean_interval(
            "local_weight_sensitivity",
            "top20_overlap_with_base",
            sensitivity_draws["top20_overlap_with_base"],
        )
    if not global_sensitivity_draws.empty:
        add_mean_interval(
            "global_simplex_sensitivity",
            "top20_overlap_with_base",
            global_sensitivity_draws["top20_overlap_with_base"],
        )
    if not hyperparameter_combos.empty:
        add_mean_interval(
            "hyperparameter_grid",
            "top20_score_overlap_with_base_OFST",
            hyperparameter_combos["top20_score_overlap_with_base_OFST"],
        )
        add_mean_interval(
            "hyperparameter_grid",
            "top20_prior_rank_overlap_with_base_OFST",
            hyperparameter_combos["top20_prior_rank_overlap_with_base_OFST"],
        )
    if not null_model_draws.empty:
        for null_name, group in null_model_draws.groupby("null_model"):
            add_mean_interval(
                f"null_model:{null_name}",
                "top20_overlap_with_base",
                group["top20_overlap_with_base"],
            )
            successes = float(group["top1_matches_base"].astype(bool).sum())
            lo, hi = wilson_interval(successes, float(len(group)))
            rows.append(
                {
                    "source": f"null_model:{null_name}",
                    "metric": "top1_match_rate",
                    "n": int(len(group)),
                    "estimate": float(successes / max(len(group), 1)),
                    "ci_method": "wilson_proportion_95",
                    "ci_low": lo,
                    "ci_high": hi,
                }
            )

    return pd.DataFrame(rows)


def hyperparameter_model_averaging(
    df: pd.DataFrame, config: RunConfig | None = None
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """
    Robustness analysis over O-metrics, score weights, eta values, and base priors.

    Two distinct quantities are reported and must not be conflated:

    * score-rank frequencies: rankings induced by S(U) only, averaged over
      O-metric variants and weight draws.
    * prior-rank frequencies and model-averaged prior mass: rankings and masses
      induced by the full Gibbs prior, averaged over O-metrics, weights, eta
      values, and base-prior choices.

    Class-level score-rank frequencies are computed under max, mean, and median
    aggregation across symmetry-class members, so the report exposes whether a
    class ranking depends on a single standout representative.
    """
    if config is None:
        config = RunConfig().validate()

    if "symmetry_class" not in df.columns:
        df, _ = add_symmetry_classes(df)

    work = df.sort_values("rule").reset_index(drop=True).copy()
    n = len(work)
    rules = work["rule"].to_numpy(dtype=int)
    classes = np.array(sorted(work["symmetry_class"].unique()), dtype=int)
    class_to_idx = {int(cid): i for i, cid in enumerate(classes)}
    class_indices = work["symmetry_class"].map(class_to_idx).to_numpy(dtype=int)
    n_classes = len(classes)

    metric_names = list(metric_registry().keys())
    weight_draws = model_averaging_weight_draws(config)
    eta_values = [float(v) for v in config.model_averaging_eta_grid]
    priors = base_prior_vectors(work)

    # Full-Gibbs prior aggregates over metric × weight × eta × base-prior combinations.
    prob_sum = np.zeros(n, dtype=float)
    prob_sq_sum = np.zeros(n, dtype=float)
    prior_top10_count = np.zeros(n, dtype=float)
    prior_top20_count = np.zeros(n, dtype=float)
    prior_rank_sum = np.zeros(n, dtype=float)
    prior_rank_sq_sum = np.zeros(n, dtype=float)

    class_prob_sum = np.zeros(n_classes, dtype=float)
    class_prob_sq_sum = np.zeros(n_classes, dtype=float)
    class_prior_top5_count = np.zeros(n_classes, dtype=float)
    class_prior_top10_count = np.zeros(n_classes, dtype=float)
    class_prior_rank_sum = np.zeros(n_classes, dtype=float)
    class_prior_rank_sq_sum = np.zeros(n_classes, dtype=float)

    # Score-rank aggregates over metric × weight combinations only.
    score_top10_count = np.zeros(n, dtype=float)
    score_top20_count = np.zeros(n, dtype=float)
    score_rank_sum = np.zeros(n, dtype=float)
    score_rank_sq_sum = np.zeros(n, dtype=float)

    class_score_top5_max_count = np.zeros(n_classes, dtype=float)
    class_score_top10_max_count = np.zeros(n_classes, dtype=float)
    class_score_rank_max_sum = np.zeros(n_classes, dtype=float)
    class_score_rank_max_sq_sum = np.zeros(n_classes, dtype=float)

    class_score_top5_mean_count = np.zeros(n_classes, dtype=float)
    class_score_top5_median_count = np.zeros(n_classes, dtype=float)

    combo_rows = []
    prior_combo_count = 0
    score_combo_count = 0

    base_score_order = np.lexsort((rules, -work["S"].to_numpy(dtype=float)))
    base_top20 = set(rules[base_score_order[:20]].astype(int).tolist())

    for metric_name in metric_names:
        o_values = work.apply(lambda row: alternative_o_score(row, metric_name), axis=1).to_numpy(dtype=float)

        for _, wrow in weight_draws.iterrows():
            w = np.array([wrow["w_C"], wrow["w_A"], wrow["w_O"], wrow["w_R"]], dtype=float)
            score = (
                w[0] * work["C"].to_numpy(dtype=float)
                + w[1] * work["A"].to_numpy(dtype=float)
                + w[2] * o_values
                - w[3] * work["R"].to_numpy(dtype=float)
            )

            score_order = np.lexsort((rules, -score))
            score_ranks = _rank_positions(score_order, n)
            score_top10_count[score_order[:10]] += 1
            score_top20_count[score_order[:20]] += 1
            score_rank_sum += score_ranks
            score_rank_sq_sum += score_ranks * score_ranks

            class_scores_max = np.full(n_classes, -np.inf, dtype=float)
            np.maximum.at(class_scores_max, class_indices, score)

            class_scores_mean = np.zeros(n_classes, dtype=float)
            class_counts = np.zeros(n_classes, dtype=float)
            np.add.at(class_scores_mean, class_indices, score)
            np.add.at(class_counts, class_indices, 1.0)
            class_scores_mean = class_scores_mean / np.maximum(class_counts, 1.0)

            class_scores_median = np.zeros(n_classes, dtype=float)
            for ci in range(n_classes):
                class_scores_median[ci] = float(np.median(score[class_indices == ci]))

            class_order_max = np.lexsort((classes, -class_scores_max))
            class_order_mean = np.lexsort((classes, -class_scores_mean))
            class_order_median = np.lexsort((classes, -class_scores_median))
            class_ranks_max = _rank_positions(class_order_max, n_classes)

            class_score_top5_max_count[class_order_max[:5]] += 1
            class_score_top10_max_count[class_order_max[:10]] += 1
            class_score_rank_max_sum += class_ranks_max
            class_score_rank_max_sq_sum += class_ranks_max * class_ranks_max
            class_score_top5_mean_count[class_order_mean[:5]] += 1
            class_score_top5_median_count[class_order_median[:5]] += 1

            score_top20 = set(rules[score_order[:20]].astype(int).tolist())
            score_overlap = float(len(base_top20 & score_top20) / 20.0)
            score_combo_count += 1

            for eta in eta_values:
                for prior_name, base_prior in priors.items():
                    probs = _gibbs_from_score(score, eta, base_prior)
                    prior_order = np.lexsort((rules, -probs))
                    prior_ranks = _rank_positions(prior_order, n)

                    prob_sum += probs
                    prob_sq_sum += probs * probs
                    prior_top10_count[prior_order[:10]] += 1
                    prior_top20_count[prior_order[:20]] += 1
                    prior_rank_sum += prior_ranks
                    prior_rank_sq_sum += prior_ranks * prior_ranks

                    class_probs = np.zeros(n_classes, dtype=float)
                    np.add.at(class_probs, class_indices, probs)
                    class_prior_order = np.lexsort((classes, -class_probs))
                    class_prior_ranks = _rank_positions(class_prior_order, n_classes)

                    class_prob_sum += class_probs
                    class_prob_sq_sum += class_probs * class_probs
                    class_prior_top5_count[class_prior_order[:5]] += 1
                    class_prior_top10_count[class_prior_order[:10]] += 1
                    class_prior_rank_sum += class_prior_ranks
                    class_prior_rank_sq_sum += class_prior_ranks * class_prior_ranks

                    prior_top20 = set(rules[prior_order[:20]].astype(int).tolist())
                    combo_rows.append(
                        {
                            "combo": prior_combo_count,
                            "score_combo": score_combo_count - 1,
                            "metric_variant": metric_name,
                            "weight_draw": int(wrow["draw"]),
                            "weight_draw_family": wrow["draw_family"],
                            "eta": float(eta),
                            "base_prior": prior_name,
                            "top20_score_overlap_with_base_OFST": score_overlap,
                            "top20_prior_rank_overlap_with_base_OFST": float(len(base_top20 & prior_top20) / 20.0),
                            "effective_model_count_ipr": float(1.0 / np.square(probs).sum()),
                            "top20_prior_mass_by_score_rank": float(probs[score_order[:20]].sum()),
                            "top20_prior_mass_by_prior_rank": float(probs[prior_order[:20]].sum()),
                        }
                    )
                    prior_combo_count += 1

    if prior_combo_count <= 0 or score_combo_count <= 0:
        raise ValueError("no hyperparameter combinations were evaluated")

    prior_denom = float(prior_combo_count)
    score_denom = float(score_combo_count)

    mean_score_rank = score_rank_sum / score_denom
    score_rank_var = np.maximum(0.0, score_rank_sq_sum / score_denom - mean_score_rank * mean_score_rank)

    mean_prior_rank = prior_rank_sum / prior_denom
    prior_rank_var = np.maximum(0.0, prior_rank_sq_sum / prior_denom - mean_prior_rank * mean_prior_rank)

    mean_prob = prob_sum / prior_denom
    prob_var = np.maximum(0.0, prob_sq_sum / prior_denom - mean_prob * mean_prob)

    rule_rows = []
    for i, rule in enumerate(rules):
        score_top20_freq = score_top20_count[i] / score_denom
        prior_top20_freq = prior_top20_count[i] / prior_denom
        score_top20_lo, score_top20_hi = wilson_interval(score_top20_count[i], score_denom)
        prior_top20_lo, prior_top20_hi = wilson_interval(prior_top20_count[i], prior_denom)
        score_top10_lo, score_top10_hi = wilson_interval(score_top10_count[i], score_denom)
        prior_top10_lo, prior_top10_hi = wilson_interval(prior_top10_count[i], prior_denom)
        rule_rows.append(
            {
                "rule": int(rule),
                "symmetry_class": int(work.loc[i, "symmetry_class"]),
                "model_averaged_prior_mass": float(mean_prob[i]),
                "prior_mass_sd": float(math.sqrt(prob_var[i])),
                "score_combo_count": int(score_combo_count),
                "prior_combo_count": int(prior_combo_count),
                "score_top10_frequency": float(score_top10_count[i] / score_denom),
                "score_top10_frequency_ci_low": score_top10_lo,
                "score_top10_frequency_ci_high": score_top10_hi,
                "score_top20_frequency": float(score_top20_freq),
                "score_top20_frequency_ci_low": score_top20_lo,
                "score_top20_frequency_ci_high": score_top20_hi,
                "score_mean_rank": float(mean_score_rank[i]),
                "score_rank_sd": float(math.sqrt(score_rank_var[i])),
                "prior_top10_frequency": float(prior_top10_count[i] / prior_denom),
                "prior_top10_frequency_ci_low": prior_top10_lo,
                "prior_top10_frequency_ci_high": prior_top10_hi,
                "prior_top20_frequency": float(prior_top20_freq),
                "prior_top20_frequency_ci_low": prior_top20_lo,
                "prior_top20_frequency_ci_high": prior_top20_hi,
                "prior_mean_rank": float(mean_prior_rank[i]),
                "prior_rank_sd": float(math.sqrt(prior_rank_var[i])),
                "robustness_label_score_top20": robustness_label(score_top20_freq),
                "robustness_label_prior_top20": robustness_label(prior_top20_freq),
            }
        )
    rule_df = (
        pd.DataFrame(rule_rows)
        .sort_values(["score_top20_frequency", "model_averaged_prior_mass", "rule"], ascending=[False, False, True])
        .reset_index(drop=True)
    )
    rule_df["robustness_rank"] = np.arange(1, len(rule_df) + 1)

    class_mean_score_rank = class_score_rank_max_sum / score_denom
    class_score_rank_var = np.maximum(0.0, class_score_rank_max_sq_sum / score_denom - class_mean_score_rank * class_mean_score_rank)

    class_mean_prior_rank = class_prior_rank_sum / prior_denom
    class_prior_rank_var = np.maximum(0.0, class_prior_rank_sq_sum / prior_denom - class_mean_prior_rank * class_mean_prior_rank)
    class_mean_prob = class_prob_sum / prior_denom
    class_prob_var = np.maximum(0.0, class_prob_sq_sum / prior_denom - class_mean_prob * class_mean_prob)
    class_members = work.groupby("symmetry_class")["rule"].apply(lambda x: json.dumps(sorted(x.astype(int).tolist()))).to_dict()

    class_rows = []
    for i, cid in enumerate(classes):
        score_top5_max = class_score_top5_max_count[i] / score_denom
        prior_top5 = class_prior_top5_count[i] / prior_denom
        score_top5_lo, score_top5_hi = wilson_interval(class_score_top5_max_count[i], score_denom)
        score_top10_lo, score_top10_hi = wilson_interval(class_score_top10_max_count[i], score_denom)
        prior_top5_lo, prior_top5_hi = wilson_interval(class_prior_top5_count[i], prior_denom)
        prior_top10_lo, prior_top10_hi = wilson_interval(class_prior_top10_count[i], prior_denom)
        score_top5_mean_lo, score_top5_mean_hi = wilson_interval(class_score_top5_mean_count[i], score_denom)
        score_top5_median_lo, score_top5_median_hi = wilson_interval(class_score_top5_median_count[i], score_denom)
        class_rows.append(
            {
                "symmetry_class": int(cid),
                "members": class_members[int(cid)],
                "model_averaged_prior_mass": float(class_mean_prob[i]),
                "prior_mass_sd": float(math.sqrt(class_prob_var[i])),
                "score_combo_count": int(score_combo_count),
                "prior_combo_count": int(prior_combo_count),
                "score_top5_frequency_max": float(score_top5_max),
                "score_top5_frequency_max_ci_low": score_top5_lo,
                "score_top5_frequency_max_ci_high": score_top5_hi,
                "score_top10_frequency_max": float(class_score_top10_max_count[i] / score_denom),
                "score_top10_frequency_max_ci_low": score_top10_lo,
                "score_top10_frequency_max_ci_high": score_top10_hi,
                "score_top5_frequency_mean": float(class_score_top5_mean_count[i] / score_denom),
                "score_top5_frequency_mean_ci_low": score_top5_mean_lo,
                "score_top5_frequency_mean_ci_high": score_top5_mean_hi,
                "score_top5_frequency_median": float(class_score_top5_median_count[i] / score_denom),
                "score_top5_frequency_median_ci_low": score_top5_median_lo,
                "score_top5_frequency_median_ci_high": score_top5_median_hi,
                "score_mean_rank_max": float(class_mean_score_rank[i]),
                "score_rank_sd_max": float(math.sqrt(class_score_rank_var[i])),
                "prior_top5_frequency": float(prior_top5),
                "prior_top5_frequency_ci_low": prior_top5_lo,
                "prior_top5_frequency_ci_high": prior_top5_hi,
                "prior_top10_frequency": float(class_prior_top10_count[i] / prior_denom),
                "prior_top10_frequency_ci_low": prior_top10_lo,
                "prior_top10_frequency_ci_high": prior_top10_hi,
                "prior_mean_rank": float(class_mean_prior_rank[i]),
                "prior_rank_sd": float(math.sqrt(class_prior_rank_var[i])),
                "robustness_label_score_top5_max": robustness_label(score_top5_max),
                "robustness_label_prior_top5": robustness_label(prior_top5),
            }
        )
    class_df = (
        pd.DataFrame(class_rows)
        .sort_values(["score_top5_frequency_max", "model_averaged_prior_mass", "symmetry_class"], ascending=[False, False, True])
        .reset_index(drop=True)
    )
    class_df["robustness_class_rank"] = np.arange(1, len(class_df) + 1)

    combo_df = pd.DataFrame(combo_rows)
    return rule_df, class_df, combo_df


def eta_sensitivity_analysis(df: pd.DataFrame, config: RunConfig | None = None) -> pd.DataFrame:
    """Show how eta changes concentration, not base score ordering."""
    if config is None:
        config = RunConfig().validate()
    work = df.sort_values("S", ascending=False).reset_index(drop=True)
    score = work["S"].to_numpy(dtype=float)
    prior = np.ones(len(work), dtype=float) / len(work)
    rows = []
    for eta in config.model_averaging_eta_grid:
        probs = _gibbs_from_score(score, float(eta), prior)
        entropy = float(-(probs * np.log(np.clip(probs, 1e-300, 1.0))).sum())
        rows.append(
            {
                "eta": float(eta),
                "top10_prior_mass": float(probs[:10].sum()),
                "top20_prior_mass": float(probs[:20].sum()),
                "effective_model_count_ipr": float(1.0 / np.square(probs).sum()),
                "effective_model_count_entropy": float(np.exp(entropy)),
            }
        )
    return pd.DataFrame(rows)


def base_prior_sensitivity_analysis(df: pd.DataFrame, config: RunConfig | None = None) -> pd.DataFrame:
    """Compare raw-rule-uniform and symmetry-class-uniform base priors."""
    if config is None:
        config = RunConfig().validate()
    if "symmetry_class" not in df.columns:
        df, _ = add_symmetry_classes(df)
    work = df.sort_values("rule").reset_index(drop=True)
    score = work["S"].to_numpy(dtype=float)
    priors = base_prior_vectors(work)
    rows = []
    for name, prior in priors.items():
        probs = _gibbs_from_score(score, config.eta, prior)
        order = np.lexsort((work["rule"].to_numpy(dtype=int), -probs))
        class_mass = pd.DataFrame({"symmetry_class": work["symmetry_class"], "prob": probs}).groupby("symmetry_class")["prob"].sum()
        rows.append(
            {
                "base_prior": name,
                "top10_rules_by_prior_probability": json.dumps(work.iloc[order[:10]]["rule"].astype(int).tolist()),
                "top20_prior_mass": float(probs[order[:20]].sum()),
                "effective_model_count_ipr": float(1.0 / np.square(probs).sum()),
                "top5_symmetry_classes_by_prior_mass": json.dumps(class_mass.sort_values(ascending=False).head(5).index.astype(int).tolist()),
            }
        )
    return pd.DataFrame(rows)


def _segmented_metric_score(row: pd.Series, segment: str, compression_window: float | None = None) -> float:
    """Base O proxy computed from early_*/late_* metric segment labels.

    The base trajectory-holdout proxy mirrors base O(U) and therefore excludes
    gzip compression. The optional compression_window is retained only so older
    callers can pass it without changing behavior.
    """
    tmp = {
        "entropy": row[f"{segment}_entropy"],
        "activity_balance": row[f"{segment}_activity_balance"],
        "time_mi": row[f"{segment}_time_mi"],
        "lag5_mi": row[f"{segment}_lag5_mi"],
        "spatial_mi": row[f"{segment}_spatial_mi"],
        "edge_balance": row[f"{segment}_edge_balance"],
    }
    if compression_window is not None:
        tmp["compression_window"] = compression_window
        tmp["complexity_window"] = compression_window
    return observer_support_proxy(pd.Series(tmp))


def _rank_correlation(x: np.ndarray, y: np.ndarray) -> float:
    """Spearman-style rank correlation using pandas average ranks."""
    rx = pd.Series(x).rank(method="average").to_numpy(dtype=float)
    ry = pd.Series(y).rank(method="average").to_numpy(dtype=float)
    if np.std(rx) <= 1e-12 or np.std(ry) <= 1e-12:
        return 0.0
    return float(np.corrcoef(rx, ry)[0, 1])


def trajectory_holdout_validation_analysis(df: pd.DataFrame, config: RunConfig | None = None) -> pd.DataFrame:
    """
    Trajectory-holdout diagnostic: can early-run structure predict late-run structure?

    This is still a toy validation, not empirical physics. It is a temporal holdout relative to the
    base score because the default S uses full-run metrics; here we ask whether
    metrics from the first half of each trajectory predict metrics from the
    second half.
    """
    if config is None:
        config = RunConfig().validate()
    work = df.copy()

    # Normalize early/late compression ratios separately to avoid importing the full-run A score.
    for segment in ["early", "late"]:
        ratio = work[f"{segment}_compression_ratio"]
        norm = (ratio - ratio.min()) / (ratio.max() - ratio.min() + 1e-12)
        work[f"{segment}_compression_window"] = 4.0 * norm * (1.0 - norm)
        work[f"{segment}_O_base"] = work.apply(lambda row: _segmented_metric_score(row, segment), axis=1)

    early = work["early_O_base"].to_numpy(dtype=float)
    late = work["late_O_base"].to_numpy(dtype=float)
    full = work["O"].to_numpy(dtype=float)
    stability = work["early_late_macro_stability"].to_numpy(dtype=float)

    early_top20 = set(work.sort_values("early_O_base", ascending=False).head(20)["rule"].astype(int).tolist())
    late_top20 = set(work.sort_values("late_O_base", ascending=False).head(20)["rule"].astype(int).tolist())
    full_top20 = set(work.sort_values("O", ascending=False).head(20)["rule"].astype(int).tolist())
    stable_top20 = set(work.sort_values("early_late_macro_stability", ascending=False).head(20)["rule"].astype(int).tolist())

    rows = [
        {
            "validation": "early_O_predicts_late_O_rank_correlation",
            "statistic": "spearman_rank_correlation",
            "value": _rank_correlation(early, late),
            "interpretation": "Higher is better; asks whether first-half information architecture predicts second-half information architecture.",
        },
        {
            "validation": "full_O_consistent_with_late_O_rank_correlation",
            "statistic": "spearman_rank_correlation",
            "value": _rank_correlation(full, late),
            "interpretation": "Sanity check; full-run O should correlate with late-run O because they share trajectory information.",
        },
        {
            "validation": "early_O_top20_overlap_with_late_O_top20",
            "statistic": "overlap_fraction",
            "value": len(early_top20 & late_top20) / 20.0,
            "interpretation": "Fraction of early top-20 O rules that remain late top-20 O rules.",
        },
        {
            "validation": "full_O_top20_overlap_with_late_O_top20",
            "statistic": "overlap_fraction",
            "value": len(full_top20 & late_top20) / 20.0,
            "interpretation": "Full-run O overlap with late-run O; useful upper-context diagnostic.",
        },
        {
            "validation": "early_O_top20_overlap_with_macro_stability_top20",
            "statistic": "overlap_fraction",
            "value": len(early_top20 & stable_top20) / 20.0,
            "interpretation": "Whether early structural richness also selects early-to-late macro-stable rules.",
        },
        {
            "validation": "late_O_predicts_macro_stability_rank_correlation",
            "statistic": "spearman_rank_correlation",
            "value": _rank_correlation(late, stability),
            "interpretation": "Checks whether late information architecture aligns with explicit early-to-late macro-stability.",
        },
    ]
    return pd.DataFrame(rows)


def write_claim_ledger(
    results_dir: Path,
    rule_robustness: pd.DataFrame,
    class_robustness: pd.DataFrame,
    trajectory_holdout: pd.DataFrame,
    combo_summary: pd.DataFrame,
) -> None:
    """Write a compact claim ledger separating robust, partial, and unsupported claims."""
    top_classes = class_robustness.head(10)
    robust_classes = top_classes[top_classes["score_top5_frequency_max"] > 0.70]
    suggestive_classes = top_classes[
        (top_classes["score_top5_frequency_max"] > 0.50) & (top_classes["score_top5_frequency_max"] <= 0.70)
    ]
    top_rules = rule_robustness.head(10)

    early_late_corr = float(
        trajectory_holdout.loc[
            trajectory_holdout["validation"] == "early_O_predicts_late_O_rank_correlation", "value"
        ].iloc[0]
    )
    mean_score_overlap = float(combo_summary["top20_score_overlap_with_base_OFST"].mean())
    mean_prior_overlap = float(combo_summary["top20_prior_rank_overlap_with_base_OFST"].mean())

    lines = [
        "# Claim Ledger",
        "",
        "This ledger summarizes the robustness layer and uses conservative claim language.",
        "",
        "## Robust claims",
    ]

    if len(robust_classes):
        lines.append(
            "- At least one symmetry class remains a top-5 score-ranked candidate across more than 70% of metric/weight combinations under max-member class aggregation."
        )
        for _, row in robust_classes.iterrows():
            lines.append(
                f"  - class {int(row['symmetry_class'])}: score-top-5 frequency {float(row['score_top5_frequency_max']):.3f}, "
                f"prior-top-5 frequency {float(row['prior_top5_frequency']):.3f}, "
                f"model-averaged mass {float(row['model_averaged_prior_mass']):.6f}, members {row['members']}"
            )
    else:
        lines.append("- No symmetry class exceeds the conservative score-top-5 robustness threshold of 0.70.")

    lines.extend(
        [
            "",
            "## Suggestive or partial claims",
            f"- Mean score-ranked top-20 overlap with the declared base-score top-20 is {mean_score_overlap:.3f}.",
            f"- Mean prior-ranked top-20 overlap with the declared base-score top-20 is {mean_prior_overlap:.3f}.",
            f"- Early-run O-proxy to late-run O-proxy rank correlation is {early_late_corr:.3f}. This is a trajectory-holdout toy diagnostic, not empirical physics.",
        ]
    )
    for _, row in suggestive_classes.iterrows():
        lines.append(
            f"  - class {int(row['symmetry_class'])}: score-top-5 frequency {float(row['score_top5_frequency_max']):.3f}, "
            f"mean-aggregation top-5 frequency {float(row['score_top5_frequency_mean']):.3f}, "
            f"median-aggregation top-5 frequency {float(row['score_top5_frequency_median']):.3f}"
        )

    lines.extend(
        [
            "",
            "## Unsupported or out-of-scope claims",
            "- The identity of the single top raw ECA rule should not be treated as robust physical content.",
            "- The base O(U) metric is not claimed to be uniquely correct.",
            "- The ECA demonstration is not evidence that OFST is a physical law-selection principle.",
            "- Class rankings based on max-member aggregation should be compared against mean and median aggregation columns before making class-level claims.",
            "",
            "Top raw rules by score-top-20 frequency:",
        ]
    )
    for _, row in top_rules.iterrows():
        lines.append(
            f"- rule {int(row['rule'])} / class {int(row['symmetry_class'])}: "
            f"score-top-20 frequency {float(row['score_top20_frequency']):.3f}, "
            f"prior-top-20 frequency {float(row['prior_top20_frequency']):.3f}, "
            f"label {row['robustness_label_score_top20']}"
        )

    (results_dir / "claim_ledger.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def rule_bits(rule: int) -> np.ndarray:
    """Return the eight output bits for ECA neighborhood indices 0..7."""
    return np.array([(rule >> i) & 1 for i in range(8)], dtype=np.uint8)


def rule_from_bits(bits: np.ndarray) -> int:
    """Build an ECA rule integer from output bits indexed 0..7."""
    return int(sum(int(bits[i]) << i for i in range(8)))


def reflect_rule(rule: int) -> int:
    """Reflect left and right neighbors in the ECA local rule."""
    bits = rule_bits(rule)
    reflected = np.zeros(8, dtype=np.uint8)
    for idx in range(8):
        left = (idx >> 2) & 1
        center = (idx >> 1) & 1
        right = idx & 1
        reflected_idx = (right << 2) | (center << 1) | left
        reflected[idx] = bits[reflected_idx]
    return rule_from_bits(reflected)


def conjugate_rule(rule: int) -> int:
    """Apply black-white state conjugacy to an ECA rule."""
    bits = rule_bits(rule)
    conjugated = np.zeros(8, dtype=np.uint8)
    for idx in range(8):
        left = (idx >> 2) & 1
        center = (idx >> 1) & 1
        right = idx & 1
        complemented_idx = ((1 - left) << 2) | ((1 - center) << 1) | (1 - right)
        conjugated[idx] = 1 - bits[complemented_idx]
    return rule_from_bits(conjugated)


def symmetry_orbit(rule: int) -> list[int]:
    """Return the reflection/conjugacy orbit of an ECA rule."""
    orbit = set()
    frontier = {int(rule)}
    while frontier:
        r = frontier.pop()
        if r in orbit:
            continue
        orbit.add(r)
        frontier.add(reflect_rule(r))
        frontier.add(conjugate_rule(r))
    return sorted(orbit)


def add_symmetry_classes(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Add ECA reflection/black-white-conjugacy classes.

    Raw ECA rankings can overstate independence because several rules represent
    the same dynamics up to spatial reflection or state relabeling. Class-level
    reporting makes the toy result more conservative.
    """
    class_id = {rule: min(symmetry_orbit(rule)) for rule in range(256)}
    df = df.copy()
    df["symmetry_class"] = df["rule"].map(class_id)

    class_rows = []
    for cid, group in df.groupby("symmetry_class", sort=True):
        members = sorted(group["rule"].astype(int).tolist())
        top_group = group.sort_values("S", ascending=False).iloc[0]
        class_rows.append(
            {
                "symmetry_class": int(cid),
                "members": json.dumps(members),
                "n_members": int(len(members)),
                "top_rule": int(top_group["rule"]),
                "best_rank_OFST": int(group["rank_OFST"].min()),
                "max_S": float(group["S"].max()),
                "mean_S": float(group["S"].mean()),
                "gibbs_mass": float(group["gibbs_weight"].sum()),
                "n_rules_in_top20": int((group["rank_OFST"] <= 20).sum()),
            }
        )

    class_df = (
        pd.DataFrame(class_rows)
        .sort_values(["best_rank_OFST", "max_S", "symmetry_class"], ascending=[True, False, True])
        .reset_index(drop=True)
    )
    class_df["class_rank_OFST"] = np.arange(1, len(class_df) + 1)
    return df, class_df


def gibbs_concentration_stats(df: pd.DataFrame) -> dict[str, float]:
    """Summarize how concentrated the finite-ensemble Gibbs prior is."""
    ranked = df.sort_values("S", ascending=False).reset_index(drop=True)
    weights = ranked["gibbs_weight"].to_numpy(dtype=float)
    entropy = float(-(weights * np.log(np.clip(weights, 1e-300, 1.0))).sum())
    return {
        "gibbs_mass_top10": float(ranked.head(10)["gibbs_weight"].sum()),
        "gibbs_mass_top20": float(ranked.head(20)["gibbs_weight"].sum()),
        "effective_model_count_ipr": float(1.0 / np.square(weights).sum()),
        "effective_model_count_entropy": float(np.exp(entropy)),
        "top1_minus_top2_score_margin": float(ranked.loc[0, "S"] - ranked.loc[1, "S"]),
        "top1_minus_top10_score_margin": float(ranked.loc[0, "S"] - ranked.loc[9, "S"]),
    }


def _rank_summary_row(
    df: pd.DataFrame,
    class_rankings: pd.DataFrame,
    base_top20: set[int],
    label: str,
    seed: int,
    n_cells: int,
    n_steps: int,
) -> dict:
    """Compact ranking summary used by seed and size sensitivity checks."""
    ranked = df.sort_values("S", ascending=False).reset_index(drop=True)
    top20 = set(ranked.head(20)["rule"].astype(int).tolist())
    top10 = ranked.head(10)["rule"].astype(int).tolist()
    stats = gibbs_concentration_stats(df)
    return {
        "label": label,
        "seed": int(seed),
        "n_cells": int(n_cells),
        "n_steps": int(n_steps),
        "top1_rule": int(ranked.loc[0, "rule"]),
        "top1_symmetry_class": int(ranked.loc[0, "symmetry_class"]),
        "top10_rules": json.dumps(top10),
        "top5_symmetry_classes": json.dumps(class_rankings.head(5)["symmetry_class"].astype(int).tolist()),
        "top20_overlap_with_base": float(len(base_top20 & top20) / 20.0),
        "gibbs_mass_top20": float(stats["gibbs_mass_top20"]),
        "effective_model_count_ipr": float(stats["effective_model_count_ipr"]),
        "top1_minus_top2_score_margin": float(stats["top1_minus_top2_score_margin"]),
    }


def seed_sensitivity_analysis(
    base_df: pd.DataFrame,
    base_class_rankings: pd.DataFrame,
    config: RunConfig,
) -> pd.DataFrame:
    """Recompute rankings under adjacent random seeds without changing declared weights."""
    base_top20 = set(base_df.sort_values("S", ascending=False).head(20)["rule"].astype(int).tolist())
    rows = []
    for offset in range(config.seed_sensitivity_runs):
        seed = config.seed + offset
        label = f"seed_{seed}"
        if offset == 0:
            df = base_df
            class_rankings = base_class_rankings
        else:
            seed_config = replace(config, seed=seed)
            df, _ = compute_metrics(seed_config)
            df, class_rankings = add_symmetry_classes(df)
        rows.append(
            _rank_summary_row(
                df=df,
                class_rankings=class_rankings,
                base_top20=base_top20,
                label=label,
                seed=seed,
                n_cells=config.n_cells,
                n_steps=config.n_steps,
            )
        )
    return pd.DataFrame(rows)


def _size_sensitivity_scales(config: RunConfig) -> list[tuple[int, int]]:
    """Default scale checks: release-scale checks for default runs, relative scales for custom runs."""
    if config.n_cells == DEFAULT_N_CELLS and config.n_steps == DEFAULT_N_STEPS:
        return DEFAULT_SIZE_SENSITIVITY_SCALES.copy()
    small = (max(8, int(round(config.n_cells * 0.75))), max(8, int(round(config.n_steps * 0.75))))
    base = (int(config.n_cells), int(config.n_steps))
    large = (max(base[0] + 1, int(round(config.n_cells * 1.25))), max(base[1] + 1, int(round(config.n_steps * 1.25))))
    return [small, base, large]


def size_sensitivity_analysis(
    base_df: pd.DataFrame,
    base_class_rankings: pd.DataFrame,
    config: RunConfig,
) -> pd.DataFrame:
    """Recompute rankings at neighboring finite ECA grid/time scales."""
    base_top20 = set(base_df.sort_values("S", ascending=False).head(20)["rule"].astype(int).tolist())
    rows = []
    for n_cells, n_steps in _size_sensitivity_scales(config):
        label = f"{n_cells}x{n_steps}"
        if n_cells == config.n_cells and n_steps == config.n_steps:
            df = base_df
            class_rankings = base_class_rankings
        else:
            scale_config = replace(config, n_cells=int(n_cells), n_steps=int(n_steps))
            df, _ = compute_metrics(scale_config)
            df, class_rankings = add_symmetry_classes(df)
        rows.append(
            _rank_summary_row(
                df=df,
                class_rankings=class_rankings,
                base_top20=base_top20,
                label=label,
                seed=config.seed,
                n_cells=int(n_cells),
                n_steps=int(n_steps),
            )
        )
    return pd.DataFrame(rows)




def reference_eca_baselines() -> pd.DataFrame:
    """Hand-declared reference ECA families used as external diagnostics.

    These are not labels learned by OFST and are not used in the base score.
    They simply make it easier to see whether the ranking overlaps familiar
    toy-dynamics families.
    """
    rows = [
        {
            "baseline": "constant_rules",
            "rules": json.dumps([0, 255]),
            "description": "Immediate all-zero or all-one evolution.",
        },
        {
            "baseline": "identity_and_complement",
            "rules": json.dumps([204, 51]),
            "description": "Identity and bit-complement reference rules.",
        },
        {
            "baseline": "additive_linear_reference",
            "rules": json.dumps([60, 90, 102, 105, 150, 153, 165, 195]),
            "description": "Common linear/additive ECA references over GF(2).",
        },
        {
            "baseline": "classic_complex_references",
            "rules": json.dumps([30, 45, 73, 110]),
            "description": "Frequently discussed complex/chaotic/universal ECA references; rule 110 is computationally universal.",
        },
        {
            "baseline": "traffic_shift_references",
            "rules": json.dumps([170, 184, 240]),
            "description": "Shift/traffic-like references including rule 184.",
        },
        {
            "baseline": "single_site_impulse_favorites",
            "rules": json.dumps(DEFAULT_SELECTED_FIGURE_RULES),
            "description": "Rules commonly plotted by this package for impulse-response inspection.",
        },
    ]
    return pd.DataFrame(rows)


def reference_baseline_overlap(df: pd.DataFrame) -> pd.DataFrame:
    """Compare OFST top ranks with hand-declared ECA reference families."""
    ranked = df.sort_values("S", ascending=False).reset_index(drop=True)
    top10 = set(ranked.head(10)["rule"].astype(int).tolist())
    top20 = set(ranked.head(20)["rule"].astype(int).tolist())
    top50 = set(ranked.head(50)["rule"].astype(int).tolist())

    rows = []
    for _, row in reference_eca_baselines().iterrows():
        rules = set(json.loads(row["rules"]))
        ranks = [
            int(ranked.index[ranked["rule"].astype(int) == rule][0] + 1)
            for rule in sorted(rules)
            if rule in set(ranked["rule"].astype(int))
        ]
        rows.append(
            {
                "baseline": row["baseline"],
                "n_rules": int(len(rules)),
                "rules": row["rules"],
                "description": row["description"],
                "top10_overlap": int(len(rules & top10)),
                "top20_overlap": int(len(rules & top20)),
                "top50_overlap": int(len(rules & top50)),
                "best_OFST_rank": int(min(ranks)) if ranks else None,
                "median_OFST_rank": float(np.median(ranks)) if ranks else None,
            }
        )
    return pd.DataFrame(rows)


def metric_correlation_analysis(df: pd.DataFrame) -> pd.DataFrame:
    """Spearman-style rank correlations among score components and diagnostics."""
    candidates = [
        "S",
        "A",
        "O",
        "R",
        "entropy",
        "activity_balance",
        "spatial_mi",
        "time_mi",
        "lag5_mi",
        "edge_balance",
        "block_entropy_2",
        "block_entropy_3",
        "block_entropy_4",
        "lz_complexity",
        "temporal_excess_entropy_proxy",
        "compression_ratio",
        "compression_window",
        "early_late_macro_stability",
    ]
    cols = [c for c in candidates if c in df.columns]
    ranks = df[cols].rank(method="average")
    corr = ranks.corr(method="pearson").fillna(0.0)

    rows = []
    for left in cols:
        for right in cols:
            if left >= right:
                continue
            rows.append(
                {
                    "metric_x": left,
                    "metric_y": right,
                    "spearman_rank_correlation": float(corr.loc[left, right]),
                }
            )
    return pd.DataFrame(rows).sort_values(
        "spearman_rank_correlation", ascending=False
    ).reset_index(drop=True)


def _score_from_components(df: pd.DataFrame, weights: dict[str, float], A: np.ndarray, O: np.ndarray, R: np.ndarray) -> np.ndarray:
    """Score helper for null-model diagnostics."""
    return weights["C"] * df["C"].to_numpy(dtype=float) + weights["A"] * A + weights["O"] * O - weights["R"] * R


def null_model_analysis(df: pd.DataFrame, config: RunConfig) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Generate null diagnostics for top-list stability.

    The nulls are negative controls. They preserve different amounts of the
    observed finite-run structure while breaking the direct rule-to-score
    assignment in different ways. They are not empirical validation.
    """
    draws = int(config.null_model_draws)
    draw_columns = [
        "draw",
        "null_model",
        "top1_rule",
        "top20_overlap_with_base",
        "top1_matches_base",
        "score_rank_correlation_with_base",
    ]
    summary_columns = [
        "null_model",
        "n_draws",
        "mean_top20_overlap_with_base",
        "median_top20_overlap_with_base",
        "max_top20_overlap_with_base",
        "top1_match_rate",
        "mean_score_rank_correlation_with_base",
    ]
    if draws == 0:
        return pd.DataFrame(columns=draw_columns), pd.DataFrame(columns=summary_columns)

    work = df.sort_values("rule").reset_index(drop=True).copy()
    rng = np.random.default_rng(config.seed + 707)

    base_ranked = work.sort_values("S", ascending=False).reset_index(drop=True)
    base_top20 = set(base_ranked.head(20)["rule"].astype(int).tolist())
    base_top1 = int(base_ranked.loc[0, "rule"])
    base_score = work["S"].to_numpy(dtype=float)
    base_score_rank = pd.Series(base_score).rank(method="average").to_numpy(dtype=float)
    weights = config.weights

    rows = []
    rule_values = work["rule"].astype(int).to_numpy()
    A = work["A"].to_numpy(dtype=float)
    O = work["O"].to_numpy(dtype=float)
    R = work["R"].to_numpy(dtype=float)
    score_by_rule = dict(zip(rule_values, base_score))

    if "symmetry_class" in work.columns:
        orbit_sizes = work.groupby("symmetry_class")["rule"].transform("count").to_numpy(dtype=int)
    else:
        orbit_sizes = np.ones(len(work), dtype=int)

    def append_null(draw: int, null_name: str, score: np.ndarray) -> None:
        tmp = pd.DataFrame({"rule": rule_values, "score": score})
        ranked = tmp.sort_values("score", ascending=False).reset_index(drop=True)
        top20 = set(ranked.head(20)["rule"].astype(int).tolist())
        score_rank = pd.Series(score).rank(method="average").to_numpy(dtype=float)
        corr = float(np.corrcoef(base_score_rank, score_rank)[0, 1])
        if not np.isfinite(corr):
            corr = 0.0
        rows.append(
            {
                "draw": int(draw),
                "null_model": null_name,
                "top1_rule": int(ranked.loc[0, "rule"]),
                "top20_overlap_with_base": float(len(base_top20 & top20) / 20.0),
                "top1_matches_base": bool(int(ranked.loc[0, "rule"]) == base_top1),
                "score_rank_correlation_with_base": corr,
            }
        )

    for draw in range(draws):
        # Break all rule-score association while preserving the marginal score distribution.
        append_null(draw, "score_label_permutation", rng.permutation(base_score))

        # Break component-to-rule association and component covariance.
        independent_component_score = _score_from_components(
            work,
            weights,
            rng.permutation(A),
            rng.permutation(O),
            rng.permutation(R),
        )
        append_null(draw, "independent_component_permutation", independent_component_score)

        # Preserve the empirical A/O/R covariance by permuting complete component rows.
        tuple_perm = rng.permutation(len(work))
        row_tuple_component_score = _score_from_components(
            work,
            weights,
            A[tuple_perm],
            O[tuple_perm],
            R[tuple_perm],
        )
        append_null(draw, "component_tuple_permutation", row_tuple_component_score)

        # Preserve orbit-size strata while detaching exact rule labels from scores.
        orbit_size_score = base_score.copy()
        for size in np.unique(orbit_sizes):
            idx = np.where(orbit_sizes == size)[0]
            orbit_size_score[idx] = rng.permutation(orbit_size_score[idx])
        append_null(draw, "orbit_size_preserving_score_permutation", orbit_size_score)

        # Local rule-table null: each rule receives the score of a random Hamming-distance-1 neighbor.
        neighbor_score = np.empty_like(base_score)
        for i, rule in enumerate(rule_values):
            bit = int(rng.integers(0, 8))
            neighbor = int(rule) ^ (1 << bit)
            neighbor_score[i] = score_by_rule[neighbor]
        append_null(draw, "hamming_neighbor_score_substitution", neighbor_score)

    draws_df = pd.DataFrame(rows, columns=draw_columns)
    summary_rows = []
    interval_rng = np.random.default_rng(config.seed + 808)
    for null_name, group in draws_df.groupby("null_model"):
        overlap_lo, overlap_hi = bootstrap_mean_interval(
            group["top20_overlap_with_base"],
            interval_rng,
            config.bootstrap_draws,
        )
        rank_corr_lo, rank_corr_hi = bootstrap_mean_interval(
            group["score_rank_correlation_with_base"],
            interval_rng,
            config.bootstrap_draws,
        )
        top1_successes = float(group["top1_matches_base"].astype(bool).sum())
        top1_lo, top1_hi = wilson_interval(top1_successes, float(len(group)))
        summary_rows.append(
            {
                "null_model": null_name,
                "n_draws": int(len(group)),
                "mean_top20_overlap_with_base": float(group["top20_overlap_with_base"].mean()),
                "mean_top20_overlap_ci_low": overlap_lo,
                "mean_top20_overlap_ci_high": overlap_hi,
                "median_top20_overlap_with_base": float(group["top20_overlap_with_base"].median()),
                "max_top20_overlap_with_base": float(group["top20_overlap_with_base"].max()),
                "top1_match_rate": float(group["top1_matches_base"].mean()),
                "top1_match_rate_ci_low": top1_lo,
                "top1_match_rate_ci_high": top1_hi,
                "mean_score_rank_correlation_with_base": float(group["score_rank_correlation_with_base"].mean()),
                "mean_score_rank_correlation_ci_low": rank_corr_lo,
                "mean_score_rank_correlation_ci_high": rank_corr_hi,
            }
        )
    summary = pd.DataFrame(summary_rows).sort_values("null_model").reset_index(drop=True)
    return draws_df, summary


def environment_metadata(config: RunConfig) -> dict:
    """Record reproducibility-relevant runtime metadata."""
    return {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "python": sys.version,
        "python_executable": sys.executable,
        "platform": platform.platform(),
        "processor": platform.processor(),
        "numpy": np.__version__,
        "pandas": pd.__version__,
        "matplotlib": getattr(plt.matplotlib, "__version__", "unknown"),
        "run_profile": config.run_profile,
        "note": "Environment metadata is informational; results are determined by the package code, configuration, and random seed.",
    }


def save_figures(
    df: pd.DataFrame,
    sample_histories: dict[int, np.ndarray],
    sens: pd.DataFrame,
    global_sens: pd.DataFrame,
    out_dir: Path,
    size_sens: pd.DataFrame | None = None,
) -> None:
    """Save publication-supporting diagnostic figures."""
    out_dir.mkdir(parents=True, exist_ok=True)

    top = df.sort_values("S", ascending=False).head(15)
    plt.figure(figsize=(8, 5))
    plt.bar(top["rule"].astype(str), top["S"])
    plt.xlabel("ECA rule")
    plt.ylabel("OFST stability score S")
    plt.title("Top 15 finite toy universes under OFST weighting")
    plt.tight_layout()
    plt.savefig(out_dir / "ofst_top15_stability_scores.png", dpi=220)
    plt.close()

    plt.figure(figsize=(7, 5))
    plt.scatter(df["A"], df["O"], s=24)
    plt.xlabel("Finite-trajectory gzip-compressibility score A")
    plt.ylabel("Persistent-structure proxy O")
    plt.title("Compressibility vs persistent-structure proxy across all 256 ECA rules")
    plt.tight_layout()
    plt.savefig(out_dir / "compressibility_vs_persistent_structure.png", dpi=220)
    plt.close()

    plt.figure(figsize=(7, 5))
    plt.hist(df["gibbs_weight"], bins=30)
    plt.xlabel("Gibbs prior weight")
    plt.ylabel("Count")
    plt.title("OFST Gibbs-weight distribution over finite ensemble")
    plt.tight_layout()
    plt.savefig(out_dir / "gibbs_weight_distribution.png", dpi=220)
    plt.close()

    plt.figure(figsize=(7, 5))
    plt.hist(sens["top20_overlap_with_base"], bins=20)
    plt.xlabel("Top-20 overlap with base weights")
    plt.ylabel("Perturbed-weight draws")
    plt.title("Local ±25% weight-perturbation sensitivity")
    plt.tight_layout()
    plt.savefig(out_dir / "sensitivity_top20_overlap.png", dpi=220)
    plt.close()

    plt.figure(figsize=(7, 5))
    plt.hist(global_sens["top20_overlap_with_base"], bins=20)
    plt.xlabel("Top-20 overlap with base weights")
    plt.ylabel("Simplex-weight draws")
    plt.title("Broad simplex-weight sensitivity")
    plt.tight_layout()
    plt.savefig(out_dir / "global_simplex_top20_overlap.png", dpi=220)
    plt.close()

    if size_sens is not None and not size_sens.empty:
        plt.figure(figsize=(7, 5))
        x = np.arange(len(size_sens))
        plt.plot(x, size_sens["top20_overlap_with_base"], marker="o")
        plt.xticks(x, size_sens["label"], rotation=30, ha="right")
        plt.ylim(0, 1.05)
        plt.xlabel("Finite run size")
        plt.ylabel("Top-20 overlap with base run")
        plt.title("Finite-size ranking stability diagnostic")
        plt.tight_layout()
        plt.savefig(out_dir / "finite_size_ranking_stability.png", dpi=220)
        plt.close()

    for rule, H in sample_histories.items():
        plt.figure(figsize=(5.6, 5.6))
        plt.imshow(H, interpolation="nearest", aspect="auto", cmap="binary")
        plt.xlabel("Cell index")
        plt.ylabel("Time step")
        plt.title(f"ECA rule {rule}: single-impulse spacetime history")
        plt.tight_layout()
        plt.savefig(out_dir / f"eca_rule_{rule}_spacetime.png", dpi=220)
        plt.close()


def save_config_snapshot(config: RunConfig, results_dir: Path) -> None:
    """Persist exact run configuration and CLI-relevant defaults."""
    payload = asdict(config)
    payload["weight_sum"] = float(sum(config.weights.values()))
    payload["interpretation"] = (
        "Weights define a Gibbs-style stability prior over the declared finite ensemble; "
        "they are not an empirical posterior unless combined with a likelihood."
    )
    with open(results_dir / "config_snapshot.json", "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)


def run(config: RunConfig) -> dict:
    """Run the complete deterministic demonstration and return the summary dictionary."""
    repo = Path(__file__).resolve().parents[1]
    results_dir = repo / config.output_results_dir
    figures_dir = repo / config.output_figures_dir
    results_dir.mkdir(parents=True, exist_ok=True)
    figures_dir.mkdir(parents=True, exist_ok=True)

    save_config_snapshot(config, results_dir)

    df, sample_histories = compute_metrics(config)
    sens, freq = sensitivity_analysis(df, config=config)
    global_sens = global_simplex_sensitivity(df, config=config)
    ablations = ablation_analysis(df, config)
    df, class_rankings = add_symmetry_classes(df)
    o_sens = o_metric_sensitivity(df, config)
    rule_robustness, class_robustness, hyperparameter_combos = hyperparameter_model_averaging(df, config)
    eta_sens = eta_sensitivity_analysis(df, config)
    base_prior_sens = base_prior_sensitivity_analysis(df, config)
    trajectory_holdout = trajectory_holdout_validation_analysis(df, config)
    seed_sens = seed_sensitivity_analysis(df, class_rankings, config)
    size_sens = size_sensitivity_analysis(df, class_rankings, config)
    reference_baselines = reference_eca_baselines()
    baseline_overlap = reference_baseline_overlap(df)
    metric_corr = metric_correlation_analysis(df)
    null_draws, null_summary = null_model_analysis(df, config)
    uncertainty_summary = uncertainty_summary_table(sens, global_sens, hyperparameter_combos, null_draws, config)
    env_meta = environment_metadata(config)

    rank_cols = [
        "rule",
        "symmetry_class",
        "rank_OFST",
        "rank_A_only",
        "rank_O_only",
        "rank_low_fragility",
        "S",
        "gibbs_weight",
        "C",
        "A",
        "O",
        "R",
        "density",
        "entropy",
        "activity",
        "activity_balance",
        "spatial_mi",
        "time_mi",
        "lag5_mi",
        "edge_density",
        "edge_balance",
        "block_entropy_2",
        "block_entropy_3",
        "block_entropy_4",
        "lz_complexity",
        "temporal_excess_entropy_proxy",
        "compression_ratio",
        "compression_window",
        "complexity_window",
        "early_late_macro_distance",
        "early_late_macro_stability",
        "early_entropy",
        "early_activity_balance",
        "early_spatial_mi",
        "early_time_mi",
        "early_lag5_mi",
        "early_block_entropy_4",
        "early_lz_complexity",
        "early_temporal_excess_entropy_proxy",
        "early_compression_ratio",
        "late_entropy",
        "late_activity_balance",
        "late_spatial_mi",
        "late_time_mi",
        "late_lag5_mi",
        "late_block_entropy_4",
        "late_lz_complexity",
        "late_temporal_excess_entropy_proxy",
        "late_compression_ratio",
    ]

    df[rank_cols].to_csv(results_dir / "eca_metrics.csv", index=False)
    df.sort_values("S", ascending=False)[rank_cols].to_csv(results_dir / "ofst_rankings.csv", index=False)
    df.sort_values("S", ascending=False).head(20)[rank_cols].to_csv(results_dir / "top20_ofst.csv", index=False)
    sens.to_csv(results_dir / "sensitivity_weight_draws.csv", index=False)
    freq.to_csv(results_dir / "sensitivity_rule_frequencies.csv", index=False)
    global_sens.to_csv(results_dir / "global_simplex_sensitivity.csv", index=False)
    seed_sens.to_csv(results_dir / "seed_sensitivity.csv", index=False)
    size_sens.to_csv(results_dir / "size_sensitivity.csv", index=False)
    ablations.to_csv(results_dir / "ablation_summary.csv", index=False)
    o_sens.to_csv(results_dir / "o_metric_sensitivity.csv", index=False)
    rule_robustness.to_csv(results_dir / "metric_robustness_rules.csv", index=False)
    class_robustness.to_csv(results_dir / "metric_robustness_classes.csv", index=False)
    rule_robustness.to_csv(results_dir / "hyperparameter_model_average.csv", index=False)
    hyperparameter_combos.to_csv(results_dir / "hyperparameter_combo_summary.csv", index=False)
    eta_sens.to_csv(results_dir / "eta_sensitivity.csv", index=False)
    base_prior_sens.to_csv(results_dir / "base_prior_sensitivity.csv", index=False)
    trajectory_holdout.to_csv(results_dir / "trajectory_holdout_validation.csv", index=False)
    reference_baselines.to_csv(results_dir / "reference_eca_baselines.csv", index=False)
    baseline_overlap.to_csv(results_dir / "reference_baseline_overlap.csv", index=False)
    metric_corr.to_csv(results_dir / "metric_correlations.csv", index=False)
    null_draws.to_csv(results_dir / "null_model_draws.csv", index=False)
    null_summary.to_csv(results_dir / "null_model_summary.csv", index=False)
    uncertainty_summary.to_csv(results_dir / "uncertainty_summary.csv", index=False)
    with open(results_dir / "environment.json", "w", encoding="utf-8") as f:
        json.dump(env_meta, f, indent=2)
    with open(results_dir / "metric_registry.json", "w", encoding="utf-8") as f:
        json.dump(metric_registry(), f, indent=2)
    write_claim_ledger(results_dir, rule_robustness, class_robustness, trajectory_holdout, hyperparameter_combos)
    df[["rule", "symmetry_class"]].sort_values("rule").to_csv(results_dir / "eca_symmetry_classes.csv", index=False)
    class_rankings.to_csv(results_dir / "ofst_class_rankings.csv", index=False)

    concentration = gibbs_concentration_stats(df)

    summary = {
        "ensemble": "elementary cellular automata, rules 0-255",
        "n_models": int(len(df)),
        "seed": config.seed,
        "n_cells": config.n_cells,
        "n_steps": config.n_steps,
        "n_random_initial_conditions": config.n_random_initial_conditions,
        "n_fragility_initial_conditions": config.n_fragility_initial_conditions,
        "weights": config.weights,
        "weight_sum": float(sum(config.weights.values())),
        "eta": config.eta,
        "run_profile": config.run_profile,
        "null_model_draws": int(config.null_model_draws),
        "bootstrap_draws": int(config.bootstrap_draws),
        "generated_at_utc": env_meta["generated_at_utc"],
        "interpretation_note": "gibbs_weight is a stability-weighted prior over the declared ensemble, not an empirical posterior.",
        "top10_OFST_rules": df.sort_values("S", ascending=False).head(10)["rule"].astype(int).tolist(),
        "top10_A_only_rules": df.sort_values("A", ascending=False).head(10)["rule"].astype(int).tolist(),
        "top10_O_only_rules": df.sort_values("O", ascending=False).head(10)["rule"].astype(int).tolist(),
        "top10_symmetry_classes": class_rankings.head(10)["symmetry_class"].astype(int).tolist(),
        "top10_class_representative_rules": class_rankings.head(10)["top_rule"].astype(int).tolist(),
        **concentration,
        "mean_top20_overlap_under_weight_perturbation": float(sens["top20_overlap_with_base"].mean()),
        "min_top20_overlap_under_weight_perturbation": float(sens["top20_overlap_with_base"].min()),
        "max_top20_overlap_under_weight_perturbation": float(sens["top20_overlap_with_base"].max()),
        "global_simplex_weight_draws": int(len(global_sens)),
        "mean_top20_overlap_under_global_simplex_weights": float(global_sens["top20_overlap_with_base"].mean()),
        "min_top20_overlap_under_global_simplex_weights": float(global_sens["top20_overlap_with_base"].min()),
        "median_top20_overlap_under_global_simplex_weights": float(global_sens["top20_overlap_with_base"].median()),
        "max_top20_overlap_under_global_simplex_weights": float(global_sens["top20_overlap_with_base"].max()),
        "seed_sensitivity_runs": int(len(seed_sens)),
        "mean_top20_overlap_under_adjacent_seeds": float(seed_sens["top20_overlap_with_base"].mean()),
        "min_top20_overlap_under_adjacent_seeds": float(seed_sens["top20_overlap_with_base"].min()),
        "top1_rules_under_adjacent_seeds": seed_sens["top1_rule"].astype(int).tolist(),
        "size_sensitivity_scales": size_sens["label"].tolist(),
        "mean_top20_overlap_under_size_sensitivity": float(size_sens["top20_overlap_with_base"].mean()),
        "min_top20_overlap_under_size_sensitivity": float(size_sens["top20_overlap_with_base"].min()),
        "top1_rules_under_size_sensitivity": size_sens["top1_rule"].astype(int).tolist(),
        "o_metric_sensitivity": {
            row["variant"]: {
                "top10_rules": json.loads(row["top10_rules"]),
                "top5_symmetry_classes": json.loads(row["top5_symmetry_classes"]),
                "top20_overlap_with_base_O": float(row["top20_overlap_with_base_O"]),
            }
            for _, row in o_sens.iterrows()
        },
        "robustness_diagnostics": {
            "metric_variants": list(metric_registry().keys()),
            "model_averaging_weight_draws": int(config.model_averaging_weight_draws),
            "model_averaging_eta_grid": [float(v) for v in config.model_averaging_eta_grid],
            "base_priors": base_prior_sens["base_prior"].tolist(),
            "n_hyperparameter_combinations": int(len(hyperparameter_combos)),
            "top10_model_averaged_rules": rule_robustness.head(10)["rule"].astype(int).tolist(),
            "top10_model_averaged_symmetry_classes": class_robustness.head(10)["symmetry_class"].astype(int).tolist(),
            "top_model_averaged_class_score_top5_frequency_max": float(class_robustness.iloc[0]["score_top5_frequency_max"]),
            "top_model_averaged_class_prior_top5_frequency": float(class_robustness.iloc[0]["prior_top5_frequency"]),
            "mean_hyperparameter_top20_score_overlap_with_base_OFST": float(hyperparameter_combos["top20_score_overlap_with_base_OFST"].mean()),
            "mean_hyperparameter_top20_prior_rank_overlap_with_base_OFST": float(hyperparameter_combos["top20_prior_rank_overlap_with_base_OFST"].mean()),
            "trajectory_holdout_early_O_to_late_O_rank_correlation": float(
                trajectory_holdout.loc[
                    trajectory_holdout["validation"] == "early_O_predicts_late_O_rank_correlation", "value"
                ].iloc[0]
            ),
        },
        "reference_baseline_overlap": {
            row["baseline"]: {
                "top10_overlap": int(row["top10_overlap"]),
                "top20_overlap": int(row["top20_overlap"]),
                "best_OFST_rank": None if pd.isna(row["best_OFST_rank"]) else int(row["best_OFST_rank"]),
            }
            for _, row in baseline_overlap.iterrows()
        },
        "null_model_summary": {
            row["null_model"]: {
                "mean_top20_overlap_with_base": float(row["mean_top20_overlap_with_base"]),
                "mean_top20_overlap_ci_low": float(row["mean_top20_overlap_ci_low"]),
                "mean_top20_overlap_ci_high": float(row["mean_top20_overlap_ci_high"]),
                "max_top20_overlap_with_base": float(row["max_top20_overlap_with_base"]),
                "top1_match_rate": float(row["top1_match_rate"]),
                "top1_match_rate_ci_low": float(row["top1_match_rate_ci_low"]),
                "top1_match_rate_ci_high": float(row["top1_match_rate_ci_high"]),
            }
            for _, row in null_summary.iterrows()
        },
        "uncertainty_summary": [
            {
                "source": str(row["source"]),
                "metric": str(row["metric"]),
                "n": int(row["n"]),
                "estimate": float(row["estimate"]),
                "ci_low": float(row["ci_low"]),
                "ci_high": float(row["ci_high"]),
            }
            for _, row in uncertainty_summary.iterrows()
        ],
        "ablation_top10_rules": {
            row["case"]: json.loads(row["top10_rules"]) for _, row in ablations.iterrows()
        },
    }

    with open(results_dir / "run_summary.json", "w", encoding="utf-8") as f:
        json.dump(summary, f, indent=2)

    save_figures(df, sample_histories, sens, global_sens, figures_dir, size_sens)

    return summary


def main(argv: list[str] | None = None) -> None:
    config = config_from_args(argv)
    summary = run(config)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
