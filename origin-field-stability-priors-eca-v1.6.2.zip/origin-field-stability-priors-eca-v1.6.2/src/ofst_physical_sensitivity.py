#!/usr/bin/env python3
"""
Origin Field Stability Prior physical-extension diagnostics, v1.6.1.

This additive module runs diagnostic extensions for the v1.6.0 physical
extension without modifying the existing ECA pipeline or the existing physical
extension module. It reuses the declared finite-grid physical pipeline and
writes sensitivity outputs under results/physical_extension and
figures/physical_extension.
"""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict
from pathlib import Path
from typing import Iterable

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from ofst_physical_extension import (
    PhysicalExtensionConfig,
    add_likelihood,
    add_observable_predictions,
    add_stability_prior_components,
    baseline_priors,
    evidence_table,
    make_candidate_grid,
)

BASELINE_PRIORS = ["uniform", "jeffreys_scale_proxy", "constrained_max_entropy_log"]
REFERENCE_RESOLUTION = "25x21"
JEFFREYS_BF_ALERT_THRESHOLD = 3.0
UNIFORM_BF_SHIFT_ALERT_PCT = 20.0


def _run_pipeline_table(config: PhysicalExtensionConfig) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Run the physical-extension grid/evidence calculation in memory."""

    config = config.validate()
    candidates = make_candidate_grid(config)
    observable_df = add_observable_predictions(candidates, config)
    stability_df = add_stability_prior_components(observable_df, config)
    likelihood_df = add_likelihood(stability_df, config)
    priors = baseline_priors(likelihood_df, config)
    evidence_df, _posterior_df = evidence_table(likelihood_df, priors)
    return likelihood_df, evidence_df


def _evidence_lookup(evidence_df: pd.DataFrame, prior_name: str, column: str) -> float:
    match = evidence_df.loc[evidence_df["prior_name"] == prior_name, column]
    if match.empty:
        raise KeyError(f"missing prior {prior_name!r} in evidence table")
    return float(match.iloc[0])


def _evidence_summary_row(
    *,
    config: PhysicalExtensionConfig,
    likelihood_df: pd.DataFrame,
    evidence_df: pd.DataFrame,
    run_label: str,
) -> dict[str, float | int | str | bool]:
    """Flatten the rung-8 evidence table into one diagnostic row."""

    row: dict[str, float | int | str | bool] = {
        "run_label": run_label,
        "lambda_points": int(config.lambda_points),
        "g_points": int(config.g_points),
        "n_candidates_total": int(len(likelihood_df)),
        "n_observable_valid_candidates": int(likelihood_df["observable_valid"].sum()),
        "cmb_shift_R_obs_used": float(config.cmb_shift_r_obs),
        "cmb_shift_R_sigma_used": float(config.cmb_shift_r_sigma),
        "log_evidence_stability": _evidence_lookup(evidence_df, "stability", "log_evidence"),
        "evidence_stability": _evidence_lookup(evidence_df, "stability", "evidence"),
    }
    for prior_name in BASELINE_PRIORS:
        short = {
            "uniform": "uniform",
            "jeffreys_scale_proxy": "jeffreys",
            "constrained_max_entropy_log": "maxent_log",
        }[prior_name]
        row[f"log_evidence_{short}"] = _evidence_lookup(evidence_df, prior_name, "log_evidence")
        row[f"evidence_{short}"] = _evidence_lookup(evidence_df, prior_name, "evidence")
        row[f"bf_{short}_vs_stability"] = _evidence_lookup(evidence_df, prior_name, "bayes_factor_vs_stability")
        row[f"bf_stability_vs_{short}"] = _evidence_lookup(evidence_df, prior_name, "bayes_factor_stability_vs_prior")
    return row


def run_grid_resolution_sensitivity(base_config: PhysicalExtensionConfig | None = None) -> pd.DataFrame:
    """Run the rung 5-8 pipeline at 13x11, 25x21, and 50x42 grids."""

    base = (base_config or PhysicalExtensionConfig()).validate()
    resolutions = [(25, 21), (50, 42), (13, 11)]
    rows: list[dict[str, float | int | str | bool]] = []
    for lambda_points, g_points in resolutions:
        config = PhysicalExtensionConfig(
            **{**asdict(base), "lambda_points": lambda_points, "g_points": g_points}
        ).validate()
        likelihood_df, evidence_df = _run_pipeline_table(config)
        label = f"{lambda_points}x{g_points}"
        rows.append(
            _evidence_summary_row(
                config=config,
                likelihood_df=likelihood_df,
                evidence_df=evidence_df,
                run_label=label,
            )
        )

    df = pd.DataFrame(rows)
    ref = df.loc[df["run_label"] == REFERENCE_RESOLUTION, "bf_stability_vs_uniform"]
    if ref.empty:
        raise RuntimeError(f"reference resolution {REFERENCE_RESOLUTION} is missing")
    ref_value = float(ref.iloc[0])
    df["uniform_bf_reference_resolution"] = REFERENCE_RESOLUTION
    df["uniform_bf_reference_value"] = ref_value
    df["uniform_bf_change_vs_25x21_pct"] = 100.0 * (df["bf_stability_vs_uniform"] - ref_value) / ref_value
    df["uniform_bf_flag_gt20pct_vs_25x21"] = df["uniform_bf_change_vs_25x21_pct"].abs() > UNIFORM_BF_SHIFT_ALERT_PCT
    df["resolution_sensitivity_note"] = np.where(
        df["uniform_bf_flag_gt20pct_vs_25x21"],
        "BF stability/uniform shifts by more than 20% relative to the 25x21 grid.",
        "BF stability/uniform remains within 20% of the 25x21 grid.",
    )
    return df


def run_shift_parameter_sensitivity(base_config: PhysicalExtensionConfig | None = None) -> pd.DataFrame:
    """Run the 25x21 grid while varying R* and sigma_R."""

    base = (base_config or PhysicalExtensionConfig()).validate()
    baseline_r = float(base.cmb_shift_r_obs)
    baseline_sigma = float(base.cmb_shift_r_sigma)
    offsets = [-5, -2, 0, 2, 5]
    sigma_multipliers = [0.5, 1.0, 2.0]
    rows: list[dict[str, float | int | str | bool]] = []
    for offset in offsets:
        for sigma_multiplier in sigma_multipliers:
            config = PhysicalExtensionConfig(
                **{
                    **asdict(base),
                    "lambda_points": 25,
                    "g_points": 21,
                    "cmb_shift_r_obs": baseline_r + offset * baseline_sigma,
                    "cmb_shift_r_sigma": baseline_sigma * sigma_multiplier,
                }
            ).validate()
            likelihood_df, evidence_df = _run_pipeline_table(config)
            row = _evidence_summary_row(
                config=config,
                likelihood_df=likelihood_df,
                evidence_df=evidence_df,
                run_label=f"R_offset_{offset:+d}sigma__sigmaR_{sigma_multiplier:g}x",
            )
            row["r_offset_sigma_units"] = int(offset)
            row["sigma_R_multiplier"] = float(sigma_multiplier)
            row["baseline_cmb_shift_R_obs"] = baseline_r
            row["baseline_cmb_shift_R_sigma"] = baseline_sigma
            row["jeffreys_bf_below_3_flag"] = bool(row["bf_stability_vs_jeffreys"] < JEFFREYS_BF_ALERT_THRESHOLD)
            row["jeffreys_sensitivity_note"] = (
                "BF stability/Jeffreys proxy drops below 3.0."
                if row["jeffreys_bf_below_3_flag"]
                else "BF stability/Jeffreys proxy remains at or above 3.0."
            )
            rows.append(row)
    return pd.DataFrame(rows)


def save_grid_resolution_figure(df: pd.DataFrame, figures_dir: Path) -> None:
    """Save a diagnostic figure for grid-resolution Bayes factors."""

    figures_dir.mkdir(parents=True, exist_ok=True)
    x = np.arange(len(df))
    width = 0.24
    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    ax.bar(x - width, df["bf_stability_vs_uniform"], width, label="uniform")
    ax.bar(x, df["bf_stability_vs_jeffreys"], width, label="Jeffreys proxy")
    ax.bar(x + width, df["bf_stability_vs_maxent_log"], width, label="max-entropy log")
    ax.set_yscale("log")
    ax.set_xticks(x)
    ax.set_xticklabels(df["run_label"].tolist())
    ax.set_xlabel("Grid resolution")
    ax.set_ylabel("Bayes factor: stability prior / baseline")
    ax.set_title("Grid-resolution sensitivity of rung-8 Bayes factors")
    ax.legend(loc="best")
    fig.tight_layout()
    fig.savefig(figures_dir / "grid_resolution_bayes_factors.png", dpi=180)
    plt.close(fig)


def save_shift_parameter_figure(df: pd.DataFrame, figures_dir: Path) -> None:
    """Save a diagnostic heatmap for R* and sigma_R sensitivity."""

    figures_dir.mkdir(parents=True, exist_ok=True)
    pivot = df.pivot(index="sigma_R_multiplier", columns="r_offset_sigma_units", values="bf_stability_vs_jeffreys")
    pivot = pivot.sort_index().sort_index(axis=1)
    values = pivot.to_numpy(dtype=float)
    fig, ax = plt.subplots(figsize=(8.5, 5.5))
    mesh = ax.imshow(np.log10(values), aspect="auto", origin="lower")
    ax.set_xticks(np.arange(len(pivot.columns)))
    ax.set_xticklabels([str(int(v)) for v in pivot.columns])
    ax.set_yticks(np.arange(len(pivot.index)))
    ax.set_yticklabels([f"{v:g}x" for v in pivot.index])
    ax.set_xlabel("R* offset from baseline, in baseline sigma units")
    ax.set_ylabel("sigma_R multiplier")
    ax.set_title("Shift-parameter sensitivity: log10 BF stability/Jeffreys proxy")
    cbar = fig.colorbar(mesh, ax=ax)
    cbar.set_label("log10 Bayes factor")
    for y_index, sigma_multiplier in enumerate(pivot.index):
        for x_index, offset in enumerate(pivot.columns):
            value = float(pivot.loc[sigma_multiplier, offset])
            ax.text(x_index, y_index, f"{value:.2g}", ha="center", va="center")
    fig.tight_layout()
    fig.savefig(figures_dir / "shift_parameter_sensitivity.png", dpi=180)
    plt.close(fig)


def write_summary(results_dir: Path, grid_df: pd.DataFrame, shift_df: pd.DataFrame) -> None:
    """Write a compact machine-readable diagnostic summary."""

    grid_flags = grid_df.loc[grid_df["uniform_bf_flag_gt20pct_vs_25x21"], "run_label"].tolist()
    jeffreys_flags = shift_df.loc[shift_df["jeffreys_bf_below_3_flag"], "run_label"].tolist()
    summary = {
        "version": "1.6.1",
        "diagnostic_extension": "physical_extension_sensitivity_runs",
        "existing_modules_modified": False,
        "grid_resolution_sensitivity": {
            "reference_resolution": REFERENCE_RESOLUTION,
            "uniform_bf_shift_alert_threshold_pct": UNIFORM_BF_SHIFT_ALERT_PCT,
            "flagged_resolutions": grid_flags,
        },
        "shift_parameter_sensitivity": {
            "jeffreys_bf_alert_threshold": JEFFREYS_BF_ALERT_THRESHOLD,
            "flagged_combinations": jeffreys_flags,
        },
        "interpretation_boundary": (
            "These diagnostics vary grid and compressed-distance-prior settings only. They do not replace full CMB likelihood, "
            "Boltzmann-code, nuisance-parameter, covariance, recombination, perturbation-growth, or true varying-G analyses."
        ),
    }
    (results_dir / "physical_sensitivity_summary_v1.6.1.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")


def run(base_config: PhysicalExtensionConfig | None = None) -> dict[str, object]:
    """Run all additive v1.6.1 physical-extension diagnostics."""

    base = (base_config or PhysicalExtensionConfig()).validate()
    results_dir = Path(base.results_dir)
    figures_dir = Path(base.figures_dir)
    results_dir.mkdir(parents=True, exist_ok=True)
    figures_dir.mkdir(parents=True, exist_ok=True)

    grid_df = run_grid_resolution_sensitivity(base)
    shift_df = run_shift_parameter_sensitivity(base)

    grid_df.to_csv(results_dir / "grid_resolution_sensitivity.csv", index=False)
    shift_df.to_csv(results_dir / "shift_parameter_sensitivity.csv", index=False)
    save_grid_resolution_figure(grid_df, figures_dir)
    save_shift_parameter_figure(shift_df, figures_dir)
    write_summary(results_dir, grid_df, shift_df)

    return {
        "version": "1.6.1",
        "grid_resolution_rows": int(len(grid_df)),
        "shift_parameter_rows": int(len(shift_df)),
        "uniform_bf_resolution_flags": grid_df.loc[
            grid_df["uniform_bf_flag_gt20pct_vs_25x21"], "run_label"
        ].tolist(),
        "jeffreys_bf_below_3_flags": shift_df.loc[
            shift_df["jeffreys_bf_below_3_flag"], "run_label"
        ].tolist(),
    }


def main(argv: Iterable[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Run OFST physical-extension v1.6.1 sensitivity diagnostics.")
    parser.add_argument("--results-dir", default="results/physical_extension")
    parser.add_argument("--figures-dir", default="figures/physical_extension")
    parser.add_argument("--integration-steps", type=int, default=4096)
    parser.add_argument("--eta", type=float, default=8.0, help="Gibbs concentration for the stability prior")
    args = parser.parse_args(list(argv) if argv is not None else None)
    config = PhysicalExtensionConfig(
        results_dir=args.results_dir,
        figures_dir=args.figures_dir,
        integration_steps=args.integration_steps,
        stability_eta=args.eta,
    )
    print(json.dumps(run(config), indent=2))


if __name__ == "__main__":
    main()
