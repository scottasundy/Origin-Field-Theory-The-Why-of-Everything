# Research Roadmap

Version: 1.5.1

## Current milestone

The current package provides a reproducible finite-ensemble ECA demonstration. It contains a declared score, a Gibbs-prior construction, generated CI-profile outputs, robustness diagnostics, null models, reference baselines, uncertainty intervals, finite-size diagnostics, figures, tests, checksums, citation metadata, and release metadata.

## Near-term technical extensions

1. Archive a larger default-profile result set separately from the CI-profile outputs.
2. Run the same diagnostics at larger grids and longer horizons.
3. Add independent implementations for the ECA update and metric layer.
4. Add additional negative controls that preserve different ECA invariants.
5. Apply the same prior-audit framework to a physically interpretable toy ensemble.

## Physics-facing extensions

A physically meaningful extension should move beyond elementary cellular automata to ensembles with clearer physical structure, such as:

- reversible cellular automata;
- lattice Hamiltonian systems;
- quantum circuit ensembles;
- scalar-field lattice models;
- graph rewrite systems with explicit locality;
- toy cosmological parameter ensembles.

Each extension must define the candidate space, symmetries, admissibility constraints, observables, and a likelihood.

## Required standard for empirical claims

A future empirical version should use:

\[
P(U_i\mid D)\propto P(D\mid U_i)P_G(U_i),
\]

where \(D\) is a specified dataset and \(P(D\mid U_i)\) is a declared likelihood. Without this likelihood, the result remains prior construction.

## Failure standard

A physical law-selection claim should be rejected or weakened if the prior does not outperform baseline priors, if the result depends on a post hoc metric choice, if it fails on blind holdout observables, or if it violates known physical constraints without a precise replacement model.
