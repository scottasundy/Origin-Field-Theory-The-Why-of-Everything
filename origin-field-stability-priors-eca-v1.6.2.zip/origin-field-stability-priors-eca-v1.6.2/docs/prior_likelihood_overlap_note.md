# Prior-Likelihood Overlap Note, v1.6.2

This note isolates the stability prior from the data likelihood on the 25x21 Lambda/G grid and then compares the prior mass surface with the CMB shift-parameter likelihood surface.

## Prior concentration

The stability prior peaks at candidate U18_09 with lambda=1.07791233589, g=0.98, prior weight=0.0308892292943, and stability score=0.748111044493.
Its weighted component drivers are: curvature=0.372638, moderation=0.342197, expansion_regularity=0.0332764.

The score used by the current physical extension is S_w = 0.45 curvature_score + 0.35 moderation_score + 0.20 expansion_regularity_score. The Gibbs prior is P_G proportional to exp(eta times [S_w - max(S_w)]), with eta=8 in the default run.

The concentration therefore comes from the score construction itself: low absolute derived curvature, closeness to the observed constant ratios in log space, and smooth background expansion. It is not learned from the CMB datum.

## Likelihood overlap

The likelihood peaks at candidate U18_00 with lambda=1.07791233589, g=0.8, relative likelihood=1, and residual=-0.931344810566 sigma.
The nearest 25x21 grid point to lambda about 1.012, g about 0.976 is candidate U18_09 with lambda=1.07791233589, g=0.98, prior weight=0.0308892292943, and residual=-22.2050969913 sigma.

No. On the 25x21 grid the stability-prior peak and likelihood peak are separated.
The prior peak is near the lambda about 1.012, g about 0.976 region.

## Physical interpretation

The overlap is only weakly physically motivated. The curvature and moderation terms favor candidates close to flat geometry and observed-scale constants, so some overlap with a CMB distance observable is expected. However, the exact prior peak is not derived from a cosmological Fisher matrix or from a physical theory of varying constants. It is a declared stability-score prior applied to Lambda/G space.

That means the Bayes factor should be read as evidence for this score construction under this finite-grid approximation, not as independent evidence that the stability prior is a fundamental cosmological prior. The elevated BF mainly says that the current stability score places more prior mass near the compressed CMB shift-parameter ridge than the Jeffreys proxy does. It does not establish that the score is the true physical prior.
