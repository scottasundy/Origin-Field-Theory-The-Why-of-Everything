# Stability-Weighted Priors for Finite Model Ensembles: An Elementary Cellular Automaton Demonstration

Version: 1.5.1  
Date: 2026-05-16

## Abstract

This repository defines and audits a stability-weighted Gibbs prior over a complete finite ensemble: the 256 elementary cellular automata. The work is methodological. It shows how a declared stability score can induce a finite prior, how the result changes under metric and hyperparameter variation, and how robustness claims can be limited by generated diagnostics. The package includes null models, reference baselines, uncertainty intervals, finite-size diagnostics, tests, manifest metadata, and checksum validation. The demonstration does not establish a physical law-selection mechanism and does not make empirical claims about the universe.

## 1. Scope

The package treats stability-weighted law selection as a finite model-selection problem. Elementary cellular automata are used because they form a complete, exactly enumerable, reproducible toy ensemble. They are not a realistic physical theory space.

The proposition tested here is limited:

> A stability-weighted prior over a complete finite model ensemble can be explicitly declared, computed, audited, and reproduced.

## 2. Candidate ensemble

The candidate ensemble is

\[
\mathcal{U}=\{U_0,U_1,\ldots,U_{255}\},
\]

where each \(U_i\) is elementary cellular automaton rule \(i\). Each rule is evaluated on finite binary histories with declared grid size, time horizon, initial-condition count, random seed, and perturbation settings.

## 3. Stability score

The declared score is

\[
S_w(U)=w_C C(U)+w_A A(U)+w_O O(U)-w_R R(U).
\]

For this demonstration:

- \(C(U)=1\) for every rule and acts only as an admissibility term.
- \(A(U)\) is a finite-history gzip-compressibility score.
- \(O(U)\) is a persistent-structure proxy built from bounded symbolic and information-theoretic summaries.
- \(R(U)\) is a perturbation-fragility penalty.

The bundled base vector is

```text
C = 0.1
A = 0.15
O = 0.65
R = 0.1
```

The score is a declared modeling choice, not a derivation from established physics.

## 4. Gibbs prior

The finite prior is

\[
P_G(U_i\mid\Theta,w,\eta)=
\frac{\pi_i\Theta_i e^{\eta S_w(U_i)}}
{\sum_j\pi_j\Theta_j e^{\eta S_w(U_j)}}.
\]

Here \(\pi_i\) is the base prior, \(\Theta_i\) is an admissibility indicator, \(w\) is the score-weight vector, and \(\eta\ge0\) controls concentration.

This is a prior. It is not an empirical posterior unless a likelihood \(P(D\mid U_i)\) is supplied.

## 5. Diagnostics

The release computes and stores:

1. base scores and rankings;
2. Gibbs prior weights;
3. symmetry classes under reflection and bit conjugation;
4. local weight sensitivity;
5. broad simplex weight sensitivity;
6. eta sensitivity;
7. base-prior sensitivity;
8. 19 \(O(U)\)-metric variants;
9. raw-rule and symmetry-class model averaging;
10. max, mean, and median class aggregation;
11. seed sensitivity;
12. finite-size sensitivity;
13. trajectory-holdout validation;
14. reference ECA baseline overlap;
15. null-model controls;
16. bootstrap and Wilson uncertainty intervals.

## 6. Bundled CI-profile result

The checked-in results use:

```text
n_cells = 32
n_steps = 32
n_random_initial_conditions = 6
n_fragility_initial_conditions = 3
metric_variants = 19
full_Gibbs_prior_combinations = 684
null_model_draws_per_null = 24
bootstrap_draws = 128
```

Base ranking:

|       rule |   symmetry_class |        S |        A |        O |        R |
|-----------:|-----------------:|---------:|---------:|---------:|---------:|
|   1.000000 |         1.000000 | 0.616290 | 0.934426 | 0.580181 | 0.009920 |
| 127.000000 |         1.000000 | 0.608610 | 0.931694 | 0.582163 | 0.095494 |
|  33.000000 |        33.000000 | 0.588601 | 0.920765 | 0.551748 | 0.081497 |
| 123.000000 |        33.000000 | 0.588032 | 0.913934 | 0.543795 | 0.025252 |
| 198.000000 |       156.000000 | 0.571832 | 0.871585 | 0.540888 | 0.104829 |
| 199.000000 |        28.000000 | 0.570964 | 0.859290 | 0.540301 | 0.091252 |
|  70.000000 |        28.000000 | 0.569740 | 0.863388 | 0.540676 | 0.112075 |
| 156.000000 |       156.000000 | 0.563162 | 0.853825 | 0.531147 | 0.101580 |
|  28.000000 |        28.000000 | 0.562184 | 0.851093 | 0.529686 | 0.097752 |
| 157.000000 |        28.000000 | 0.560985 | 0.842896 | 0.529650 | 0.097224 |

## 7. Robustness summary

The local ±25% weight perturbation has mean top-20 overlap 0.967. The broad simplex-weight diagnostic has mean top-20 overlap 0.350. The hyperparameter grid has mean score-top-20 overlap 0.430 and mean prior-rank top-20 overlap 0.289.

The strongest class-level score-rank result is symmetry class 1, with max-member score-top-5 frequency 0.754 and prior-top-5 frequency 0.437. This supports a limited score-rank robustness statement, not a physical interpretation.

## 8. Null models

| null_model                              |   n_draws |   mean_top20_overlap_with_base |   mean_top20_overlap_ci_low |   mean_top20_overlap_ci_high |   top1_match_rate |   top1_match_rate_ci_low |   top1_match_rate_ci_high |   mean_score_rank_correlation_with_base |
|:----------------------------------------|----------:|-------------------------------:|----------------------------:|-----------------------------:|------------------:|-------------------------:|--------------------------:|----------------------------------------:|
| component_tuple_permutation             |        24 |                       0.091667 |                    0.070833 |                     0.114219 |          0.000000 |                 0.000000 |                  0.137976 |                                0.012392 |
| hamming_neighbor_score_substitution     |        24 |                       0.118750 |                    0.090313 |                     0.149635 |          0.000000 |                 0.000000 |                  0.137976 |                                0.221547 |
| independent_component_permutation       |        24 |                       0.081250 |                    0.066667 |                     0.100000 |          0.000000 |                 0.000000 |                  0.137976 |                               -0.002590 |
| orbit_size_preserving_score_permutation |        24 |                       0.122917 |                    0.098646 |                     0.143385 |          0.000000 |                 0.000000 |                  0.137976 |                                0.035282 |
| score_label_permutation                 |        24 |                       0.102083 |                    0.081615 |                     0.122552 |          0.000000 |                 0.000000 |                  0.137976 |                                0.025795 |

The null controls produce low top-20 overlap with the base score ranking and zero observed top-1 matches in the bundled CI profile. These controls support the integrity of the finite diagnostic pipeline, not an empirical physical claim.

## 9. Claim boundary

The package supports the following claim:

> The finite ECA prior-construction pipeline is explicit, reproducible, and auditable under declared diagnostics.

It does not support:

- physical law selection;
- empirical cosmological inference;
- observer detection;
- replacement of established physics;
- posterior model selection without a likelihood.

## 10. Path to empirical use

An empirical extension must define a physically meaningful candidate space, observables, and likelihood:

\[
P(U_i\mid D)\propto P(D\mid U_i)P_G(U_i).
\]

It must also compare evidence against baseline priors and preregister failure conditions before interpreting prior concentration as evidence.
