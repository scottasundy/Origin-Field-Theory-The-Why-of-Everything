# Persistent-Structure Metric Protocol

Version: 1.5.1

## Purpose

This protocol defines the finite-history \(O(U)\) metric family used in the ECA demonstration. The base \(O(U)\) metric rewards persistent, nontrivial structural information while avoiding direct dependence on gzip-derived compressibility.

## Base components

For a generated ECA history, the base metric uses:

1. binary occupancy entropy;
2. activity balance;
3. temporal persistence, combining one-step and lag-5 mutual information;
4. structured nontriviality, combining spatial mutual information and edge balance.

The base proxy is the geometric mean of these four bounded positive components.

## Compression separation

\(A(U)\) already uses gzip-derived compressibility. Therefore, the base \(O(U)\) metric excludes gzip. Compression-inclusive variants are retained only as explicit sensitivity checks.

## Metric family

- `base_geometric`
- `with_compression_window_geometric`
- `arithmetic_mean`
- `harmonic_mean_guardrail`
- `min_component_guardrail`
- `information_heavy_geometric`
- `structure_heavy_geometric`
- `entropy_activity_geometric`
- `persistence_structure_geometric`
- `spatial_temporal_balance`
- `edge_temporal_geometric`
- `late_holdout_geometric`
- `predictive_stability_geometric`
- `block_entropy_geometric`
- `lz_complexity_geometric`
- `symbolic_dynamics_geometric`
- `excess_entropy_geometric`
- `multi_complexity_geometric`
- `compression_only_window`

## Bundled CI-profile metric sensitivity

Top-20 overlap with the base \(O(U)\) ranking:

| variant                           |   top20_overlap_with_base_O |
|:----------------------------------|----------------------------:|
| base_geometric                    |                       1.000 |
| with_compression_window_geometric |                       0.800 |
| arithmetic_mean                   |                       0.400 |
| harmonic_mean_guardrail           |                       0.800 |
| min_component_guardrail           |                       0.700 |
| information_heavy_geometric       |                       0.450 |
| structure_heavy_geometric         |                       0.800 |
| entropy_activity_geometric        |                       0.000 |
| persistence_structure_geometric   |                       0.200 |
| spatial_temporal_balance          |                       0.200 |
| edge_temporal_geometric           |                       0.000 |
| late_holdout_geometric            |                       0.700 |
| predictive_stability_geometric    |                       0.950 |
| block_entropy_geometric           |                       1.000 |
| lz_complexity_geometric           |                       0.950 |
| symbolic_dynamics_geometric       |                       0.850 |
| excess_entropy_geometric          |                       0.800 |
| multi_complexity_geometric        |                       0.800 |
| compression_only_window           |                       0.100 |

Large variation across this table is an intended diagnostic. It prevents the package from overstating conclusions that depend on a single hand-declared structural proxy.

## Interpretation boundary

\(O(U)\) is not an observer detector and does not show that an ECA contains observers. It is a finite-history structural proxy used for a bounded model-selection demonstration.
