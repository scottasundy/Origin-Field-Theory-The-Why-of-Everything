# Framework Context

Version: 1.5.1

## Purpose

This document connects the computational package to its conceptual motivation while keeping the scientific claim boundary explicit.

## Conceptual translation

The motivating framework treats law selection as a stability problem over possible configurations. This repository operationalizes only a narrow, testable fragment of that idea:

- a declared candidate ensemble;
- a declared stability score;
- a Gibbs prior over candidates;
- sensitivity diagnostics;
- null-model diagnostics;
- uncertainty intervals;
- release validation.

## Operational terms

| Framework role | ECA operational proxy |
|---|---|
| admissibility / consistency | \(C(U)=1\) for every ECA rule |
| simplicity / compressibility | \(A(U)\), a gzip-derived finite-history score |
| structured persistence | \(O(U)\), a non-compression finite-history structural proxy |
| fragility / instability | \(R(U)\), perturbation sensitivity |

This is an operational analogy, not a derivation from fundamental physics.

## Observer-capacity language

This package does not model observers. The \(O(U)\) term is a persistent-structure proxy only. It should not be interpreted as detecting experience, agency, or physical observation.

## Physical interpretation boundary

The ECA demonstration does not test quantum mechanics, relativity, cosmology, thermodynamics, or field theory. It is a reproducible finite-ensemble prior-construction package. Any future physics-facing version must specify a physical candidate space, observables, and an empirical likelihood.
