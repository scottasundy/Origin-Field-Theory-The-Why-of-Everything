# Robustness Protocol

Version: 1.5.1

## Purpose

This protocol records the robustness checks used for the finite ECA demonstration of stability-weighted priors.

The protocol addresses eight failure modes:

1. dependence on one structural metric;
2. compression double-counting between \(A(U)\) and \(O(U)\);
3. conflation of score-rank robustness with Gibbs-prior-mass robustness;
4. class-level claims driven by a single high-scoring representative;
5. overinterpretation of overlap with familiar ECA rules;
6. overinterpretation of finite-run top-list stability as empirical evidence;
7. unreported finite diagnostic uncertainty;
8. size and seed sensitivity in finite trajectories.

## Metric family

The base \(O(U)\) metric excludes gzip compression. Compression appears only in labeled sensitivity variants.

Metric variants:

- `base_geometric`
- `with_compression_window_geometric`
- `arithmetic_mean`
- `harmonic_mean_guardrail`
- `min_component_guardrail`
- `information_heavy_geometric`
- `structure_heavy_geometric`
- `entropy_activity_geometric`
- `persistence_structure_geometric`
- `spatial_temporal_balance`
- `edge_temporal_geometric`
- `late_holdout_geometric`
- `predictive_stability_geometric`
- `block_entropy_geometric`
- `lz_complexity_geometric`
- `symbolic_dynamics_geometric`
- `excess_entropy_geometric`
- `multi_complexity_geometric`
- `compression_only_window`

## Hyperparameter grid

Bundled CI-profile outputs use:

```text
O-metric variants = 19
weight draws = 6
eta values = [0.0, 2.0, 8.0]
base priors = ['uniform_raw_rules', 'uniform_symmetry_classes']
full Gibbs-prior combinations = 684
```

## Aggregation separation

Raw-rule and symmetry-class conclusions are reported separately. Class-level output includes:

- max-member aggregation;
- mean aggregation;
- median aggregation;
- prior-mass aggregation.

Max-member aggregation is the most permissive class score. Mean and median columns show whether a class result depends on one standout member.

## Uncertainty intervals

The package reports:

- Wilson 95% intervals for binomial top-list frequencies;
- nonparametric bootstrap 95% intervals for mean overlap diagnostics.

Intervals are diagnostic summaries for finite runs. They do not imply empirical confirmation of the theory.

## Bundled class robustness summary

The top class-level score result under the bundled CI profile is symmetry class 1. Its max-member score-top-5 frequency is 0.754, while its prior-top-5 frequency is 0.437. The clean conclusion is therefore limited: the diagnostics expose score-rank robustness and prior-rank weakness in a finite toy ensemble.

## Null models

Five null diagnostics are included:

- `score_label_permutation`: permutes score values among rule labels.
- `independent_component_permutation`: independently permutes \(A\), \(O\), and \(R\).
- `component_tuple_permutation`: permutes complete \((A,O,R)\) component rows, preserving empirical component covariance.
- `orbit_size_preserving_score_permutation`: permutes scores within symmetry-orbit-size strata.
- `hamming_neighbor_score_substitution`: assigns each rule the score of a random Hamming-distance-1 rule-table neighbor.

Bundled null summary:

| null_model                              |   n_draws |   mean_top20_overlap_with_base |   mean_top20_overlap_ci_low |   mean_top20_overlap_ci_high |   top1_match_rate |   top1_match_rate_ci_low |   top1_match_rate_ci_high |   mean_score_rank_correlation_with_base |
|:----------------------------------------|----------:|-------------------------------:|----------------------------:|-----------------------------:|------------------:|-------------------------:|--------------------------:|----------------------------------------:|
| component_tuple_permutation             |        24 |                       0.091667 |                    0.070833 |                     0.114219 |          0.000000 |                 0.000000 |                  0.137976 |                                0.012392 |
| hamming_neighbor_score_substitution     |        24 |                       0.118750 |                    0.090313 |                     0.149635 |          0.000000 |                 0.000000 |                  0.137976 |                                0.221547 |
| independent_component_permutation       |        24 |                       0.081250 |                    0.066667 |                     0.100000 |          0.000000 |                 0.000000 |                  0.137976 |                               -0.002590 |
| orbit_size_preserving_score_permutation |        24 |                       0.122917 |                    0.098646 |                     0.143385 |          0.000000 |                 0.000000 |                  0.137976 |                                0.035282 |
| score_label_permutation                 |        24 |                       0.102083 |                    0.081615 |                     0.122552 |          0.000000 |                 0.000000 |                  0.137976 |                                0.025795 |

## Interpretation

A class is treated as score-rank robust under the CI profile if it exceeds a score-top-5 frequency threshold of 0.70. The bundled result should be read as a finite-ensemble methodology result, not as empirical evidence for physical law selection.
