# Toy Universe Stability Simulation Appendix, v1.5.1

Release date: 2026-05-16

## Purpose

This appendix packages a lean toy-universe stability simulation run against the Origin Field Stability Priors ECA framework. The simulation uses the complete elementary cellular automaton ensemble as a finite model universe and asks whether the declared stability score ranks persistent, compressible, low-fragility structure above maximally noisy behavior.

This appendix is a finite-model computational demonstration. It is not physical proof, not an empirical posterior, and not evidence by itself that the score selects real physical laws.

## What was simulated

The toy universe was the complete set of 256 elementary cellular automata. Each rule was evolved over finite binary spacetime histories using random initial conditions. For each rule, the run computed the same four component structure used by the package:

- `C`: admissibility, held constant at 1 for the full ECA ensemble.
- `A`: finite-trajectory compressibility score.
- `O`: persistent-structure proxy over finite binary histories.
- `R`: perturbation-fragility penalty.

The total stability score was:

```text
S_w(U) = w_C C(U) + w_A A(U) + w_O O(U) - w_R R(U)
```

The Gibbs prior weight was:

```text
P_G(U_i | Theta, w, eta) = pi_i Theta_i exp(eta S_w(U_i)) / sum_j pi_j Theta_j exp(eta S_w(U_j))
```

## Run configuration

| Setting | Value |
|---|---:|
| Rules tested | 256 |
| Cells | 64 |
| Time steps | 64 |
| Random initial conditions | 10 |
| Fragility initial conditions | 4 |
| Seed | 20260516 |
| Eta | 8.0 |
| Runtime seconds | 9.943 |

Declared weights:

| Component | Weight |
|---|---:|
| C | 0.1 |
| A | 0.15 |
| O | 0.65 |
| R | 0.1 |

## What was done

The run performed four checks.

1. It ranked all 256 rules using the declared stability score.
2. It generated spacetime visualizations for representative high-ranking, structured, and chaotic rules.
3. It tested local weight stability by perturbing the declared weights by approximately +/-25%.
4. It tested broad global-weight sensitivity and an early-to-late persistent-structure holdout diagnostic.

The raw outputs are included under `results/toy_universe_simulation/`. The associated figures are included under `figures/toy_universe_simulation/`.

## Top 10 rules

| Rule | Symmetry class | S | A | O | R | Gibbs weight |
| --- | --- | --- | --- | --- | --- | --- |
| 1 | 1 | 0.616223 | 0.969982 | 0.575869 | 0.035897 | 0.019781 |
| 127 | 1 | 0.615364 | 0.969782 | 0.579790 | 0.069674 | 0.019645 |
| 33 | 33 | 0.610235 | 0.948569 | 0.567005 | 0.006042 | 0.018855 |
| 123 | 33 | 0.605091 | 0.948369 | 0.566999 | 0.057134 | 0.018095 |
| 156 | 156 | 0.590621 | 0.929358 | 0.545561 | 0.033974 | 0.016117 |
| 157 | 28 | 0.589728 | 0.922554 | 0.545614 | 0.033040 | 0.016003 |
| 28 | 28 | 0.588844 | 0.924355 | 0.545624 | 0.044649 | 0.015890 |
| 198 | 156 | 0.586593 | 0.929358 | 0.545929 | 0.076650 | 0.015606 |
| 70 | 28 | 0.586521 | 0.926156 | 0.546110 | 0.073740 | 0.015597 |
| 199 | 28 | 0.586082 | 0.924755 | 0.546097 | 0.075949 | 0.015543 |

## Stability diagnostics

| Diagnostic | Result |
|---|---:|
| Local weight perturbation mean top-20 overlap | 0.993 |
| Local weight perturbation minimum top-20 overlap | 0.950 |
| Local weight perturbation maximum top-20 overlap | 1.000 |
| Broad global-weight sweep mean top-20 overlap | 0.497 |
| Broad global-weight sweep minimum top-20 overlap | 0.050 |
| Broad global-weight sweep maximum top-20 overlap | 0.950 |
| Early O to late O rank correlation | 0.600 |
| Early O top-20 overlap with late O top-20 | 0.850 |

## Interpretation

The top-ranked rules were not the maximally chaotic rules. They favored compressible but nontrivial persistent structure with relatively low fragility. The ranking remained highly stable under local perturbation of the declared weights, with a mean top-20 overlap of 0.993. The ranking moved substantially under broad global changes to the scoring philosophy, with a mean top-20 overlap of 0.497.

The correct reading is narrow: the framework behaves coherently under its declared metric choices, but the choice of stability definition remains materially important. The result strengthens the package as a transparent finite-ensemble demonstration. It does not upgrade the claim into empirical physics.

## Included files

### Results

- `results/toy_universe_simulation/toy_universe_full_rankings.csv`
- `results/toy_universe_simulation/toy_universe_top20_rankings.csv`
- `results/toy_universe_simulation/top20_symmetry_classes.csv`
- `results/toy_universe_simulation/local_weight_sensitivity.csv`
- `results/toy_universe_simulation/global_weight_sensitivity.csv`
- `results/toy_universe_simulation/trajectory_holdout_validation.csv`
- `results/toy_universe_simulation/toy_universe_summary.json`

### Figures

- `figures/toy_universe_simulation/top15_stability_scores.png`
- `figures/toy_universe_simulation/toy_universe_spacetime_comparison.png`
- `figures/toy_universe_simulation/compressibility_vs_persistent_structure.png`
- `figures/toy_universe_simulation/local_weight_sensitivity.png`
- `figures/toy_universe_simulation/global_weight_sensitivity.png`
- `figures/toy_universe_simulation/eca_rule_1_spacetime.png`
- `figures/toy_universe_simulation/eca_rule_33_spacetime.png`
- `figures/toy_universe_simulation/eca_rule_127_spacetime.png`
- `figures/toy_universe_simulation/eca_rule_110_spacetime.png`
- `figures/toy_universe_simulation/eca_rule_184_spacetime.png`
- `figures/toy_universe_simulation/eca_rule_30_spacetime.png`

## Reproducibility note

The v1.5.1 appendix packages the completed run artifacts. The original executable analysis code remains unchanged in `src/ofst_eca_analysis.py`; code, CSV, JSON, shell scripts, tests, and configuration files remain in their native formats.
