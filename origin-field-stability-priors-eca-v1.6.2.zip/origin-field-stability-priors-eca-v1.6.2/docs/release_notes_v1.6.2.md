# Release Notes v1.6.2

Version 1.6.2 adds resolution-convergence and prior-overlap diagnostics to the physical Lambda/G extension.

## Added

- `src/ofst_resolution_debug_v162.py`: reruns the finite-grid evidence calculation at 13x11, 25x21, 50x42, 100x84, and 200x168.
- `src/ofst_prior_diagnostic.py`: computes the 25x21 stability prior independently of the likelihood and compares the prior mass surface against the CMB shift-parameter likelihood surface.
- `results/physical_extension/resolution_debug.csv`
- `results/physical_extension/resolution_debug_summary.json`
- `results/physical_extension/prior_only_weights.csv`
- `results/physical_extension/prior_likelihood_overlap_summary.json`
- `figures/physical_extension/prior_only_heatmap.png`
- `docs/resolution_debug_note.md`
- `docs/prior_likelihood_overlap_note.md`

## Main result

The 50x42 BF stability/Jeffreys value is not convergence. The 200x168 run gives BF stability/Jeffreys = 58.762, compared with 52.369 at 100x84 and 94.966 at 50x42. The result is stabilizing in the elevated range, not falling back to the 9-10 range observed at 13x11 and 25x21.

The driver is prior-likelihood overlap along a narrow CMB shift-parameter ridge. The maximum likelihood is already close to one at the fine grids, so the elevated BF is not caused by a new likelihood ceiling.

## Prior-only diagnostic

On the 25x21 grid, the stability prior peaks at lambda=1.0779123358892524 and g=0.98. The concentration is driven by the declared score construction: curvature moderation, parameter moderation, and background-expansion regularity. This overlap should be interpreted as a finite-grid score-construction result, not as an independently established cosmological prior.
