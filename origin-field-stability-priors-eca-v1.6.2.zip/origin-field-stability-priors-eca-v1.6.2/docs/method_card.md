# Method Card

Version: 1.5.1

## Object of study

Complete finite ensemble of all 256 elementary cellular automata.

## Objective

Construct a stability-weighted Gibbs prior over a declared finite ensemble and audit the sensitivity of the resulting rankings.

## Main equation

\[
S_w(U)=w_C C(U)+w_A A(U)+w_O O(U)-w_R R(U).
\]

## Component definitions

- \(C(U)\): admissibility or consistency. Constant in this package.
- \(A(U)\): gzip-derived finite-trajectory compressibility score.
- \(O(U)\): persistent-structure proxy based on entropy, activity balance, temporal information persistence, spatial structure, and symbolic-dynamics summaries.
- \(R(U)\): perturbation fragility.

## Bundled output profile

The checked-in `results/` directory was generated with `--profile ci`:

```text
grid = 32 cells by 32 steps
random_initial_conditions = 6
fragility_initial_conditions = 3
weights = C=0.1, A=0.15, O=0.65, R=0.1
eta = 8.0
metric_variants = 19
model_averaging_weight_draws = 6
eta_grid = [0.0, 2.0, 8.0]
hyperparameter_combinations = 684
null_model_draws_per_null = 24
bootstrap_draws = 128
```

## Bundled base ranking

|       rule |   symmetry_class |        S |        A |        O |        R |
|-----------:|-----------------:|---------:|---------:|---------:|---------:|
|   1.000000 |         1.000000 | 0.616290 | 0.934426 | 0.580181 | 0.009920 |
| 127.000000 |         1.000000 | 0.608610 | 0.931694 | 0.582163 | 0.095494 |
|  33.000000 |        33.000000 | 0.588601 | 0.920765 | 0.551748 | 0.081497 |
| 123.000000 |        33.000000 | 0.588032 | 0.913934 | 0.543795 | 0.025252 |
| 198.000000 |       156.000000 | 0.571832 | 0.871585 | 0.540888 | 0.104829 |
| 199.000000 |        28.000000 | 0.570964 | 0.859290 | 0.540301 | 0.091252 |
|  70.000000 |        28.000000 | 0.569740 | 0.863388 | 0.540676 | 0.112075 |
| 156.000000 |       156.000000 | 0.563162 | 0.853825 | 0.531147 | 0.101580 |
|  28.000000 |        28.000000 | 0.562184 | 0.851093 | 0.529686 | 0.097752 |
| 157.000000 |        28.000000 | 0.560985 | 0.842896 | 0.529650 | 0.097224 |

## Uncertainty summary

| source                                             | metric                                  |   n |   estimate | ci_method                       |   ci_low |   ci_high |
|:---------------------------------------------------|:----------------------------------------|----:|-----------:|:--------------------------------|---------:|----------:|
| local_weight_sensitivity                           | top20_overlap_with_base                 |  12 |   0.966667 | nonparametric_bootstrap_mean_95 | 0.933333 |  1.000000 |
| global_simplex_sensitivity                         | top20_overlap_with_base                 |  16 |   0.350000 | nonparametric_bootstrap_mean_95 | 0.200156 |  0.479609 |
| hyperparameter_grid                                | top20_score_overlap_with_base_OFST      | 684 |   0.430263 | nonparametric_bootstrap_mean_95 | 0.408715 |  0.458271 |
| hyperparameter_grid                                | top20_prior_rank_overlap_with_base_OFST | 684 |   0.288596 | nonparametric_bootstrap_mean_95 | 0.268364 |  0.309942 |
| null_model:component_tuple_permutation             | top20_overlap_with_base                 |  24 |   0.091667 | nonparametric_bootstrap_mean_95 | 0.071198 |  0.110417 |
| null_model:component_tuple_permutation             | top1_match_rate                         |  24 |   0.000000 | wilson_proportion_95            | 0.000000 |  0.137976 |
| null_model:hamming_neighbor_score_substitution     | top20_overlap_with_base                 |  24 |   0.118750 | nonparametric_bootstrap_mean_95 | 0.091667 |  0.141667 |
| null_model:hamming_neighbor_score_substitution     | top1_match_rate                         |  24 |   0.000000 | wilson_proportion_95            | 0.000000 |  0.137976 |
| null_model:independent_component_permutation       | top20_overlap_with_base                 |  24 |   0.081250 | nonparametric_bootstrap_mean_95 | 0.062865 |  0.110417 |
| null_model:independent_component_permutation       | top1_match_rate                         |  24 |   0.000000 | wilson_proportion_95            | 0.000000 |  0.137976 |
| null_model:orbit_size_preserving_score_permutation | top20_overlap_with_base                 |  24 |   0.122917 | nonparametric_bootstrap_mean_95 | 0.106250 |  0.141302 |
| null_model:orbit_size_preserving_score_permutation | top1_match_rate                         |  24 |   0.000000 | wilson_proportion_95            | 0.000000 |  0.137976 |
| null_model:score_label_permutation                 | top20_overlap_with_base                 |  24 |   0.102083 | nonparametric_bootstrap_mean_95 | 0.083333 |  0.122917 |
| null_model:score_label_permutation                 | top1_match_rate                         |  24 |   0.000000 | wilson_proportion_95            | 0.000000 |  0.137976 |

## Null diagnostics

| null_model                              |   n_draws |   mean_top20_overlap_with_base |   mean_top20_overlap_ci_low |   mean_top20_overlap_ci_high |   top1_match_rate |   top1_match_rate_ci_low |   top1_match_rate_ci_high |   mean_score_rank_correlation_with_base |
|:----------------------------------------|----------:|-------------------------------:|----------------------------:|-----------------------------:|------------------:|-------------------------:|--------------------------:|----------------------------------------:|
| component_tuple_permutation             |        24 |                       0.091667 |                    0.070833 |                     0.114219 |          0.000000 |                 0.000000 |                  0.137976 |                                0.012392 |
| hamming_neighbor_score_substitution     |        24 |                       0.118750 |                    0.090313 |                     0.149635 |          0.000000 |                 0.000000 |                  0.137976 |                                0.221547 |
| independent_component_permutation       |        24 |                       0.081250 |                    0.066667 |                     0.100000 |          0.000000 |                 0.000000 |                  0.137976 |                               -0.002590 |
| orbit_size_preserving_score_permutation |        24 |                       0.122917 |                    0.098646 |                     0.143385 |          0.000000 |                 0.000000 |                  0.137976 |                                0.035282 |
| score_label_permutation                 |        24 |                       0.102083 |                    0.081615 |                     0.122552 |          0.000000 |                 0.000000 |                  0.137976 |                                0.025795 |

## Interpretation

The output supports a finite-ensemble reproducibility and audit claim. It does not establish physical law selection.
