# Jeffreys scale proxy note, v1.6.1

This note documents the Jeffreys proxy baseline used by the v1.6.0 physical extension and retained unchanged for the v1.6.1 diagnostics.

## Functional form actually used

The current code constructs the Jeffreys proxy in `src/ofst_physical_extension.py` inside `baseline_priors(...)` as a finite-grid prior over observable-valid candidates:

```text
pi_J_proxy(U_i) ∝ 1 / (lambda_i * g_i)
```

where:

```text
lambda_i = Lambda_i / Lambda_obs
g_i      = G_i / G_obs
```

Invalid observable candidates receive zero prior mass. The finite-grid normalization is:

```text
pi_J_proxy(U_i) = [I_valid(U_i) / (lambda_i * g_i)] / sum_j [I_valid(U_j) / (lambda_j * g_j)]
```

This is the exact prior used for the reported v1.6.0 result in which the stability prior beats the Jeffreys proxy by a Bayes factor of approximately 9.42.

## Why this proxy was chosen

The two varied physical quantities, Lambda and G, are positive scale parameters after nondimensionalization. A common scale-invariant reference density for a positive scale parameter x is proportional to 1/x. Applying that independently to the two positive ratios gives the product-form proxy:

```text
p(lambda, g) ∝ 1 / (lambda * g)
```

This is a simple declared baseline. It is useful because it tests the stability prior against a prior that does not privilege the linear coordinate volume of the finite grid.

It is still only a proxy. In the current implementation it is assigned directly as point mass over the finite candidate grid, rather than derived from the likelihood geometry of the observable map.

## What a true Jeffreys prior would require

A true Jeffreys prior is defined by the Fisher information matrix of the likelihood:

```text
pi_J(theta) ∝ sqrt(det I(theta))
```

with:

```text
theta = (lambda, g)
I_ab(theta) = E_D|theta[-d^2 log P(D | theta) / d theta_a d theta_b]
```

or equivalently, under regularity assumptions:

```text
I_ab(theta) = E_D|theta[(d log P(D | theta) / d theta_a)(d log P(D | theta) / d theta_b)]
```

For the simplified one-observable Gaussian shift-parameter likelihood used in this package, with fixed sigma_R and prediction R(theta), the local Fisher form would reduce to approximately:

```text
I_ab(theta) = (1 / sigma_R^2) * (dR(theta) / d theta_a) * (dR(theta) / d theta_b)
```

That matrix is rank-one for a single scalar observable and two varied parameters, so its determinant is zero or ill-conditioned without additional independent observables, covariance structure, regularization, or a different reference-prior construction. A domain-grade Jeffreys prior would require the full likelihood geometry, not just the scale nature of Lambda and G.

For this physical problem, a true reference prior would also need a better generative model: CAMB/CLASS or equivalent Boltzmann calculations, a full cosmological parameter vector, covariance matrices, nuisance parameters, recombination physics, perturbation growth, sound-horizon changes, and a physically specified varying-G theory.

## Interpretation gap

The reported `~9.42` Bayes factor is therefore not evidence against a mathematically exact Jeffreys prior. It is evidence against the specific finite-grid scale proxy defined above.

That distinction matters. If the true likelihood-derived Jeffreys/reference prior placed much more mass near the high-likelihood ridge, the stability-versus-Jeffreys Bayes factor could shrink. If it placed less mass there, the Bayes factor could grow. The current result should be read as:

```text
The declared stability prior outperforms the declared 1/(lambda*g) scale proxy on this compressed CMB-shift finite-grid demonstration.
```

It should not be read as:

```text
The stability prior outperforms the unique parameterization-invariant Jeffreys prior for cosmology.
```

The second claim would require a full Fisher/reference-prior derivation from a domain-complete observational likelihood.
