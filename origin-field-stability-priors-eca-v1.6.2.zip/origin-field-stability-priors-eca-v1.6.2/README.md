# Origin Field Stability Priors for Finite Model Ensembles

**ECA demonstration and physical-extension package, version 1.6.2**  
Release date: 2026-05-16

## Status

This repository implements bounded computational demonstrations of stability-weighted prior construction over finite ensembles. The original candidate ensemble is the set of all 256 elementary cellular automata. The physical extension is a separate Lambda/G candidate-grid workflow with a compressed CMB shift-parameter likelihood. The ECA pipeline remains isolated from the physical-extension diagnostics.

The supported claim is limited and operational:

> A declared stability score can be used to construct a reproducible Gibbs prior over a finite model ensemble, and the resulting rankings can be audited with metric sensitivity, hyperparameter sweeps, null models, uncertainty intervals, finite-size diagnostics, release validation, and finite-grid evidence diagnostics.

This package does not establish a new physical law or confirmed cosmological selection mechanism. The physical extension is a background-level compressed-data demonstration. It does not modify quantum mechanics, relativity, thermodynamics, quantum field theory, Lambda-CDM, or standard Bayesian model selection.

## v1.6.2 diagnostics

Version 1.6.2 adds two diagnostics to the physical-extension workflow:

- Resolution convergence through a 200x168 Lambda/G grid.
- Prior-only and prior-likelihood overlap analysis on the 25x21 grid.

Primary v1.6.2 files:

- `src/ofst_resolution_debug_v162.py`
- `src/ofst_prior_diagnostic.py`
- `results/physical_extension/resolution_debug.csv`
- `results/physical_extension/resolution_debug_summary.json`
- `results/physical_extension/prior_only_weights.csv`
- `results/physical_extension/prior_likelihood_overlap_summary.json`
- `figures/physical_extension/prior_only_heatmap.png`
- `docs/resolution_debug_note.md`
- `docs/prior_likelihood_overlap_note.md`

### Resolution convergence result

The stability/Jeffreys Bayes factor sequence is:

| Grid | BF stability/uniform | BF stability/Jeffreys proxy | BF stability/max-ent log |
|---:|---:|---:|---:|
| 13x11 | 1.934 | 10.413 | 1.610 |
| 25x21 | 1.916 | 9.419 | 1.575 |
| 50x42 | 16.610 | 94.966 | 17.520 |
| 100x84 | 9.587 | 52.369 | 9.686 |
| 200x168 | 10.908 | 58.762 | 10.923 |

The 50x42 result is not convergence. At 200x168, BF stability/Jeffreys is still elevated but closer to the 100x84 value. The 100x84-to-200x168 change is about 12.2%, so the value is stabilizing in the elevated range rather than falling back to 9-10.

### Prior-only result

On the 25x21 grid, the stability prior peaks near lambda=1.078 and g=0.98. That is near the lambda about 1.012, g about 0.976 region in coarse-grid terms, but it does not overlap the 25x21 likelihood peak. The prior concentration is driven by the declared score construction:

`S_w = 0.45 curvature_score + 0.35 moderation_score + 0.20 expansion_regularity_score`.

This means the elevated BF should be interpreted as a property of the current finite-grid score construction and compressed CMB shift-parameter likelihood, not as proof of a fundamental cosmological prior.

## v1.6.0 physical extension

Version 1.6.0 adds rungs 5-8 of the evidence ladder in a separate module:

- `src/ofst_physical_extension.py`
- `tests/test_ofst_physical_extension.py`
- `results/physical_extension/`
- `figures/physical_extension/`

The ECA analysis remains in `src/ofst_eca_analysis.py`.

### Rung 5: finite physical candidate space

The physical candidates are

```text
U_i = (lambda_i, g_i)
lambda = Lambda / Lambda_obs
g = G / G_obs
```

The checked-in grid uses 25 log-spaced values for `lambda_ratio` from 0.05 to 3.00 and 21 linearly spaced values for `g_ratio` from 0.80 to 1.20, for 525 total candidates. Curvature is derived by closure:

```text
Omega_k = 1 - g(Omega_m + Omega_r) - lambda Omega_Lambda.
```

Rung 5 outputs:

- `results/physical_extension/rung5_candidate_grid.csv`
- `figures/physical_extension/rung5_candidate_grid.png`

### Rung 6: observable map

Each candidate is mapped to the CMB shift parameter using a background-level FRW distance approximation:

```text
E^2(z) = g Omega_r (1+z)^4 + g Omega_m (1+z)^3 + Omega_k (1+z)^2 + lambda Omega_Lambda
chi(z*) = integral from 0 to z* of dz / E(z)
R(lambda,g) = sqrt(g Omega_m) S_k(chi)
```

Rung 6 outputs:

- `results/physical_extension/rung6_observable_predictions.csv`
- `figures/physical_extension/rung6_cmb_shift_observable_map.png`

### Rung 7: empirical likelihood

The likelihood uses the Planck 2018 non-flat CMB distance-prior shift parameter:

```text
R_obs = 1.7429
sigma_R = 0.0051
z* = 1089.46
log P(D | U_i) = -0.5 * ((R(U_i) - R_obs) / sigma_R)^2
```

This is grid-based because the candidate space is finite and bounded. Nested sampling is unnecessary for this release.

Rung 7 outputs:

- `results/physical_extension/rung7_likelihood_grid.csv`
- `figures/physical_extension/rung7_likelihood_chi2_heatmap.png`
- `results/physical_extension/planck2018_distance_prior_dataset.csv`

### Rung 8: evidence and Bayes factors

The stability prior is a declared pre-data Gibbs prior over the physical candidate grid. It is compared with three baselines:

- uniform model mass over observable-valid candidates;
- discrete scale-parameter Jeffreys proxy, proportional to `1 / (lambda_ratio * g_ratio)`;
- constrained maximum entropy over bounded `log Lambda` and `log G` support, discretized by log-cell area.

The original 25x21 Bayes factors are:

| baseline | BF baseline/stability | BF stability/baseline |
|:--|--:|--:|
| uniform | 0.521845 | 1.916278 |
| Jeffreys scale proxy | 0.106168 | 9.419057 |
| constrained max-entropy log | 0.635106 | 1.574540 |

Rung 8 outputs:

- `results/physical_extension/rung8_evidence_bayes_factors.csv`
- `results/physical_extension/rung8_posteriors_by_prior.csv`
- `figures/physical_extension/rung8_bayes_factor_comparison.png`

### Physical-extension run commands

```bash
python src/ofst_physical_extension.py
python src/ofst_resolution_debug_v162.py
python src/ofst_prior_diagnostic.py
```

### Interpretation boundary for the physical extension

The physical extension is not a full cosmological inference. It uses one compressed public CMB distance-prior datum and an analytical background-distance approximation. A domain cosmology analysis would replace this with CAMB or CLASS, vary the full cosmological parameter vector, include nuisance parameters and covariance matrices, and use the full Planck likelihood or public chains. The G-variation treatment here is background-level only and does not model recombination, perturbation growth, BBN, or sound-horizon changes caused by a real varying-G theory.

## v1.5.1 update

This release adds a packaged toy-universe stability simulation appendix. The run tested all 256 elementary cellular automata at 64 cells by 64 steps, using 10 random initial conditions and 4 fragility initial conditions. The top 10 rules were 1, 127, 33, 123, 156, 157, 28, 198, 70, 199. The local weight perturbation check had a mean top-20 overlap of 0.993; broad global weight changes had a mean top-20 overlap of 0.497.

The appendix, raw outputs, and figures are bundled in:

- `docs/toy_universe_simulation_appendix.md`
- `results/toy_universe_simulation/`
- `figures/toy_universe_simulation/`
- `pdf_reading_copies/`

The result should be read as a finite toy-model stability demonstration, not as empirical physics.

## Repository contents

```text
.
├── README.md
├── LICENSE
├── CITATION.cff
├── CHANGELOG.md
├── .zenodo.json
├── requirements.txt
├── pyproject.toml
├── src/
│   ├── ofst_eca_analysis.py
│   ├── ofst_physical_extension.py
│   ├── ofst_resolution_debug_v162.py
│   └── ofst_prior_diagnostic.py
├── tests/
│   ├── test_ofst_eca_analysis.py
│   ├── test_ofst_physical_extension.py
│   └── test_ofst_v162_diagnostics.py
├── scripts/
│   ├── run_analysis.sh
│   ├── run_tests.sh
│   ├── run_tests.bat
│   └── validate_release.py
├── docs/
│   ├── manuscript.md
│   ├── supplementary_note.md
│   ├── formal_core.md
│   ├── method_card.md
│   ├── origin_field_framework_context.md
│   ├── persistent_structure_metric_protocol.md
│   ├── robustness_protocol.md
│   ├── falsification_preregistration_protocol.md
│   ├── empirical_likelihood_protocol.md
│   ├── evidence_standard.md
│   ├── research_roadmap.md
│   ├── toy_universe_simulation_appendix.md
│   ├── jeffreys_proxy_note.md
│   ├── resolution_debug_note.md
│   ├── prior_likelihood_overlap_note.md
│   └── release_notes_v1.6.2.md
├── results/
│   ├── CI-profile CSV/JSON/Markdown outputs
│   ├── toy_universe_simulation/
│   └── physical_extension/
├── figures/
│   ├── CI-profile diagnostic figures
│   ├── toy_universe_simulation/
│   └── physical_extension/
└── pdf_reading_copies/
    └── PDF copies of readable documents
```

## Core model

For each candidate model \(U\), define

\[
S_w(U)=w_C C(U)+w_A A(U)+w_O O(U)-w_R R(U).
\]

In this ECA demonstration:

- \(C(U)\) is an admissibility indicator. It is constant, \(C=1\), for every ECA rule.
- \(A(U)\) is a finite-trajectory gzip-compressibility score.
- \(O(U)\) is a persistent-structure proxy based on finite binary histories. It is not an observer detector.
- \(R(U)\) is a perturbation-fragility penalty.
- \(w\) is a declared nonnegative weight vector.

The finite-ensemble Gibbs prior is

\[
P_G(U_i\mid \Theta,w,\eta)=
\frac{\pi_i\Theta_i\exp[\eta S_w(U_i)]}
{\sum_j \pi_j\Theta_j\exp[\eta S_w(U_j)]}.
\]

This is a prior over a declared ensemble. It becomes a posterior only after a likelihood \(P(D\mid U_i)\) is introduced.

## Run profiles

The checked-in outputs use the CI profile:

```bash
python src/ofst_eca_analysis.py --profile ci
```

To run the default profile:

```bash
python src/ofst_eca_analysis.py
```

To run the physical extension:

```bash
python src/ofst_physical_extension.py
```

To run tests:

```bash
python -m unittest discover -s tests
```

To validate the release package:

```bash
python scripts/validate_release.py
```

## Bundled CI-profile configuration

```text
n_cells = 32
n_steps = 32
random_initial_conditions = 6
fragility_initial_conditions = 3
weights = C=0.1, A=0.15, O=0.65, R=0.1
eta = 8.0
metric_variants = 19
model_averaging_weight_draws = 6
eta_grid = [0.0, 2.0, 8.0]
base_priors = uniform_raw_rules, uniform_symmetry_classes
hyperparameter_combinations = 684
null_model_draws_per_null = 24
bootstrap_draws = 128
```

## Bundled base ranking

|       rule |   symmetry_class |        S |        A |        O |        R |
|-----------:|-----------------:|---------:|---------:|---------:|---------:|
|   1.000000 |         1.000000 | 0.616290 | 0.934426 | 0.580181 | 0.009920 |
| 127.000000 |         1.000000 | 0.608610 | 0.931694 | 0.582163 | 0.095494 |
|  33.000000 |        33.000000 | 0.588601 | 0.920765 | 0.551748 | 0.081497 |
| 123.000000 |        33.000000 | 0.588032 | 0.913934 | 0.543795 | 0.025252 |
| 198.000000 |       156.000000 | 0.571832 | 0.871585 | 0.540888 | 0.104829 |
| 199.000000 |        28.000000 | 0.570964 | 0.859290 | 0.540301 | 0.091252 |
|  70.000000 |        28.000000 | 0.569740 | 0.863388 | 0.540676 | 0.112075 |
| 156.000000 |       156.000000 | 0.563162 | 0.853825 | 0.531147 | 0.101580 |
|  28.000000 |        28.000000 | 0.562184 | 0.851093 | 0.529686 | 0.097752 |
| 157.000000 |        28.000000 | 0.560985 | 0.842896 | 0.529650 | 0.097224 |

## Main diagnostics

The bundled robustness layer includes:

- 19 \(O(U)\)-metric variants;
- local and global weight sensitivity;
- eta sensitivity;
- raw-rule and symmetry-class base priors;
- raw-rule and symmetry-class aggregation;
- max, mean, and median class aggregation;
- seed and finite-size sensitivity;
- trajectory-holdout diagnostics;
- reference ECA baseline overlap;
- five null-model controls;
- bootstrap and Wilson uncertainty intervals;
- deterministic tests, manifest, and SHA-256 checksums.

## Null-model summary

| null_model                              |   n_draws |   mean_top20_overlap_with_base |   mean_top20_overlap_ci_low |   mean_top20_overlap_ci_high |   top1_match_rate |   top1_match_rate_ci_low |   top1_match_rate_ci_high |   mean_score_rank_correlation_with_base |
|:----------------------------------------|----------:|-------------------------------:|----------------------------:|-----------------------------:|------------------:|-------------------------:|--------------------------:|----------------------------------------:|
| component_tuple_permutation             |        24 |                       0.091667 |                    0.070833 |                     0.114219 |          0.000000 |                 0.000000 |                  0.137976 |                                0.012392 |
| hamming_neighbor_score_substitution     |        24 |                       0.118750 |                    0.090313 |                     0.149635 |          0.000000 |                 0.000000 |                  0.137976 |                                0.221547 |
| independent_component_permutation       |        24 |                       0.081250 |                    0.066667 |                     0.100000 |          0.000000 |                 0.000000 |                  0.137976 |                               -0.002590 |
| orbit_size_preserving_score_permutation |        24 |                       0.122917 |                    0.098646 |                     0.143385 |          0.000000 |                 0.000000 |                  0.137976 |                                0.035282 |
| score_label_permutation                 |        24 |                       0.102083 |                    0.081615 |                     0.122552 |          0.000000 |                 0.000000 |                  0.137976 |                                0.025795 |

## Key interpretation

The CI-profile ECA result supports the method as a transparent finite-ensemble prior-construction pipeline. The v1.6.0 physical extension adds a bounded empirical likelihood demonstration and Bayes-factor comparison, but it still does not support the stronger claim that the procedure selects real physical laws.

For empirical extensions, use the posterior form

\[
P(U_i\mid D)\propto P(D\mid U_i)P_G(U_i),
\]

with a declared dataset \(D\), a likelihood \(P(D\mid U_i)\), and comparison against baseline priors.
