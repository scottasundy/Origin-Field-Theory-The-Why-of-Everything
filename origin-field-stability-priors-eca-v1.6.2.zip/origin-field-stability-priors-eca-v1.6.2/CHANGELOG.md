# Changelog

## v1.6.2 - 2026-05-16

- Added 200x168 resolution-convergence diagnostics for the physical Lambda/G evidence calculation.
- Added prior-only 25x21 stability-prior weights and heatmap.
- Added prior-likelihood overlap note identifying the current score-construction driver of the elevated Bayes factor.
- Regenerated current manifest, checksums, and readable PDF copies.

## v1.6.0 - 2026-05-16

- Added `src/ofst_physical_extension.py`, a separate physical-extension pipeline for evidence rungs 5-8.
- Preserved the existing ECA pipeline without changing `src/ofst_eca_analysis.py`.
- Added a finite bounded Lambda/G candidate grid: 25 log-spaced Lambda/Lambda_obs values from 0.05 to 3.00 and 21 linearly spaced G/G_obs values from 0.80 to 1.20.
- Added a CMB shift-parameter observable map using background-level FRW distance approximations.
- Added a finite-grid Gaussian likelihood using the Planck 2018 non-flat CMB distance-prior value R = 1.7429 +/- 0.0051.
- Added evidence comparison against uniform, scale-parameter Jeffreys proxy, and constrained max-entropy-over-log-support baselines.
- Added physical-extension CSV outputs, diagnostic figures for rungs 5-8, domain-expertise notes, summary JSON, and unit tests.

## v1.5.1 - 2026-05-16

- Added packaged toy-universe stability simulation appendix using all 256 elementary cellular automata.
- Added raw toy-universe simulation outputs under `results/toy_universe_simulation/`.
- Added toy-universe simulation figures under `figures/toy_universe_simulation/`.
- Added PDF reading copies for human-facing documentation under `pdf_reading_copies/`.
- Preserved source code, unit tests, CI-profile baseline outputs, and the conservative claim boundary from v1.5.0.

## v1.5.0 — 2026-05-16

- Publication package for finite-ensemble stability-prior construction over the complete ECA ensemble.
- Bootstrap and Wilson uncertainty intervals for robustness and null-model diagnostics.
- Finite-size ranking-stability figure and bundled finite-size summary output.
- Empirical likelihood protocol for future dataset-facing extensions.
- Evidence standard distinguishing finite prior construction from physical law-selection evidence.
- Updated release validation, manifest, checksums, and test contracts.

## v1.4.1 — 2026-05-16

- Publication package for the finite-ensemble ECA demonstration.
- Repository-level Origin Field Stability terminology.
- Persistent-structure interpretation for \(O(U)\).
- Covariance-preserving, orbit-size-preserving, and local Hamming-neighbor null diagnostics.
- Release validation script for metadata, output contracts, and checksums.
- Bundled CI-profile results, figures, summary files, manifest, and checksums.

## v1.4.0 — 2026-05-16

- Added symbolic-dynamics diagnostics: normalized block entropy, bounded initial-segment Lempel-Ziv complexity, and an excess-entropy-style mutual-information proxy.
- Expanded the \(O(U)\) robustness family from 14 to 19 variants while keeping the base score backward-compatible.
- Added hand-declared ECA reference baselines and overlap diagnostics.
- Added metric rank-correlation diagnostics.
- Added null-model diagnostics for score-label permutation and independent component permutation.
- Added `default`, `ci`, and `tiny` run profiles.
- Added runtime environment metadata.
- Preserved the conservative claim posture: these are finite toy-ensemble diagnostics, not evidence for physical law selection.

## v1.3.0 — 2026-05-16

- Decoupled the base \(O(U)\) persistent-structure metric from gzip-derived \(A(U)\) compressibility.
- Expanded the preregistered \(O(U)\) robustness family to 14 variants.
- Separated score-rank frequencies from Gibbs-prior-rank frequencies and model-averaged prior mass.
- Added max, mean, and median symmetry-class aggregation diagnostics.
- Added trajectory-holdout diagnostics.
- Reduced default robustness-grid size to a CI-friendly scale.
