from pathlib import Path

import pandas as pd

from ofst_physical_extension import PhysicalExtensionConfig
from ofst_physical_sensitivity import (
    run_grid_resolution_sensitivity,
    run_shift_parameter_sensitivity,
    run,
)


def test_grid_resolution_sensitivity_contract():
    df = run_grid_resolution_sensitivity(PhysicalExtensionConfig(integration_steps=512))
    assert set(df["run_label"]) == {"25x21", "50x42", "13x11"}
    for column in [
        "bf_stability_vs_uniform",
        "bf_stability_vs_jeffreys",
        "bf_stability_vs_maxent_log",
        "uniform_bf_flag_gt20pct_vs_25x21",
    ]:
        assert column in df.columns
    assert (df["bf_stability_vs_uniform"] > 0).all()


def test_shift_parameter_sensitivity_contract():
    df = run_shift_parameter_sensitivity(PhysicalExtensionConfig(integration_steps=512))
    assert len(df) == 15
    assert set(df["r_offset_sigma_units"]) == {-5, -2, 0, 2, 5}
    assert set(df["sigma_R_multiplier"]) == {0.5, 1.0, 2.0}
    assert "jeffreys_bf_below_3_flag" in df.columns
    assert (df["bf_stability_vs_jeffreys"] > 0).all()


def test_sensitivity_run_writes_outputs(tmp_path: Path):
    results_dir = tmp_path / "results"
    figures_dir = tmp_path / "figures"
    summary = run(
        PhysicalExtensionConfig(
            results_dir=str(results_dir),
            figures_dir=str(figures_dir),
            integration_steps=512,
        )
    )
    assert summary["version"] == "1.6.1"
    assert (results_dir / "grid_resolution_sensitivity.csv").exists()
    assert (results_dir / "shift_parameter_sensitivity.csv").exists()
    assert (figures_dir / "grid_resolution_bayes_factors.png").exists()
    assert (figures_dir / "shift_parameter_sensitivity.png").exists()
    grid = pd.read_csv(results_dir / "grid_resolution_sensitivity.csv")
    shift = pd.read_csv(results_dir / "shift_parameter_sensitivity.csv")
    assert len(grid) == 3
    assert len(shift) == 15
