import json
from pathlib import Path

import pandas as pd

from ofst_physical_extension import PhysicalExtensionConfig
from ofst_prior_diagnostic import run as run_prior_diagnostic


def test_v162_checked_in_resolution_outputs():
    summary_path = Path("results/physical_extension/resolution_debug_summary.json")
    csv_path = Path("results/physical_extension/resolution_debug.csv")
    assert summary_path.exists()
    assert csv_path.exists()
    summary = json.loads(summary_path.read_text(encoding="utf-8"))
    assert "200x168" in summary["resolutions"]
    bf = summary["bayes_factor_series"]["stability_vs_jeffreys_scale_proxy"]["200x168"]
    assert bf > 0
    df = pd.read_csv(csv_path)
    assert "200x168" in set(df["resolution_label"])
    assert {"evidence_summary", "highest_likelihood", "top20_posterior"}.issubset(set(df["record_type"]))


def test_v162_prior_outputs():
    csv_path = Path("results/physical_extension/prior_only_weights.csv")
    assert csv_path.exists()
    df = pd.read_csv(csv_path)
    assert list(df.columns) == ["candidate_id", "lambda_ratio", "g_ratio", "stability_score", "prior_weight"]
    assert len(df) == 525
    assert abs(float(df["prior_weight"].sum()) - 1.0) < 1e-12
    assert Path("figures/physical_extension/prior_only_heatmap.png").exists()
    assert Path("docs/prior_likelihood_overlap_note.md").exists()


def test_v162_run_functions_write_outputs(tmp_path: Path, monkeypatch):
    monkeypatch.chdir(tmp_path)
    config = PhysicalExtensionConfig(
        results_dir="results/physical_extension",
        figures_dir="figures/physical_extension",
        integration_steps=512,
    )
    prior_summary = run_prior_diagnostic(config)
    assert prior_summary["grid"] == "25x21"
    assert Path("results/physical_extension/prior_only_weights.csv").exists()
    assert Path("figures/physical_extension/prior_only_heatmap.png").exists()
