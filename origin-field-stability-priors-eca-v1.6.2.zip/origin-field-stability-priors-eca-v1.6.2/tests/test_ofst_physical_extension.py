import csv
import json
import tempfile
import unittest
from pathlib import Path
import sys

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

import ofst_physical_extension as phys


def read_csv_rows(path: Path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


class PhysicalExtensionContractTests(unittest.TestCase):
    def test_candidate_grid_contract(self):
        rows = read_csv_rows(REPO / "results" / "physical_extension" / "rung5_candidate_grid.csv")
        self.assertEqual(len(rows), 25 * 21)
        self.assertIn("lambda_ratio", rows[0])
        self.assertIn("g_ratio", rows[0])
        self.assertIn("omega_k_derived", rows[0])
        self.assertEqual(rows[0]["candidate_id"], "U00_00")

    def test_observable_and_likelihood_outputs_exist(self):
        rung6 = read_csv_rows(REPO / "results" / "physical_extension" / "rung6_observable_predictions.csv")
        rung7 = read_csv_rows(REPO / "results" / "physical_extension" / "rung7_likelihood_grid.csv")
        self.assertEqual(len(rung6), 525)
        self.assertEqual(len(rung7), 525)
        self.assertIn("cmb_shift_R_pred", rung6[0])
        self.assertIn("log_likelihood", rung7[0])
        self.assertGreater(sum(row["observable_valid"] == "True" for row in rung7), 400)

    def test_evidence_outputs_compare_baselines_to_stability(self):
        rows = read_csv_rows(REPO / "results" / "physical_extension" / "rung8_evidence_bayes_factors.csv")
        names = {row["prior_name"] for row in rows}
        self.assertEqual(names, {"stability", "uniform", "jeffreys_scale_proxy", "constrained_max_entropy_log"})
        for row in rows:
            self.assertIn("bayes_factor_vs_stability", row)
            self.assertIn("bayes_factor_stability_vs_prior", row)
            self.assertGreater(float(row["evidence"]), 0.0)
        stability = next(row for row in rows if row["prior_name"] == "stability")
        self.assertAlmostEqual(float(stability["bayes_factor_vs_stability"]), 1.0, places=12)

    def test_summary_and_figures_exist(self):
        summary = json.loads((REPO / "results" / "physical_extension" / "physical_extension_summary.json").read_text())
        self.assertEqual(summary["version"], "1.6.0")
        self.assertEqual(summary["n_candidates_total"], 525)
        for filename in [
            "rung5_candidate_grid.png",
            "rung6_cmb_shift_observable_map.png",
            "rung7_likelihood_chi2_heatmap.png",
            "rung8_bayes_factor_comparison.png",
        ]:
            self.assertTrue((REPO / "figures" / "physical_extension" / filename).exists())

    def test_tiny_physical_run(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            config = phys.PhysicalExtensionConfig(
                lambda_points=7,
                g_points=5,
                integration_steps=512,
                results_dir=str(tmp / "results"),
                figures_dir=str(tmp / "figures"),
            )
            summary = phys.run(config)
            self.assertEqual(summary["n_candidates_total"], 35)
            self.assertTrue((tmp / "results" / "rung8_evidence_bayes_factors.csv").exists())
            self.assertTrue((tmp / "figures" / "rung8_bayes_factor_comparison.png").exists())


if __name__ == "__main__":
    unittest.main()
