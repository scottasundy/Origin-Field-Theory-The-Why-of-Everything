import argparse
import csv
import json
import unittest
from pathlib import Path
import sys
import tempfile

import numpy as np
import pandas as pd

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "src"))

import ofst_eca_analysis as demo


def read_csv_rows(path):
    with path.open(newline="") as handle:
        return list(csv.DictReader(handle))


class OutputContractTests(unittest.TestCase):
    def test_run_summary_contract(self):
        summary = json.loads((REPO / "results" / "run_summary.json").read_text())
        self.assertEqual(summary["n_models"], 256)
        self.assertEqual(len(summary["top10_OFST_rules"]), 10)
        self.assertGreater(summary["gibbs_mass_top20"], summary["gibbs_mass_top10"])
        self.assertGreater(summary["effective_model_count_ipr"], 50)
        self.assertIn("interpretation_note", summary)
        self.assertEqual(summary["bootstrap_draws"], 128)
        self.assertIn("uncertainty_summary", summary)
        self.assertGreaterEqual(len(summary["uncertainty_summary"]), 10)
        self.assertIn("robustness_diagnostics", summary)
        self.assertGreaterEqual(len(summary["robustness_diagnostics"]["metric_variants"]), 19)
        self.assertEqual(summary["robustness_diagnostics"]["n_hyperparameter_combinations"], 684)
        self.assertIn("trajectory_holdout_early_O_to_late_O_rank_correlation", summary["robustness_diagnostics"])

    def test_rankings_have_symmetry_classes_and_normalized_gibbs_weight(self):
        rankings = read_csv_rows(REPO / "results" / "ofst_rankings.csv")
        self.assertIn("symmetry_class", rankings[0])
        self.assertIn("gibbs_weight", rankings[0])
        self.assertIn("compression_window", rankings[0])
        mass = sum(float(row["gibbs_weight"]) for row in rankings)
        self.assertAlmostEqual(mass, 1.0, places=10)

    def test_class_rankings_are_present_and_masses_sum(self):
        classes = read_csv_rows(REPO / "results" / "ofst_class_rankings.csv")
        self.assertIn("gibbs_mass", classes[0])
        mass = sum(float(row["gibbs_mass"]) for row in classes)
        self.assertAlmostEqual(mass, 1.0, places=10)
        members = []
        for row in classes:
            members.extend(json.loads(row["members"]))
        self.assertEqual(sorted(members), list(range(256)))

    def test_config_snapshot_is_present(self):
        config = json.loads((REPO / "results" / "config_snapshot.json").read_text())
        self.assertEqual(config["seed"], 20260516)
        self.assertEqual(config["n_cells"], 32)
        self.assertEqual(config["weights"], {"C": 0.1, "A": 0.15, "O": 0.65, "R": 0.1})
        self.assertEqual(config["model_averaging_weight_draws"], 6)
        self.assertEqual(config["bootstrap_draws"], 128)
        self.assertIn("Gibbs-style stability prior", config["interpretation"])

    def test_o_metric_sensitivity_is_present(self):
        rows = read_csv_rows(REPO / "results" / "o_metric_sensitivity.csv")
        variants = {row["variant"] for row in rows}
        for variant in [
            "base_geometric",
            "with_compression_window_geometric",
            "harmonic_mean_guardrail",
            "late_holdout_geometric",
            "compression_only_window",
        ]:
            self.assertIn(variant, variants)
        base = next(row for row in rows if row["variant"] == "base_geometric")
        self.assertEqual(len(json.loads(base["top10_rules"])), 10)
        self.assertAlmostEqual(float(base["top20_overlap_with_base_O"]), 1.0)

    def test_robustness_outputs_are_present_and_separated(self):
        registry = json.loads((REPO / "results" / "metric_registry.json").read_text())
        self.assertIn("base_geometric", registry)
        self.assertFalse(registry["base_geometric"]["uses_compression_window"])
        self.assertTrue(registry["with_compression_window_geometric"]["uses_compression_window"])
        self.assertTrue(registry["predictive_stability_geometric"]["uses_holdout_feature"])

        rule_rows = read_csv_rows(REPO / "results" / "metric_robustness_rules.csv")
        class_rows = read_csv_rows(REPO / "results" / "metric_robustness_classes.csv")
        combo_rows = read_csv_rows(REPO / "results" / "hyperparameter_combo_summary.csv")
        eta_rows = read_csv_rows(REPO / "results" / "eta_sensitivity.csv")
        prior_rows = read_csv_rows(REPO / "results" / "base_prior_sensitivity.csv")
        holdout_rows = read_csv_rows(REPO / "results" / "trajectory_holdout_validation.csv")

        for col in [
            "score_top20_frequency",
            "score_top20_frequency_ci_low",
            "score_top20_frequency_ci_high",
            "prior_top20_frequency",
            "prior_top20_frequency_ci_low",
            "prior_top20_frequency_ci_high",
            "model_averaged_prior_mass",
        ]:
            self.assertIn(col, rule_rows[0])
        for col in [
            "score_top5_frequency_max",
            "score_top5_frequency_max_ci_low",
            "score_top5_frequency_max_ci_high",
            "score_top5_frequency_mean",
            "score_top5_frequency_median",
            "prior_top5_frequency",
            "prior_top5_frequency_ci_low",
            "prior_top5_frequency_ci_high",
        ]:
            self.assertIn(col, class_rows[0])
        self.assertIn("top20_score_overlap_with_base_OFST", combo_rows[0])
        self.assertIn("top20_prior_rank_overlap_with_base_OFST", combo_rows[0])
        self.assertIn("top20_prior_mass", eta_rows[0])
        self.assertEqual({row["base_prior"] for row in prior_rows}, {"uniform_raw_rules", "uniform_symmetry_classes"})
        self.assertTrue(any(row["validation"] == "early_O_predicts_late_O_rank_correlation" for row in holdout_rows))
        self.assertTrue((REPO / "results" / "reference_eca_baselines.csv").exists())
        self.assertTrue((REPO / "results" / "reference_baseline_overlap.csv").exists())
        self.assertTrue((REPO / "results" / "metric_correlations.csv").exists())
        self.assertTrue((REPO / "results" / "null_model_summary.csv").exists())
        null_rows = read_csv_rows(REPO / "results" / "null_model_summary.csv")
        for col in [
            "mean_top20_overlap_ci_low",
            "mean_top20_overlap_ci_high",
            "top1_match_rate_ci_low",
            "top1_match_rate_ci_high",
            "mean_score_rank_correlation_ci_low",
            "mean_score_rank_correlation_ci_high",
        ]:
            self.assertIn(col, null_rows[0])
        self.assertEqual(
            {row["null_model"] for row in null_rows},
            {
                "component_tuple_permutation",
                "hamming_neighbor_score_substitution",
                "independent_component_permutation",
                "orbit_size_preserving_score_permutation",
                "score_label_permutation",
            },
        )
        self.assertTrue((REPO / "results" / "uncertainty_summary.csv").exists())
        uncertainty_rows = read_csv_rows(REPO / "results" / "uncertainty_summary.csv")
        self.assertGreaterEqual(len(uncertainty_rows), 10)
        for row in uncertainty_rows:
            self.assertLessEqual(float(row["ci_low"]), float(row["estimate"]))
            self.assertLessEqual(float(row["estimate"]), float(row["ci_high"]))
        self.assertTrue((REPO / "results" / "environment.json").exists())
        self.assertTrue((REPO / "results" / "claim_ledger.md").exists())

    def test_seed_and_size_sensitivity_are_present(self):
        seed_rows = read_csv_rows(REPO / "results" / "seed_sensitivity.csv")
        size_rows = read_csv_rows(REPO / "results" / "size_sensitivity.csv")
        self.assertEqual(len(seed_rows), 2)
        self.assertEqual(len(size_rows), 3)
        self.assertIn("top20_overlap_with_base", seed_rows[0])
        self.assertIn("top20_overlap_with_base", size_rows[0])
        self.assertGreaterEqual(float(seed_rows[0]["top20_overlap_with_base"]), 0.9)
        self.assertIn(size_rows[1]["label"], {"32x32"})
        self.assertTrue((REPO / "figures" / "finite_size_ranking_stability.png").exists())

    def test_tiny_end_to_end_run(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            tmp = Path(tmpdir)
            config = demo.RunConfig(
                n_cells=16,
                n_steps=16,
                n_random_initial_conditions=3,
                n_fragility_initial_conditions=2,
                local_sensitivity_draws=5,
                global_sensitivity_draws=7,
                seed_sensitivity_runs=2,
                model_averaging_weight_draws=5,
                model_averaging_eta_grid=[0.0, 2.0],
                bootstrap_draws=64,
                selected_figure_rules=[],
                output_results_dir=str(tmp / "results"),
                output_figures_dir=str(tmp / "figures"),
            ).validate()
            summary = demo.run(config)
            self.assertEqual(summary["n_models"], 256)
            self.assertTrue((tmp / "results" / "seed_sensitivity.csv").exists())
            self.assertTrue((tmp / "results" / "size_sensitivity.csv").exists())
            self.assertTrue((tmp / "results" / "metric_robustness_rules.csv").exists())
            self.assertTrue((tmp / "results" / "trajectory_holdout_validation.csv").exists())
            self.assertTrue((tmp / "results" / "null_model_summary.csv").exists())
            self.assertTrue((tmp / "results" / "uncertainty_summary.csv").exists())
            self.assertTrue((tmp / "figures" / "finite_size_ranking_stability.png").exists())
            self.assertTrue((tmp / "results" / "metric_correlations.csv").exists())


class ECATransformationTests(unittest.TestCase):
    def test_eca_symmetry_helpers(self):
        self.assertEqual(demo.reflect_rule(demo.reflect_rule(30)), 30)
        self.assertEqual(demo.conjugate_rule(demo.conjugate_rule(30)), 30)
        self.assertEqual(set(demo.symmetry_orbit(177)), {58, 114, 163, 177})

    def test_rule_204_is_identity(self):
        state = np.array([[0, 1, 0, 1, 1, 0, 0, 1]], dtype=np.uint8)
        np.testing.assert_array_equal(demo.eca_step_batch(state, 204), state)

    def test_rule_0_and_255_are_constant(self):
        state = np.array([[0, 1, 0, 1, 1, 0, 0, 1]], dtype=np.uint8)
        np.testing.assert_array_equal(demo.eca_step_batch(state, 0), np.zeros_like(state))
        np.testing.assert_array_equal(demo.eca_step_batch(state, 255), np.ones_like(state))


class MetricTests(unittest.TestCase):
    def test_binary_entropy_bounds(self):
        self.assertEqual(demo.binary_entropy(0.0), 0.0)
        self.assertEqual(demo.binary_entropy(1.0), 0.0)
        self.assertAlmostEqual(demo.binary_entropy(0.5), 1.0)

    def test_normalized_mi_self_is_one_for_nonconstant_binary_data(self):
        x = np.array([0, 1, 0, 1, 1, 0], dtype=np.uint8)
        self.assertAlmostEqual(demo.normalized_mi_binary(x, x), 1.0)

    def test_parse_weights(self):
        weights = demo.parse_weights("C=0.1,A=0.2,O=0.6,R=0.1")
        self.assertEqual(weights, {"C": 0.1, "A": 0.2, "O": 0.6, "R": 0.1})
        with self.assertRaises(argparse.ArgumentTypeError):
            demo.parse_weights("C=0.1,A=0.2,O=0.6")

    def test_base_o_excludes_compression_window(self):
        row = pd.Series(
            {
                "entropy": 0.8,
                "activity_balance": 0.7,
                "time_mi": 0.4,
                "lag5_mi": 0.3,
                "spatial_mi": 0.5,
                "edge_balance": 0.6,
                "compression_window": 0.1,
            }
        )
        base_a = demo.structural_persistence_proxy(row)
        row["compression_window"] = 0.9
        base_b = demo.structural_persistence_proxy(row)
        self.assertAlmostEqual(base_a, base_b)

        row_low = row.copy()
        row_high = row.copy()
        row_low["compression_window"] = 0.1
        row_high["compression_window"] = 0.9
        compressed_a = demo.alternative_o_score(row_low, "with_compression_window_geometric")
        compressed_b = demo.alternative_o_score(row_high, "with_compression_window_geometric")
        self.assertNotAlmostEqual(compressed_a, compressed_b)

    def test_symbolic_dynamics_helpers_are_bounded(self):
        bits = np.array([0, 1, 0, 1, 1, 0, 1, 0], dtype=np.uint8)
        self.assertGreaterEqual(demo.normalized_block_entropy(bits, 2), 0.0)
        self.assertLessEqual(demo.normalized_block_entropy(bits, 2), 1.0)
        self.assertGreaterEqual(demo.lz76_complexity_sample(bits), 0.0)
        self.assertLessEqual(demo.lz76_complexity_sample(bits), 1.0)

    def test_wilson_interval_bounds(self):
        lo, hi = demo.wilson_interval(0, 24)
        self.assertEqual(lo, 0.0)
        self.assertGreater(hi, 0.0)
        self.assertLessEqual(hi, 1.0)

    def test_eta_zero_returns_base_prior(self):
        base_prior = np.array([0.2, 0.3, 0.5])
        score = np.array([10.0, 0.0, -10.0])
        probs = demo._gibbs_from_score(score, 0.0, base_prior)
        np.testing.assert_allclose(probs, base_prior)

    def test_symmetry_classes_partition_rules(self):
        df = pd.DataFrame({"rule": list(range(256)), "S": np.zeros(256), "rank_OFST": np.arange(1, 257), "gibbs_weight": np.ones(256) / 256})
        _, class_df = demo.add_symmetry_classes(df)
        members = []
        for raw in class_df["members"]:
            members.extend(json.loads(raw))
        self.assertEqual(sorted(members), list(range(256)))


if __name__ == "__main__":
    unittest.main()
