# PDF Reading Copies

This directory contains PDF copies of the main readable package documents. Source Markdown files remain in the repository for version control and review.
