# Claim Ledger

This ledger summarizes the robustness layer and uses conservative claim language.

## Robust claims
- At least one symmetry class remains a top-5 score-ranked candidate across more than 70% of metric/weight combinations under max-member class aggregation.
  - class 1: score-top-5 frequency 0.754, prior-top-5 frequency 0.437, model-averaged mass 0.017511, members [1, 127]

## Suggestive or partial claims
- Mean score-ranked top-20 overlap with the declared base-score top-20 is 0.430.
- Mean prior-ranked top-20 overlap with the declared base-score top-20 is 0.289.
- Early-run O-proxy to late-run O-proxy rank correlation is 0.489. This is a trajectory-holdout toy diagnostic, not empirical physics.
  - class 33: score-top-5 frequency 0.658, mean-aggregation top-5 frequency 0.544, median-aggregation top-5 frequency 0.544

## Unsupported or out-of-scope claims
- The identity of the single top raw ECA rule should not be treated as robust physical content.
- The base O(U) metric is not claimed to be uniquely correct.
- The ECA demonstration is not evidence that OFST is a physical law-selection principle.
- Class rankings based on max-member aggregation should be compared against mean and median aggregation columns before making class-level claims.

Top raw rules by score-top-20 frequency:
- rule 1 / class 1: score-top-20 frequency 0.798, prior-top-20 frequency 0.890, label robust
- rule 123 / class 33: score-top-20 frequency 0.728, prior-top-20 frequency 0.516, label robust
- rule 127 / class 1: score-top-20 frequency 0.596, prior-top-20 frequency 0.418, label suggestive
- rule 33 / class 33: score-top-20 frequency 0.561, prior-top-20 frequency 0.558, label suggestive
- rule 198 / class 156: score-top-20 frequency 0.465, prior-top-20 frequency 0.319, label weak
- rule 199 / class 28: score-top-20 frequency 0.465, prior-top-20 frequency 0.193, label weak
- rule 55 / class 19: score-top-20 frequency 0.447, prior-top-20 frequency 0.323, label weak
- rule 70 / class 28: score-top-20 frequency 0.447, prior-top-20 frequency 0.184, label weak
- rule 13 / class 13: score-top-20 frequency 0.439, prior-top-20 frequency 0.326, label weak
- rule 156 / class 156: score-top-20 frequency 0.430, prior-top-20 frequency 0.307, label weak
