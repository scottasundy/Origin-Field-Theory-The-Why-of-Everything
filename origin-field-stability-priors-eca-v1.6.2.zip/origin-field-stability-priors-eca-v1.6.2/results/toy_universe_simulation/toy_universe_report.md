# Toy Universe Stability Simulation Report

This run uses the Origin Field Stability Priors ECA package logic on all 256 elementary cellular automata.

Interpretation: finite toy-model ranking only. This is a demonstration of stability-weighted prior construction, not physical proof.

## Configuration

- Rules tested: 256
- Cells: 64
- Steps: 64
- Random initial conditions: 10
- Fragility initial conditions: 4
- Weights: {'C': 0.1, 'A': 0.15, 'O': 0.65, 'R': 0.1}
- Eta: 8.0
- Runtime: 9.94 seconds

## Top 10 Rules

|   rule |   symmetry_class |        S |        A |        O |          R |   gibbs_weight |
|-------:|-----------------:|---------:|---------:|---------:|-----------:|---------------:|
|      1 |                1 | 0.616223 | 0.969982 | 0.575869 | 0.0358969  |      0.0197807 |
|    127 |                1 | 0.615364 | 0.969782 | 0.57979  | 0.0696742  |      0.0196452 |
|     33 |               33 | 0.610235 | 0.948569 | 0.567005 | 0.00604175 |      0.0188555 |
|    123 |               33 | 0.605091 | 0.948369 | 0.566999 | 0.0571342  |      0.0180954 |
|    156 |              156 | 0.590621 | 0.929358 | 0.545561 | 0.0339739  |      0.0161173 |
|    157 |               28 | 0.589728 | 0.922554 | 0.545614 | 0.0330396  |      0.0160026 |
|     28 |               28 | 0.588844 | 0.924355 | 0.545624 | 0.0446487  |      0.0158898 |
|    198 |              156 | 0.586593 | 0.929358 | 0.545929 | 0.07665    |      0.0156062 |
|     70 |               28 | 0.586521 | 0.926156 | 0.54611  | 0.0737396  |      0.0155973 |
|    199 |               28 | 0.586082 | 0.924755 | 0.546097 | 0.0759492  |      0.0155425 |


## Stability Diagnostics

- Local ±25% weight perturbation, mean top-20 overlap: 0.993; min: 0.950; max: 1.000

- Broad global weight sweep, mean top-20 overlap: 0.497; min: 0.050; max: 0.950

- Early O to late O rank correlation: 0.600

- Early O top-20 overlap with late O top-20: 0.850


## Main Read

The top rules were not maximally chaotic rules. The highest-ranking rules favored compressible but nontrivial persistent structure with low fragility. The ranking is stable under small local weight changes, but much less stable under broad changes to the scoring philosophy. That means the framework is internally coherent under its declared weights, but the chosen definition of stability still matters heavily.
