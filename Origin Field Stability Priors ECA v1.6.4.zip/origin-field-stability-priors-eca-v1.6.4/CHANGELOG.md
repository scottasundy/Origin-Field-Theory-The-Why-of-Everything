# Changelog

## v1.6.4 - 2026-05-16

- Cleaned release structure for GitHub and Zenodo upload.
- Updated package metadata, validation contracts, and bundled summaries to version 1.6.4.
- Removed stale PDF copies and previous per-release note files.
- Replaced draft-style filenames with release-facing document names.
- Added clean PDF exports under `pdfs/` for the main release-facing Markdown documents.
- Preserved the finite-ensemble claim boundary and the physical-extension limitation that the \(\Lambda/G\) workflow is a compressed background-level diagnostic, not a self-consistent varying-\(G\) cosmology.

## v1.6.3 - 2026-05-16

- Added explicit claim-boundary documentation.
- Updated package metadata and stale documentation version headers.
- Clarified that the implemented scale baseline is a finite-grid scale proxy retained under the legacy output key `jeffreys_scale_proxy`.
- Strengthened the interpretation boundary for the \(\Lambda/G\) physical extension.
- Added a concrete path toward domain-grade cosmology likelihood work.

## v1.6.2 - 2026-05-16

- Added 200x168 resolution-convergence diagnostics for the physical \(\Lambda/G\) evidence calculation.
- Added prior-only 25x21 stability-prior weights and heatmap.
- Added prior-likelihood overlap analysis identifying the current score-construction driver of the elevated Bayes factor.

## v1.6.0 - 2026-05-16

- Added `src/ofst_physical_extension.py`, a separate physical-extension pipeline for evidence rungs 5-8.
- Added a finite bounded \(\Lambda/G\) candidate grid.
- Added a CMB shift-parameter observable map using background-level FRW distance approximations.
- Added a finite-grid Gaussian likelihood using the Planck 2018 non-flat CMB distance-prior value \(R=1.7429\pm0.0051\).
- Added evidence comparison against uniform, finite-grid scale-proxy, and constrained max-entropy-over-log-support baselines.

## v1.5.1 - 2026-05-16

- Added packaged toy-universe stability simulation appendix using all 256 elementary cellular automata.
- Added raw toy-universe simulation outputs and figures.
- Preserved source code, unit tests, CI-profile baseline outputs, and the conservative claim boundary from v1.5.0.

## v1.5.0 - 2026-05-16

- Publication package for finite-ensemble stability-prior construction over the complete ECA ensemble.
- Added uncertainty intervals for robustness and null-model diagnostics.
- Added finite-size ranking-stability figure and finite-size summary output.
- Added empirical likelihood protocol for future dataset-facing extensions.
- Updated release validation, manifest, checksums, and test contracts.

## v1.4.1 - 2026-05-16

- Publication package for the finite-ensemble ECA demonstration.
- Added repository-level Origin Field Stability terminology.
- Added covariance-preserving, orbit-size-preserving, and local Hamming-neighbor null diagnostics.
- Added release validation script for metadata, output contracts, and checksums.

## v1.4.0 - 2026-05-16

- Added symbolic-dynamics diagnostics.
- Expanded the \(O(U)\) robustness family from 14 to 19 variants.
- Added hand-declared ECA reference baselines and overlap diagnostics.
- Added metric rank-correlation diagnostics.
- Added null-model diagnostics.
- Added `default`, `ci`, and `tiny` run profiles.
