#!/usr/bin/env python3
"""Validate release files, outputs, PDFs, and metadata contracts."""

from __future__ import annotations

import csv
import hashlib
import json
import sys
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
VERSION = "1.6.4"

REQUIRED_FILES = [
    "README.md",
    "LICENSE",
    "CITATION.cff",
    "CHANGELOG.md",
    ".zenodo.json",
    "requirements.txt",
    "pyproject.toml",
    "src/ofst_eca_analysis.py",
    "src/ofst_physical_extension.py",
    "src/ofst_physical_sensitivity.py",
    "src/ofst_prior_diagnostic.py",
    "src/ofst_resolution_debug.py",
    "src/ofst_resolution_convergence.py",
    "tests/test_ofst_eca_analysis.py",
    "tests/test_ofst_physical_extension.py",
    "tests/test_ofst_physical_sensitivity.py",
    "tests/test_ofst_resolution_debug.py",
    "tests/test_ofst_resolution_convergence.py",
    "docs/manuscript.md",
    "docs/supplementary_methods.md",
    "docs/formal_core.md",
    "docs/method_card.md",
    "docs/origin_field_framework_context.md",
    "docs/persistent_structure_metric_protocol.md",
    "docs/robustness_protocol.md",
    "docs/falsification_preregistration_protocol.md",
    "docs/empirical_likelihood_protocol.md",
    "docs/evidence_standard.md",
    "docs/research_roadmap.md",
    "docs/scope_and_limitations.md",
    "docs/finite_grid_scale_proxy.md",
    "docs/resolution_convergence.md",
    "docs/prior_likelihood_overlap.md",
    "figures/finite_size_ranking_stability.png",
    "figures/physical_extension/rung5_candidate_grid.png",
    "figures/physical_extension/rung6_cmb_shift_observable_map.png",
    "figures/physical_extension/rung7_likelihood_chi2_heatmap.png",
    "figures/physical_extension/rung8_bayes_factor_comparison.png",
    "figures/physical_extension/prior_only_heatmap.png",
    "results/run_summary.json",
    "results/claim_ledger.md",
    "results/null_model_summary.csv",
    "results/uncertainty_summary.csv",
    "results/metric_robustness_rules.csv",
    "results/metric_robustness_classes.csv",
    "results/physical_extension/rung5_candidate_grid.csv",
    "results/physical_extension/rung6_observable_predictions.csv",
    "results/physical_extension/rung7_likelihood_grid.csv",
    "results/physical_extension/rung8_evidence_bayes_factors.csv",
    "results/physical_extension/rung8_posteriors_by_prior.csv",
    "results/physical_extension/physical_extension_summary.json",
    "results/physical_extension/physical_extension_summary.md",
    "results/physical_extension/resolution_debug.csv",
    "results/physical_extension/resolution_debug_summary.json",
    "results/physical_extension/prior_only_weights.csv",
    "results/physical_extension/prior_likelihood_overlap_summary.json",
    "MANIFEST.json",
    "checksums.sha256",
]

REQUIRED_PDFS = [
    "pdfs/README.pdf",
    "pdfs/CHANGELOG.pdf",
    "pdfs/docs__empirical_likelihood_protocol.pdf",
    "pdfs/docs__evidence_standard.pdf",
    "pdfs/docs__falsification_preregistration_protocol.pdf",
    "pdfs/docs__finite_grid_scale_proxy.pdf",
    "pdfs/docs__formal_core.pdf",
    "pdfs/docs__manuscript.pdf",
    "pdfs/docs__method_card.pdf",
    "pdfs/docs__origin_field_framework_context.pdf",
    "pdfs/docs__persistent_structure_metric_protocol.pdf",
    "pdfs/docs__prior_likelihood_overlap.pdf",
    "pdfs/docs__research_roadmap.pdf",
    "pdfs/docs__resolution_convergence.pdf",
    "pdfs/docs__robustness_protocol.pdf",
    "pdfs/docs__scope_and_limitations.pdf",
    "pdfs/docs__supplementary_methods.pdf",
    "pdfs/docs__toy_universe_simulation_appendix.pdf",
    "pdfs/results__claim_ledger.pdf",
    "pdfs/results__physical_extension__physical_extension_summary.pdf",
    "pdfs/results__toy_universe_simulation__toy_universe_report.pdf",
]


def fail(message: str) -> None:
    print(f"VALIDATION ERROR: {message}", file=sys.stderr)
    raise SystemExit(1)


def load_csv(path: Path) -> list[dict[str, str]]:
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def verify_required_files() -> None:
    missing = [rel for rel in REQUIRED_FILES if not (REPO / rel).exists()]
    if missing:
        fail(f"missing required files: {missing}")


def verify_pdf_outputs() -> None:
    missing = [rel for rel in REQUIRED_PDFS if not (REPO / rel).exists()]
    if missing:
        fail(f"missing PDF outputs: {missing}")
    small = [rel for rel in REQUIRED_PDFS if (REPO / rel).stat().st_size < 1000]
    if small:
        fail(f"PDF outputs appear empty or invalid: {small}")


def verify_release_metadata() -> None:
    citation = (REPO / "CITATION.cff").read_text(encoding="utf-8")
    zenodo = json.loads((REPO / ".zenodo.json").read_text(encoding="utf-8"))
    manifest = json.loads((REPO / "MANIFEST.json").read_text(encoding="utf-8"))
    pyproject = (REPO / "pyproject.toml").read_text(encoding="utf-8")
    if f'version: "{VERSION}"' not in citation:
        fail(f"CITATION.cff version must be {VERSION}")
    if zenodo.get("version") != VERSION:
        fail(f".zenodo.json version must be {VERSION}")
    if manifest.get("version") != VERSION:
        fail(f"MANIFEST.json version must be {VERSION}")
    if f'version = "{VERSION}"' not in pyproject:
        fail(f"pyproject.toml version must be {VERSION}")


def verify_summary_contract() -> None:
    summary = json.loads((REPO / "results" / "run_summary.json").read_text(encoding="utf-8"))
    if summary.get("n_models") != 256:
        fail("run_summary.json must report 256 models")
    if summary.get("bootstrap_draws") != 128:
        fail("CI-profile bootstrap_draws must be 128")
    if "uncertainty_summary" not in summary or len(summary["uncertainty_summary"]) < 10:
        fail("run_summary.json missing uncertainty_summary rows")
    diagnostics = summary.get("robustness_diagnostics", {})
    if len(diagnostics.get("metric_variants", [])) < 19:
        fail("metric variant count is below expected minimum")
    if diagnostics.get("n_hyperparameter_combinations") != 684:
        fail("CI-profile hyperparameter combination count must be 684")


def verify_null_models() -> None:
    rows = load_csv(REPO / "results" / "null_model_summary.csv")
    names = {row["null_model"] for row in rows}
    expected = {
        "component_tuple_permutation",
        "hamming_neighbor_score_substitution",
        "independent_component_permutation",
        "orbit_size_preserving_score_permutation",
        "score_label_permutation",
    }
    if names != expected:
        fail(f"unexpected null model set: {sorted(names)}")
    required_columns = {
        "mean_top20_overlap_ci_low",
        "mean_top20_overlap_ci_high",
        "top1_match_rate_ci_low",
        "top1_match_rate_ci_high",
        "mean_score_rank_correlation_ci_low",
        "mean_score_rank_correlation_ci_high",
    }
    missing = required_columns - set(rows[0])
    if missing:
        fail(f"null_model_summary.csv missing interval columns: {sorted(missing)}")


def verify_uncertainty_outputs() -> None:
    rows = load_csv(REPO / "results" / "uncertainty_summary.csv")
    if len(rows) < 10:
        fail("uncertainty_summary.csv has too few rows")
    required_sources = {
        "local_weight_sensitivity",
        "global_simplex_sensitivity",
        "hyperparameter_grid",
        "null_model:score_label_permutation",
    }
    sources = {row["source"] for row in rows}
    missing_sources = required_sources - sources
    if missing_sources:
        fail(f"uncertainty_summary.csv missing sources: {sorted(missing_sources)}")
    for row in rows:
        lo = float(row["ci_low"])
        hi = float(row["ci_high"])
        estimate = float(row["estimate"])
        if not (lo <= estimate <= hi):
            fail(f"interval does not contain estimate for {row['source']} / {row['metric']}")


def verify_robustness_intervals() -> None:
    rule_rows = load_csv(REPO / "results" / "metric_robustness_rules.csv")
    class_rows = load_csv(REPO / "results" / "metric_robustness_classes.csv")
    for column in ["score_top20_frequency_ci_low", "score_top20_frequency_ci_high", "prior_top20_frequency_ci_low", "prior_top20_frequency_ci_high"]:
        if column not in rule_rows[0]:
            fail(f"metric_robustness_rules.csv missing {column}")
    for column in ["score_top5_frequency_max_ci_low", "score_top5_frequency_max_ci_high", "prior_top5_frequency_ci_low", "prior_top5_frequency_ci_high"]:
        if column not in class_rows[0]:
            fail(f"metric_robustness_classes.csv missing {column}")


def verify_claim_ledger_consistency() -> None:
    rows = load_csv(REPO / "results" / "metric_robustness_classes.csv")
    if not rows:
        fail("metric_robustness_classes.csv is empty")
    top = rows[0]
    freq = float(top["score_top5_frequency_max"])
    ledger = (REPO / "results" / "claim_ledger.md").read_text(encoding="utf-8")
    if freq > 0.70 and "At least one symmetry class remains" not in ledger:
        fail("claim ledger does not report the class-level score robustness result")
    if freq <= 0.70 and "No symmetry class exceeds" not in ledger:
        fail("claim ledger does not report the absence of a class-level score robustness result")


def verify_physical_extension_outputs() -> None:
    grid = load_csv(REPO / "results" / "physical_extension" / "rung5_candidate_grid.csv")
    if len(grid) != 525:
        fail("physical extension rung 5 grid must contain 525 candidates")
    likelihood = load_csv(REPO / "results" / "physical_extension" / "rung7_likelihood_grid.csv")
    valid_count = sum(row.get("observable_valid") == "True" for row in likelihood)
    if valid_count < 400:
        fail("physical extension has too few observable-valid candidates")
    evidence = load_csv(REPO / "results" / "physical_extension" / "rung8_evidence_bayes_factors.csv")
    names = {row["prior_name"] for row in evidence}
    expected = {"stability", "uniform", "jeffreys_scale_proxy", "constrained_max_entropy_log"}
    if names != expected:
        fail(f"unexpected physical-extension evidence priors: {sorted(names)}")
    for row in evidence:
        for column in ["bayes_factor_vs_stability", "bayes_factor_stability_vs_prior"]:
            if column not in row:
                fail(f"physical-extension evidence table missing {column}")
            if float(row[column]) <= 0:
                fail(f"physical-extension evidence table has nonpositive {column}")


def verify_checksums() -> None:
    checksum_file = REPO / "checksums.sha256"
    for line_no, line in enumerate(checksum_file.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            expected, rel = line.split(maxsplit=1)
        except ValueError:
            fail(f"invalid checksum line {line_no}")
        path = REPO / rel
        if not path.exists():
            fail(f"checksum target missing: {rel}")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual != expected:
            fail(f"checksum mismatch for {rel}")


def main() -> None:
    verify_required_files()
    verify_pdf_outputs()
    verify_release_metadata()
    verify_summary_contract()
    verify_null_models()
    verify_uncertainty_outputs()
    verify_robustness_intervals()
    verify_claim_ledger_consistency()
    verify_physical_extension_outputs()
    verify_checksums()
    print("release validation passed")


if __name__ == "__main__":
    main()
