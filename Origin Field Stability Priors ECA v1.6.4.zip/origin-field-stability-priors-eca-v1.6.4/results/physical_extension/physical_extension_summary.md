# Physical Extension Summary

This extension adds rungs 5-8 without modifying the existing ECA pipeline.

## Rung 5 candidate space

The candidate space is the finite bounded grid U_i = (Lambda/Lambda_obs, G/G_obs), with Lambda/Lambda_obs in [0.05, 3.0] over 25 log-spaced points and G/G_obs in [0.8, 1.2] over 21 linearly spaced points. Curvature is derived by closure as omega_k = 1 - g(omega_m + omega_r) - lambda omega_Lambda.

## Rung 6 observable map

The observable is the CMB shift parameter R using a background-level FRW distance approximation. This is an analytical/semianalytical distance-prior calculation, not a full CMB simulation.

## Rung 7 dataset and likelihood

The likelihood uses the Planck 2018 non-flat CMB distance-prior shift parameter R = 1.7429 +/- 0.0051 at z_star = 1089.46. The likelihood is a finite-grid Gaussian likelihood in R. This is a compressed public observational datum, not the raw Planck map likelihood or a Planck MCMC chain.

## Rung 8 baselines

Baselines are uniform model mass over valid finite candidates, a discrete finite-grid scale proxy proportional to 1/(lambda g), retained under the legacy key `jeffreys_scale_proxy`, and a constrained maximum-entropy baseline defined as uniform density over bounded log Lambda and log G support and discretized by log-cell area.

## Domain-expertise and data-change considerations

A domain cosmologist would normally replace this module with a Boltzmann solver such as CAMB or CLASS, vary the full cosmological parameter vector, include nuisance parameters, and use the full Planck likelihood or public chains rather than a one-number distance prior.

The G-variation treatment here is background-level only. A real varying-G cosmology would alter recombination, perturbation growth, the sound horizon, and possibly BBN; those effects are intentionally not modeled here.

The stability prior is a declared pre-data physical-grid proxy. It is not derived from a known law of nature. It favors curvature moderation, parameter moderation around the observed nondimensional reference point, and smooth background expansion. Different stability definitions could materially change the evidence comparison.

The non-flat shift-parameter prior is used because the grid derives omega_k by closure. Using the flat value R = 1.7502 +/- 0.0046, using the full three-parameter CMB distance-prior covariance, or using full Planck likelihoods would change numerical Bayes factors.

## Interpretation boundary

This physical extension is a compressed background-level finite-grid toy diagnostic. It is not a self-consistent varying-G cosmology and should not be cited as full cosmological model comparison.
