# Scope and Limitations

Version: 1.6.4

## Purpose

This document states the negative claim boundary for the package. It is intentionally placed near the front of the release because the package uses physics-facing language and a physical-extension toy workflow.

## Not established

This package does not establish any of the following claims:

1. An Origin Field exists.
2. Stability priors select the real laws of physics.
3. Elementary cellular automata are physically preferred universes.
4. The declared ECA stability score is unique, natural, or physically necessary.
5. The Lambda/G grid identifies the real values of Lambda, G, or curvature.
6. The physical-extension Bayes factors are evidence for a new cosmological mechanism.
7. The finite-grid scale proxy is a mathematically exact Jeffreys or reference prior.
8. The Lambda/G extension is a self-consistent varying-G cosmology.
9. The package competes with full Lambda-CDM inference, Planck likelihood analyses, CAMB/CLASS pipelines, BAO/SNe joint analyses, or domain-grade cosmological model comparison.

## What is established by the checked-in artifacts

The checked-in artifacts support a narrower methodological statement:

> A declared stability score can be used to construct a reproducible Gibbs prior over a finite candidate ensemble, and the resulting rankings/evidences can be audited with sensitivity checks, null models, uncertainty intervals, release validation, and finite-grid likelihood diagnostics.

That claim is computational and conditional on the declared ensemble, metrics, weights, and likelihood approximation.

## Why the distinction matters

A prior-overlap result can be mathematically reproducible and still not be physical evidence. In the physical extension, the elevated Bayes factors primarily show how the declared stability prior places finite-grid mass relative to a compressed CMB shift-parameter likelihood ridge and relative to selected baseline priors. They do not show that the universe uses the declared stability score.

## What would be needed for a stronger physical claim

A stronger physical claim would require at least:

- a physically motivated candidate ensemble;
- a score defined before seeing the target likelihood;
- a full generative cosmology model, not a compressed background-only approximation;
- CAMB/CLASS or equivalent Boltzmann calculations;
- CMB/BAO/SNe likelihoods with covariance and nuisance parameters;
- checks against BBN, recombination, perturbation growth, local gravity constraints, and structure formation;
- comparison against standard baseline priors and Lambda-CDM extensions;
- blind or preregistered tests on holdout observables.

Until those conditions are met, the correct interpretation is methodological, not discovery-level physics.
