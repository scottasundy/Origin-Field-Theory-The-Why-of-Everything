# Supplementary Methods

Version: 1.6.4

## Reproducibility contents

The repository includes:

- source code;
- generated CI-profile results;
- diagnostic figures;
- tests;
- citation metadata;
- Zenodo metadata;
- manifest and checksums.

## Generated outputs

Core outputs:

```text
results/config_snapshot.json
results/eca_metrics.csv
results/eca_symmetry_classes.csv
results/ofst_rankings.csv
results/top20_ofst.csv
results/ofst_class_rankings.csv
results/metric_robustness_rules.csv
results/metric_robustness_classes.csv
results/hyperparameter_combo_summary.csv
results/hyperparameter_model_average.csv
results/trajectory_holdout_validation.csv
results/uncertainty_summary.csv
results/claim_ledger.md
results/run_summary.json
```

Additional diagnostics:

```text
results/ablation_summary.csv
results/base_prior_sensitivity.csv
results/eta_sensitivity.csv
results/global_simplex_sensitivity.csv
results/metric_correlations.csv
results/metric_registry.json
results/null_model_draws.csv
results/null_model_summary.csv
results/o_metric_sensitivity.csv
results/reference_baseline_overlap.csv
results/reference_eca_baselines.csv
results/seed_sensitivity.csv
results/sensitivity_rule_frequencies.csv
results/sensitivity_weight_draws.csv
results/size_sensitivity.csv
results/environment.json
```

Figures:

```text
figures/ofst_top15_stability_scores.png
figures/compressibility_vs_persistent_structure.png
figures/gibbs_weight_distribution.png
figures/sensitivity_top20_overlap.png
figures/global_simplex_top20_overlap.png
figures/finite_size_ranking_stability.png
```

## Checksum verification

Use:

```bash
sha256sum -c checksums.sha256
```

## Test command

Use:

```bash
python -m unittest discover -s tests
```

## Release validation

Use:

```bash
python scripts/validate_release.py
```
