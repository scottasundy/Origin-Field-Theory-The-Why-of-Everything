# Resolution Convergence

Version: 1.6.4

This report records the finite-grid behavior of the physical Lambda/G finite-grid evidence calculation after adding the 200x168 grid. The calculation is a compressed background-level toy diagnostic, not a self-consistent varying-G cosmology.

## 1. 200x168 behavior

BF stability/finite-grid scale proxy is stabilizing around the 100x84-to-200x168 regime: 52.3691 at 100x84 and 58.762 at 200x168. It is not stabilized near 52 exactly, but the change is within 20%.

Bayes factor series, stability prior divided by baseline:

| Grid | Uniform | finite-grid scale proxy | Max-ent log |
|---:|---:|---:|---:|
| 13x11 | 1.93406 | 10.4125 | 1.61016 |
| 25x21 | 1.91628 | 9.41906 | 1.57454 |
| 50x42 | 16.6102 | 94.9662 | 17.5197 |
| 100x84 | 9.58714 | 52.3691 | 9.68646 |
| 200x168 | 10.9083 | 58.762 | 10.9237 |

## 2. Source of the divergence

The 200x168 run shows that the 50x42 value was too high, but the elevated BF does not disappear. The source is the overlap between the stability prior and a narrow CMB shift-parameter likelihood ridge. The maximum likelihood remains close to one at all fine grids, so the movement is not caused by a new likelihood ceiling. It is caused by how finite-grid prior mass lands on the high-likelihood ridge relative to the finite-grid scale-proxy normalization.

Key numeric diagnostics by grid:

### 13x11
Evidence: Z_stability=0.0103593; Z_scale_proxy=0.00099489; Z_uniform=0.00535624; Z_maxent=0.00643371.
Raw prior normalizers: stability=8.4784; scale_proxy=755.435.
Best likelihood: L=0.648106 at lambda=1.07791, g=0.8, residual=-0.931345 sigma.

### 25x21
Evidence: Z_stability=0.0026713; Z_scale_proxy=0.000283606; Z_uniform=0.001394; Z_maxent=0.00169656.
Raw prior normalizers: stability=32.3737; scale_proxy=2656.05.
Best likelihood: L=0.648106 at lambda=1.07791, g=0.8, residual=-0.931345 sigma.

### 50x42
Evidence: Z_stability=0.0297625; Z_scale_proxy=0.000313401; Z_uniform=0.00179182; Z_maxent=0.0016988.
Raw prior normalizers: stability=74.9903; scale_proxy=10366.6.
Best likelihood: L=0.999942 at lambda=1.01243, g=0.97561, residual=0.0108147 sigma.

### 100x84
Evidence: Z_stability=0.0230985; Z_scale_proxy=0.000441072; Z_uniform=0.00240932; Z_maxent=0.00238462.
Raw prior normalizers: stability=317.011; scale_proxy=40997.3.
Best likelihood: L=0.999529 at lambda=1.0236, g=0.944578, residual=-0.0306989 sigma.

### 200x168
Evidence: Z_stability=0.0229486; Z_scale_proxy=0.000390536; Z_uniform=0.00210378; Z_maxent=0.0021008.
Raw prior normalizers: stability=1180.98; scale_proxy=163061.
Best likelihood: L=0.998752 at lambda=0.947844, g=1.15928, residual=-0.0499756 sigma.

## 3. Candidate cluster

The 50x42 result is driven by a narrow coordinate cluster. The top three stability-posterior cells at 50x42 carry 0.887587 posterior mass: lambda=1.0124343, g=0.97560976, residual=0.0108147 sigma; lambda=1.0124343, g=0.98536585, residual=-1.12402 sigma; lambda=1.0124343, g=0.96585366, residual=1.1614 sigma. The nearest top-posterior analogues are 25x21: lambda=1.0779123, g=0.86, residual=-8.69636 sigma; 100x84: lambda=1.0236041, g=0.94939759, residual=-0.607387 sigma; 200x168: lambda=1.0081921, g=0.98203593, residual=0.653031 sigma.

Interpretation boundary: the diagnostic identifies numerical behavior in the declared grid and compressed CMB shift-parameter likelihood. A full cosmological analysis would require the full parameter vector, covariance structure, and a Boltzmann-code likelihood workflow.
