# Empirical Likelihood Protocol

Version: 1.6.4

## Purpose

This protocol defines the additional structure required before the stability prior can be used for empirical model selection.

## Required posterior form

A dataset-facing extension must use:

\[
P(U_i\mid D)\propto P(D\mid U_i)P_G(U_i).
\]

The package prior is \(P_G(U_i)\). It is not a posterior until \(P(D\mid U_i)\) is declared.

## Required elements

For each empirical application, define:

1. candidate ensemble \(\mathcal U\);
2. admissibility constraints \(\Theta_i\);
3. base prior \(\pi_i\);
4. score components \(C,A,O,R\);
5. weight vector \(w\);
6. concentration parameter \(\eta\);
7. dataset \(D\);
8. observable map \(U_i\rightarrow \hat D_i\);
9. likelihood \(P(D\mid U_i)\);
10. baseline priors;
11. success and failure thresholds.

## Example likelihood forms

Gaussian residual model:

\[
\log P(D\mid U_i)=
-\frac{1}{2}(D-\hat D_i)^T\Sigma^{-1}(D-\hat D_i)+\mathrm{const}.
\]

Count model:

\[
P(D\mid U_i)=\prod_k \mathrm{Poisson}(D_k\mid \lambda_{ik}).
\]

Classification or detection model:

\[
P(D\mid U_i)=\prod_k p_{ik}^{y_k}(1-p_{ik})^{1-y_k}.
\]

## Baseline evidence comparison

Report the marginal evidence:

\[
P(D\mid \mathcal M)=\sum_i P(D\mid U_i)P(U_i\mid \mathcal M),
\]

and compare against named baselines:

- uniform over raw candidates;
- uniform over equivalence classes;
- simplicity-only prior;
- maximum-entropy prior;
- domain-standard prior;
- random or permutation controls.

## Interpretation rule

Prior concentration alone is not empirical evidence. Evidence increases only when the prior improves predictive or explanatory performance under a declared likelihood and against serious baselines.
