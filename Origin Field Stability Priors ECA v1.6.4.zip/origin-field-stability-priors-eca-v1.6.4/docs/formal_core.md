# Formal Core

Version: 1.6.4

## Finite ensemble

Let

\[
\mathcal{U}=\{U_1,\ldots,U_N\}
\]

be a declared finite candidate-model ensemble. In this package, \(N=256\), and \(\mathcal{U}\) is the complete elementary cellular automaton ensemble.

## Score

\[
S_w(U)=w_C C(U)+w_A A(U)+w_O O(U)-w_R R(U).
\]

The score is a declared modeling choice. It is not derived from established physics.

## Component roles

- \(C(U)\): admissibility or consistency. In this ECA run, \(C=1\) for all candidates.
- \(A(U)\): finite-history compressibility.
- \(O(U)\): persistent-structure proxy.
- \(R(U)\): perturbation fragility.

## Gibbs prior

\[
P_G(U_i\mid\Theta,w,\eta)=
\frac{\pi_i\Theta_i e^{\eta S_w(U_i)}}
{\sum_j\pi_j\Theta_j e^{\eta S_w(U_j)}}.
\]

where:

- \(\pi_i\) is a base prior;
- \(\Theta_i\) is an admissibility indicator;
- \(w\) is a nonnegative weight vector;
- \(\eta\ge0\) controls concentration.

## Prior/posterior distinction

\(P_G\) is a prior over a declared ensemble. It becomes an empirical posterior only after adding a likelihood:

\[
P(U_i\mid D)\propto P(D\mid U_i)P_G(U_i).
\]

No likelihood is used in the bundled ECA demonstration.

## Interval estimates

The package reports two interval types:

- nonparametric bootstrap intervals for mean overlap diagnostics;
- Wilson score intervals for binomial top-list frequencies.

These intervals quantify finite diagnostic uncertainty. They do not convert the toy ensemble into empirical physics.

## Robustness requirements

A strong class-level claim should survive:

1. alternative \(O(U)\) metrics;
2. local and global weight variation;
3. eta variation;
4. raw-rule and symmetry-class base priors;
5. max, mean, and median aggregation over symmetry-class members;
6. null-model and reference-baseline comparisons;
7. seed and finite-size checks;
8. explicit uncertainty intervals.

The bundled CI-profile result supports a methodological demonstration, not a physical law-selection claim.
