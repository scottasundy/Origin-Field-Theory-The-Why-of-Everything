# Evidence Standard for Physical Law-Selection Claims

Version: 1.6.4

## Purpose

This standard separates finite prior construction from evidence for physical law selection.

## Current status

The ECA package supports a methodological claim: a declared prior over a complete finite ensemble can be implemented and audited.

It does not support an empirical claim about real physical laws.

## Evidence ladder

1. **Formal construction**: candidate ensemble, score, and prior are defined.
2. **Reproducibility**: code, tests, environment metadata, manifest, and checksums are provided.
3. **Robustness**: conclusions survive metric, weight, eta, base-prior, seed, and finite-size variation.
4. **Negative controls**: null models and reference baselines are included.
5. **Physical candidate space**: the ensemble represents admissible physical models.
6. **Observable map**: each candidate predicts measurable quantities.
7. **Likelihood**: data are connected through \(P(D\mid U_i)\).
8. **Baseline comparison**: the method outperforms uniform, simplicity, maximum-entropy, and domain-standard priors.
9. **Blind prediction**: a preregistered prediction succeeds on data not used to set the score.
10. **Independent replication**: independent implementations and datasets support the same conclusion.

The current package reaches the first four levels for the ECA toy ensemble.

## Required claim language

Acceptable:

> This is a reproducible finite-ensemble prior-construction demonstration.

Not acceptable:

> This proves physical law selection.

Acceptable for future empirical work:

> Under the declared likelihood and dataset, this prior improves model evidence relative to named baselines.

## Minimum empirical package

An empirical extension must provide:

- candidate model definitions;
- admissibility constraints;
- observables;
- dataset;
- likelihood;
- baseline priors;
- evidence metrics;
- preregistered success and failure thresholds.
