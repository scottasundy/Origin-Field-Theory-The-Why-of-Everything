# Falsification and Preregistration Protocol

Version: 1.6.4

## Scope

The ECA demonstration is not a test of physical law selection. It is a finite-ensemble audit of a declared prior. The package still defines conditions under which stronger claims should be rejected.

## Allowed claims

Allowed:

- The score and Gibbs prior are defined over the complete 256-rule ECA ensemble.
- The bundled outputs can be reproduced from the included code and CI profile.
- The robustness layer identifies which score-rank and prior-rank claims are stable, partial, or unsupported.
- The uncertainty intervals quantify finite diagnostic variability for the bundled run profile.

Not allowed:

- The framework is established physics.
- The top ECA rules are physically preferred universes.
- The \(O(U)\) metric detects observers.
- Null-model behavior validates law selection.
- The Gibbs prior is an empirical posterior without a likelihood.

## Rejection conditions for stronger ECA robustness claims

A stronger ECA robustness claim should be rejected if:

1. it fails under alternative \(O(U)\) metrics;
2. it disappears under global weight variation;
3. it holds only under max-member class aggregation;
4. it is not supported by prior-rank or prior-mass diagnostics;
5. it is comparable to null-model overlap;
6. it depends on a profile too small to support the stated conclusion;
7. its uncertainty interval overlaps an explicitly declared failure region.

## Rejection conditions for physical claims

A physical law-selection claim should be rejected or weakened if:

1. no physically meaningful candidate ensemble is defined;
2. no observables are mapped from candidates to data;
3. no empirical likelihood is specified;
4. the method fails to outperform baseline priors;
5. the result depends on post hoc metric changes;
6. the result conflicts with established conservation laws, locality, causality, quantum mechanics, or thermodynamics without a precise replacement theory.

## Bundled conclusion

The CI-profile result supports a methodological demonstration. It does not support an empirical or physical law-selection claim.
