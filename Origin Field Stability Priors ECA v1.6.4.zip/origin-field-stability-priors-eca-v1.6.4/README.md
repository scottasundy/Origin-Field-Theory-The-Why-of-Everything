# Origin Field Stability Priors for Finite Model Ensembles

**ECA demonstration and physical-extension package, version 1.6.4**  
Release date: 2026-05-16

## Status

This repository implements bounded computational demonstrations of stability-weighted prior construction over finite ensembles. The primary demonstration uses the complete set of 256 elementary cellular automata. A separate physical-extension workflow maps a finite \(\Lambda/G\) candidate grid to a compressed CMB shift-parameter likelihood.

The supported claim is limited and operational:

> A declared stability score can be used to construct a reproducible Gibbs prior over a finite model ensemble, and the resulting rankings can be audited with metric sensitivity, hyperparameter sweeps, null models, uncertainty intervals, finite-size diagnostics, release validation, and finite-grid evidence diagnostics.

This package does not establish a new physical law, infer the true values of \(\Lambda\) or \(G\), or show that elementary cellular automata are physically preferred universes. The physical extension is a background-level compressed-data demonstration, not a self-consistent varying-\(G\) cosmology and not a replacement for full \(\Lambda\)CDM inference, CAMB/CLASS calculations, Planck likelihoods, BAO/SNe analyses, or standard Bayesian model comparison.

For the formal boundary, see `docs/scope_and_limitations.md`.

## Repository contents

```text
.
├── README.md
├── LICENSE
├── CITATION.cff
├── CHANGELOG.md
├── .zenodo.json
├── requirements.txt
├── pyproject.toml
├── src/
│   ├── ofst_eca_analysis.py
│   ├── ofst_physical_extension.py
│   ├── ofst_prior_diagnostic.py
│   ├── ofst_resolution_debug.py
│   └── ofst_resolution_convergence.py
├── tests/
├── scripts/
│   ├── run_analysis.sh
│   ├── run_tests.sh
│   ├── run_tests.bat
│   └── validate_release.py
├── docs/
├── results/
├── figures/
└── pdfs/
```

## Core model

For each candidate model \(U\), define

\[
S_w(U)=w_C C(U)+w_A A(U)+w_O O(U)-w_R R(U).
\]

In this ECA demonstration:

- \(C(U)\) is an admissibility indicator. It is constant, \(C=1\), for every ECA rule.
- \(A(U)\) is a finite-trajectory gzip-compressibility score.
- \(O(U)\) is a persistent-structure proxy based on finite binary histories. It is not an observer detector.
- \(R(U)\) is a perturbation-fragility penalty.
- \(w\) is a declared nonnegative weight vector.

The finite-ensemble Gibbs prior is

\[
P_G(U_i\mid \Theta,w,\eta)=
\frac{\pi_i\Theta_i\exp[\eta S_w(U_i)]}
{\sum_j \pi_j\Theta_j\exp[\eta S_w(U_j)]}.
\]

This is a prior over a declared ensemble. It becomes a posterior only after a likelihood \(P(D\mid U_i)\) is introduced:

\[
P(U_i\mid D)\propto P(D\mid U_i)P_G(U_i).
\]

## Physical extension

The physical extension uses candidates

\[
U_i=(\lambda_i,g_i),\qquad
\lambda=\Lambda/\Lambda_{\rm obs},\qquad
g=G/G_{\rm obs}.
\]

The checked-in grid uses 25 log-spaced \(\lambda\) values from 0.05 to 3.00 and 21 linearly spaced \(g\) values from 0.80 to 1.20, for 525 total candidates. Curvature is derived by closure:

\[
\Omega_k = 1-g(\Omega_m+\Omega_r)-\lambda\Omega_\Lambda.
\]

Each candidate is mapped to a compressed CMB shift-parameter observable using

\[
E^2(z)=g\Omega_r(1+z)^4+g\Omega_m(1+z)^3+\Omega_k(1+z)^2+\lambda\Omega_\Lambda,
\]

\[
\chi(z_\ast)=\int_0^{z_\ast}\frac{dz}{E(z)},
\]

\[
R(\lambda,g)=\sqrt{g\Omega_m}\,S_k(\chi).
\]

The likelihood uses the Planck 2018 non-flat CMB distance-prior value

\[
R_{\rm obs}=1.7429,\qquad \sigma_R=0.0051,\qquad z_\ast=1089.46,
\]

\[
\log P(D\mid U_i)=-\frac{1}{2}\left(\frac{R(U_i)-R_{\rm obs}}{\sigma_R}\right)^2.
\]

The finite-grid scale-proxy baseline is proportional to

\[
p_{\rm scale}(\lambda,g)\propto \frac{1}{\lambda g},
\]

and is retained in output tables under the legacy key `jeffreys_scale_proxy`. It is not a Fisher-information Jeffreys prior.

The original 25x21 Bayes factors are:

| baseline | BF baseline/stability | BF stability/baseline |
|:--|--:|--:|
| uniform | 0.521845 | 1.916278 |
| finite-grid scale proxy | 0.106168 | 9.419057 |
| constrained max-entropy log | 0.635106 | 1.574540 |

Resolution convergence through the 200x168 grid gives:

| Grid | BF stability/uniform | BF stability/finite-grid scale proxy | BF stability/max-ent log |
|---:|---:|---:|---:|
| 13x11 | 1.934 | 10.413 | 1.610 |
| 25x21 | 1.916 | 9.419 | 1.575 |
| 50x42 | 16.610 | 94.966 | 17.520 |
| 100x84 | 9.587 | 52.369 | 9.686 |
| 200x168 | 10.908 | 58.762 | 10.923 |

These values should be read as finite-grid prior-overlap diagnostics for this compressed likelihood, not as evidence for a fundamental cosmological prior.

## Run commands

Run the checked-in ECA profile:

```bash
python src/ofst_eca_analysis.py --profile ci
```

Run the default ECA profile:

```bash
python src/ofst_eca_analysis.py
```

Run the physical extension:

```bash
python src/ofst_physical_extension.py
python src/ofst_resolution_convergence.py
python src/ofst_prior_diagnostic.py
```

Run tests:

```bash
python -m unittest discover -s tests
python -m pytest -q
```

Validate the release package:

```bash
python scripts/validate_release.py
```

## Bundled CI-profile configuration

```text
n_cells = 32
n_steps = 32
random_initial_conditions = 6
fragility_initial_conditions = 3
weights = C=0.1, A=0.15, O=0.65, R=0.1
eta = 8.0
metric_variants = 19
model_averaging_weight_draws = 6
eta_grid = [0.0, 2.0, 8.0]
base_priors = uniform_raw_rules, uniform_symmetry_classes
hyperparameter_combinations = 684
null_model_draws_per_null = 24
bootstrap_draws = 128
```

## Bundled base ranking

| rule | symmetry_class | S | A | O | R |
|---:|---:|---:|---:|---:|---:|
| 1 | 1 | 0.616290 | 0.934426 | 0.580181 | 0.009920 |
| 127 | 1 | 0.608610 | 0.931694 | 0.582163 | 0.095494 |
| 33 | 33 | 0.588601 | 0.920765 | 0.551748 | 0.081497 |
| 123 | 33 | 0.588032 | 0.913934 | 0.543795 | 0.025252 |
| 198 | 156 | 0.571832 | 0.871585 | 0.540888 | 0.104829 |
| 199 | 28 | 0.570964 | 0.859290 | 0.540301 | 0.091252 |
| 70 | 28 | 0.569740 | 0.863388 | 0.540676 | 0.112075 |
| 156 | 156 | 0.563162 | 0.853825 | 0.531147 | 0.101580 |
| 28 | 28 | 0.562184 | 0.851093 | 0.529686 | 0.097752 |
| 157 | 28 | 0.560985 | 0.842896 | 0.529650 | 0.097224 |

## Main diagnostics

The bundled robustness layer includes:

- 19 \(O(U)\)-metric variants;
- local and global weight sensitivity;
- \(\eta\) sensitivity;
- raw-rule and symmetry-class base priors;
- raw-rule and symmetry-class aggregation;
- max, mean, and median class aggregation;
- seed and finite-size sensitivity;
- trajectory-holdout diagnostics;
- reference ECA baseline overlap;
- five null-model controls;
- bootstrap and Wilson uncertainty intervals;
- deterministic tests, manifest, and SHA-256 checksums.

## Null-model summary

| null_model | n_draws | mean_top20_overlap_with_base | top1_match_rate | mean_score_rank_correlation_with_base |
|:--|--:|--:|--:|--:|
| component_tuple_permutation | 24 | 0.091667 | 0.000000 | 0.012392 |
| hamming_neighbor_score_substitution | 24 | 0.118750 | 0.000000 | 0.221547 |
| independent_component_permutation | 24 | 0.081250 | 0.000000 | -0.002590 |
| orbit_size_preserving_score_permutation | 24 | 0.122917 | 0.000000 | 0.035282 |
| score_label_permutation | 24 | 0.102083 | 0.000000 | 0.025795 |

## Next domain-grade upgrade

A domain-grade empirical version should replace the compressed CMB shift-parameter toy likelihood with a full cosmology workflow:

1. CAMB, CLASS, or equivalent Boltzmann predictions for each candidate.
2. Full CMB/BAO/SNe likelihoods or public chains with covariance information.
3. A complete cosmological parameter vector with nuisance parameters.
4. A physically specified model for any varying-\(G\) or modified-gravity behavior.
5. Blind or preregistered score definitions before likelihood comparison.

Until then, the physical extension should be cited only as a finite-grid prior-overlap diagnostic.
