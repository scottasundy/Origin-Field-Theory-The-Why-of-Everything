from pathlib import Path

import pandas as pd

from ofst_physical_extension import PhysicalExtensionConfig
from ofst_resolution_debug import run_resolution_debug, run


def test_resolution_debug_contract():
    df, summary = run_resolution_debug(PhysicalExtensionConfig(integration_steps=512))
    assert set(summary["resolutions"]) == {"13x11", "25x21", "50x42", "100x84"}
    assert {"evidence_summary", "highest_likelihood", "top20_posterior"}.issubset(set(df["record_type"]))
    evidence_rows = df[df["record_type"] == "evidence_summary"]
    assert len(evidence_rows) == 16
    assert (evidence_rows["evidence"] > 0).all()
    top_rows = df[df["record_type"] == "top20_posterior"]
    assert len(top_rows) == 4 * 4 * 20
    assert (top_rows["posterior_weight"] >= 0).all()


def test_resolution_debug_run_writes_outputs(tmp_path: Path, monkeypatch):
    results_dir = tmp_path / "results"
    monkeypatch.chdir(tmp_path)
    summary = run(
        PhysicalExtensionConfig(
            results_dir=str(results_dir),
            figures_dir=str(tmp_path / "figures"),
            integration_steps=512,
        )
    )
    assert summary["diagnostic_extension"] == "resolution_debug"
    assert (results_dir / "resolution_debug.csv").exists()
    assert (results_dir / "resolution_debug_summary.json").exists()
    assert (tmp_path / "docs" / "resolution_convergence.md").exists()
    debug = pd.read_csv(results_dir / "resolution_debug.csv")
    assert "raw_prior_normalization_constant" in debug.columns
    assert "highest_likelihood_candidate_id" in debug.columns
