#!/usr/bin/env python3
"""Resolution-convergence diagnostics for the physical Lambda/G extension."""

from __future__ import annotations

import argparse
import json
import math
from dataclasses import asdict
from pathlib import Path
from typing import Iterable

import numpy as np
import pandas as pd

from ofst_physical_extension import PhysicalExtensionConfig, baseline_priors, evidence_table
from ofst_resolution_debug import (
    BASELINES,
    PRIORS,
    PRIOR_SHORT,
    _candidate_fields,
    _raw_prior_denominators,
    _run_pipeline,
    _safe_exp,
)

RESOLUTIONS: tuple[tuple[int, int], ...] = ((13, 11), (25, 21), (50, 42), (100, 84), (200, 168))


def _evidence_value(evidence_df: pd.DataFrame, prior_name: str, column: str) -> float:
    values = evidence_df.loc[evidence_df["prior_name"] == prior_name, column]
    if values.empty:
        raise KeyError(f"missing prior {prior_name!r}")
    return float(values.iloc[0])


def _base_row(record_type: str, resolution_label: str, config: PhysicalExtensionConfig) -> dict[str, object]:
    return {
        "record_type": record_type,
        "resolution_label": resolution_label,
        "lambda_points": int(config.lambda_points),
        "g_points": int(config.g_points),
        "cmb_shift_R_obs": float(config.cmb_shift_r_obs),
        "cmb_shift_R_sigma": float(config.cmb_shift_r_sigma),
        "stability_eta": float(config.stability_eta),
    }


def _highest_likelihood(likelihood_df: pd.DataFrame) -> pd.Series:
    return likelihood_df.loc[int(likelihood_df["log_likelihood"].astype(float).idxmax())]


def _make_evidence_rows(
    *,
    resolution_label: str,
    config: PhysicalExtensionConfig,
    likelihood_df: pd.DataFrame,
    evidence_df: pd.DataFrame,
    raw_prior_denominators: dict[str, float],
) -> list[dict[str, object]]:
    stability_logz = _evidence_value(evidence_df, "stability", "log_evidence")
    stability_z = _evidence_value(evidence_df, "stability", "evidence")
    rows: list[dict[str, object]] = []
    for prior_name in PRIORS:
        logz = _evidence_value(evidence_df, prior_name, "log_evidence")
        z = _evidence_value(evidence_df, prior_name, "evidence")
        row = _base_row("evidence_summary", resolution_label, config)
        row.update(
            {
                "prior_name": prior_name,
                "log_evidence": logz,
                "evidence": z,
                "raw_prior_normalization_constant": raw_prior_denominators[prior_name],
                "posterior_normalization_constant": z,
                "log_bayes_factor_stability_vs_prior": stability_logz - logz,
                "bf_stability_vs_prior": math.exp(stability_logz - logz),
                "log_bayes_factor_prior_vs_stability": logz - stability_logz,
                "bf_prior_vs_stability": math.exp(logz - stability_logz),
                "n_candidates_total": int(len(likelihood_df)),
                "n_observable_valid_candidates": int(likelihood_df["observable_valid"].sum()),
                "evidence_stability_reference": stability_z,
            }
        )
        rows.append(row)
    return rows


def _make_highest_likelihood_row(
    *,
    resolution_label: str,
    config: PhysicalExtensionConfig,
    likelihood_df: pd.DataFrame,
) -> dict[str, object]:
    best = _highest_likelihood(likelihood_df)
    row = _base_row("highest_likelihood", resolution_label, config)
    row.update(_candidate_fields(best))
    row.update(
        {
            "likelihood_value": _safe_exp(float(best["log_likelihood"])),
            "relative_likelihood": float(best["relative_likelihood"]),
            "highest_likelihood_index": int(best.name),
            "highest_likelihood_candidate_id": str(best["candidate_id"]),
            "highest_likelihood_lambda_ratio": float(best["lambda_ratio"]),
            "highest_likelihood_g_ratio": float(best["g_ratio"]),
        }
    )
    return row


def _make_top_posterior_rows(
    *,
    resolution_label: str,
    config: PhysicalExtensionConfig,
    posterior_df: pd.DataFrame,
    priors: dict[str, np.ndarray],
    raw_prior_denominators: dict[str, float],
    top_n: int = 20,
) -> list[dict[str, object]]:
    rows: list[dict[str, object]] = []
    for prior_name in PRIORS:
        posterior_col = f"posterior_{prior_name}"
        order = np.argsort(-posterior_df[posterior_col].to_numpy(dtype=float))[:top_n]
        for rank, idx in enumerate(order, start=1):
            cand = posterior_df.iloc[int(idx)]
            row = _base_row("top20_posterior", resolution_label, config)
            row.update(_candidate_fields(cand))
            row.update(
                {
                    "prior_name": prior_name,
                    "posterior_rank_within_prior": rank,
                    "stability_score": float(cand["stability_score"]),
                    "stability_prior_weight": float(cand["stability_prior"]),
                    "prior_weight": float(priors[prior_name][int(idx)]),
                    "raw_prior_normalization_constant": raw_prior_denominators[prior_name],
                    "log_likelihood": float(cand["log_likelihood"]),
                    "likelihood_value": _safe_exp(float(cand["log_likelihood"])),
                    "relative_likelihood": float(cand["relative_likelihood"]),
                    "posterior_weight": float(cand[posterior_col]),
                }
            )
            rows.append(row)
    return rows


def _top_candidates(posterior_df: pd.DataFrame, prior_name: str, top_n: int = 5) -> list[dict[str, object]]:
    posterior_col = f"posterior_{prior_name}"
    order = np.argsort(-posterior_df[posterior_col].to_numpy(dtype=float))[:top_n]
    out: list[dict[str, object]] = []
    for idx in order:
        row = posterior_df.iloc[int(idx)]
        out.append(
            {
                "candidate_id": str(row["candidate_id"]),
                "lambda_ratio": float(row["lambda_ratio"]),
                "g_ratio": float(row["g_ratio"]),
                "cmb_shift_residual_sigma": float(row["cmb_shift_residual_sigma"]),
                "likelihood_value": _safe_exp(float(row["log_likelihood"])),
                "stability_score": float(row["stability_score"]),
                "stability_prior": float(row["stability_prior"]),
                "posterior_weight": float(row[posterior_col]),
            }
        )
    return out


def _summarize_one(
    *,
    label: str,
    lambda_points: int,
    g_points: int,
    likelihood_df: pd.DataFrame,
    evidence_df: pd.DataFrame,
    posterior_df: pd.DataFrame,
    raw_prior_denominators: dict[str, float],
) -> dict[str, object]:
    best = _highest_likelihood(likelihood_df)
    evidence_by_prior: dict[str, dict[str, float]] = {}
    for prior_name in PRIORS:
        evidence_by_prior[prior_name] = {
            "log_evidence": _evidence_value(evidence_df, prior_name, "log_evidence"),
            "evidence": _evidence_value(evidence_df, prior_name, "evidence"),
            "raw_prior_normalization_constant": raw_prior_denominators[prior_name],
        }
    stability_logz = evidence_by_prior["stability"]["log_evidence"]
    for baseline in BASELINES:
        evidence_by_prior["stability"][f"bf_stability_vs_{PRIOR_SHORT[baseline]}"] = math.exp(
            stability_logz - evidence_by_prior[baseline]["log_evidence"]
        )
    return {
        "lambda_points": int(lambda_points),
        "g_points": int(g_points),
        "n_candidates_total": int(len(likelihood_df)),
        "n_observable_valid_candidates": int(likelihood_df["observable_valid"].sum()),
        "evidence_by_prior": evidence_by_prior,
        "highest_likelihood_candidate": {
            "candidate_index": int(best.name),
            "candidate_id": str(best["candidate_id"]),
            "lambda_index": int(best["lambda_index"]),
            "g_index": int(best["g_index"]),
            "lambda_ratio": float(best["lambda_ratio"]),
            "g_ratio": float(best["g_ratio"]),
            "omega_k_derived": float(best["omega_k_derived"]),
            "cmb_shift_R_pred": float(best["cmb_shift_R_pred"]),
            "cmb_shift_residual_sigma": float(best["cmb_shift_residual_sigma"]),
            "cmb_shift_chi2": float(best["cmb_shift_chi2"]),
            "log_likelihood": float(best["log_likelihood"]),
            "likelihood_value": _safe_exp(float(best["log_likelihood"])),
        },
        "top_stability_posterior_candidates": _top_candidates(posterior_df, "stability", 5),
        "top_jeffreys_posterior_candidates": _top_candidates(posterior_df, "jeffreys_scale_proxy", 5),
    }


def _nearest_top_candidate(candidates: list[dict[str, object]], lambda_ratio: float, g_ratio: float) -> dict[str, object]:
    return min(
        candidates,
        key=lambda c: abs(math.log(float(c["lambda_ratio"]) / lambda_ratio)) + abs(float(c["g_ratio"]) - g_ratio),
    )


def _loc(candidate: dict[str, object]) -> str:
    return (
        f"lambda={float(candidate['lambda_ratio']):.8g}, "
        f"g={float(candidate['g_ratio']):.8g}, "
        f"residual={float(candidate['cmb_shift_residual_sigma']):.6g} sigma"
    )


def build_summary(summaries: dict[str, dict[str, object]]) -> dict[str, object]:
    bf_uniform = {
        label: float(data["evidence_by_prior"]["stability"]["bf_stability_vs_uniform"])
        for label, data in summaries.items()
    }
    bf_jeffreys = {
        label: float(data["evidence_by_prior"]["stability"]["bf_stability_vs_jeffreys"])
        for label, data in summaries.items()
    }
    bf_maxent = {
        label: float(data["evidence_by_prior"]["stability"]["bf_stability_vs_maxent_log"])
        for label, data in summaries.items()
    }

    bf100 = bf_jeffreys["100x84"]
    bf200 = bf_jeffreys["200x168"]
    rel_change_100_to_200 = (bf200 - bf100) / bf100 if bf100 else math.inf
    if abs(rel_change_100_to_200) <= 0.2:
        trend = (
            f"BF stability/finite-grid scale proxy is stabilizing around the 100x84-to-200x168 regime: "
            f"{bf100:.6g} at 100x84 and {bf200:.6g} at 200x168. "
            "It is not stabilized near 52 exactly, but the change is within 20%."
        )
    elif bf200 > bf100:
        trend = (
            f"BF stability/finite-grid scale proxy is still moving upward: {bf100:.6g} at 100x84 and {bf200:.6g} at 200x168."
        )
    else:
        trend = (
            f"BF stability/finite-grid scale proxy is still moving downward: {bf100:.6g} at 100x84 and {bf200:.6g} at 200x168."
        )

    numeric_rows: dict[str, dict[str, object]] = {}
    for label, data in summaries.items():
        ev = data["evidence_by_prior"]
        best = data["highest_likelihood_candidate"]
        numeric_rows[label] = {
            "stability_evidence": ev["stability"]["evidence"],
            "jeffreys_evidence": ev["jeffreys_scale_proxy"]["evidence"],
            "uniform_evidence": ev["uniform"]["evidence"],
            "maxent_log_evidence": ev["constrained_max_entropy_log"]["evidence"],
            "stability_raw_prior_norm": ev["stability"]["raw_prior_normalization_constant"],
            "jeffreys_raw_prior_norm": ev["jeffreys_scale_proxy"]["raw_prior_normalization_constant"],
            "uniform_raw_prior_norm": ev["uniform"]["raw_prior_normalization_constant"],
            "maxent_log_raw_prior_norm": ev["constrained_max_entropy_log"]["raw_prior_normalization_constant"],
            "best_likelihood_value": best["likelihood_value"],
            "best_candidate_id": best["candidate_id"],
            "best_lambda_ratio": best["lambda_ratio"],
            "best_g_ratio": best["g_ratio"],
            "best_residual_sigma": best["cmb_shift_residual_sigma"],
        }

    top50 = summaries["50x42"]["top_stability_posterior_candidates"]
    best50 = summaries["50x42"]["highest_likelihood_candidate"]
    nearest25 = _nearest_top_candidate(
        summaries["25x21"]["top_stability_posterior_candidates"],
        float(best50["lambda_ratio"]),
        float(best50["g_ratio"]),
    )
    nearest100 = _nearest_top_candidate(
        summaries["100x84"]["top_stability_posterior_candidates"],
        float(best50["lambda_ratio"]),
        float(best50["g_ratio"]),
    )
    nearest200 = _nearest_top_candidate(
        summaries["200x168"]["top_stability_posterior_candidates"],
        float(best50["lambda_ratio"]),
        float(best50["g_ratio"]),
    )
    cluster_mass_50_top3 = sum(float(c["posterior_weight"]) for c in top50[:3])
    cluster_text = (
        "The 50x42 result is driven by a narrow coordinate cluster. "
        f"The top three stability-posterior cells at 50x42 carry {cluster_mass_50_top3:.6g} posterior mass: "
        + "; ".join(_loc(c) for c in top50[:3])
        + ". The nearest top-posterior analogues are "
        + f"25x21: {_loc(nearest25)}; 100x84: {_loc(nearest100)}; 200x168: {_loc(nearest200)}."
    )

    if abs(rel_change_100_to_200) <= 0.2:
        origin = (
            "The 200x168 run shows that the 50x42 value was too high, but the elevated BF does not disappear. "
            "The source is the overlap between the stability prior and a narrow CMB shift-parameter likelihood ridge. "
            "The maximum likelihood remains close to one at all fine grids, so the movement is not caused by a new likelihood ceiling. "
            "It is caused by how finite-grid prior mass lands on the high-likelihood ridge relative to the finite-grid scale proxy normalization."
        )
    else:
        origin = (
            "The 200x168 run still changes materially from 100x84. The result remains resolution-sensitive. "
            "The movement is dominated by prior-likelihood overlap and finite-grid normalization along a narrow likelihood ridge, not by a new likelihood maximum."
        )

    return {
        "diagnostic_extension": "resolution_convergence",
        "resolutions": summaries,
        "bayes_factor_series": {
            "stability_vs_uniform": bf_uniform,
            "stability_vs_jeffreys_scale_proxy": bf_jeffreys,
            "stability_vs_constrained_max_entropy_log": bf_maxent,
        },
        "plain_language_answers": {
            "q1_200x168_behavior": trend,
            "q2_divergence_origin": origin,
            "q3_specific_candidate_or_cluster": cluster_text,
        },
        "numeric_diagnosis": {"resolution_numeric_rows": numeric_rows},
        "relative_change_100x84_to_200x168_jeffreys": rel_change_100_to_200,
        "interpretation_boundary": (
            "This is a finite-grid diagnostic inside the compressed CMB shift-parameter approximation. "
            "It is not a substitute for a full cosmological likelihood analysis."
        ),
    }


def write_report(summary: dict[str, object], docs_dir: Path) -> None:
    docs_dir.mkdir(parents=True, exist_ok=True)
    answers = summary["plain_language_answers"]
    numeric = summary["numeric_diagnosis"]["resolution_numeric_rows"]
    bf = summary["bayes_factor_series"]
    labels = ["13x11", "25x21", "50x42", "100x84", "200x168"]

    lines = [
        "# Resolution Convergence",
        "",
        "This report records the finite-grid behavior of the physical Lambda/G evidence calculation after adding the 200x168 grid.",
        "",
        "## 1. 200x168 behavior",
        "",
        str(answers["q1_200x168_behavior"]),
        "",
        "Bayes factor series, stability prior divided by baseline:",
        "",
        "| Grid | Uniform | finite-grid scale proxy | Max-ent log |",
        "|---:|---:|---:|---:|",
    ]
    for label in labels:
        lines.append(
            f"| {label} | {bf['stability_vs_uniform'][label]:.12g} | "
            f"{bf['stability_vs_jeffreys_scale_proxy'][label]:.12g} | "
            f"{bf['stability_vs_constrained_max_entropy_log'][label]:.12g} |"
        )
    lines.extend(
        [
            "",
            "## 2. Source of the divergence",
            "",
            str(answers["q2_divergence_origin"]),
            "",
            "Key numeric diagnostics:",
            "",
            "| Grid | Z_stability | Z_scale_proxy | Z_uniform | Z_maxent | Raw norm stability | Raw norm scale proxy | Best likelihood | Best lambda | Best g | Residual sigma |",
            "|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for label in labels:
        r = numeric[label]
        lines.append(
            f"| {label} | {r['stability_evidence']:.12g} | {r['jeffreys_evidence']:.12g} | "
            f"{r['uniform_evidence']:.12g} | {r['maxent_log_evidence']:.12g} | "
            f"{r['stability_raw_prior_norm']:.12g} | {r['jeffreys_raw_prior_norm']:.12g} | "
            f"{r['best_likelihood_value']:.12g} | {r['best_lambda_ratio']:.12g} | "
            f"{r['best_g_ratio']:.12g} | {r['best_residual_sigma']:.12g} |"
        )
    lines.extend(
        [
            "",
            "## 3. Candidate cluster",
            "",
            str(answers["q3_specific_candidate_or_cluster"]),
            "",
            "Interpretation boundary: the diagnostic identifies numerical behavior in the declared grid and compressed CMB shift-parameter likelihood. A full cosmological analysis would require the full parameter vector, covariance structure, and a Boltzmann-code likelihood workflow.",
        ]
    )
    (docs_dir / "resolution_convergence.md").write_text("\n".join(lines) + "\n", encoding="utf-8")


def run(base_config: PhysicalExtensionConfig | None = None) -> dict[str, object]:
    base = (base_config or PhysicalExtensionConfig()).validate()
    results_dir = Path(base.results_dir)
    docs_dir = Path("docs")
    results_dir.mkdir(parents=True, exist_ok=True)

    all_rows: list[dict[str, object]] = []
    summaries: dict[str, dict[str, object]] = {}
    for lambda_points, g_points in RESOLUTIONS:
        config = PhysicalExtensionConfig(**{**asdict(base), "lambda_points": lambda_points, "g_points": g_points}).validate()
        label = f"{lambda_points}x{g_points}"
        likelihood_df, evidence_df, posterior_df, priors, raw_prior_denominators = _run_pipeline(config)
        all_rows.extend(
            _make_evidence_rows(
                resolution_label=label,
                config=config,
                likelihood_df=likelihood_df,
                evidence_df=evidence_df,
                raw_prior_denominators=raw_prior_denominators,
            )
        )
        all_rows.append(_make_highest_likelihood_row(resolution_label=label, config=config, likelihood_df=likelihood_df))
        all_rows.extend(
            _make_top_posterior_rows(
                resolution_label=label,
                config=config,
                posterior_df=posterior_df,
                priors=priors,
                raw_prior_denominators=raw_prior_denominators,
            )
        )
        summaries[label] = _summarize_one(
            label=label,
            lambda_points=lambda_points,
            g_points=g_points,
            likelihood_df=likelihood_df,
            evidence_df=evidence_df,
            posterior_df=posterior_df,
            raw_prior_denominators=raw_prior_denominators,
        )

    debug_df = pd.DataFrame(all_rows)
    summary = build_summary(summaries)
    debug_df.to_csv(results_dir / "resolution_debug.csv", index=False)
    (results_dir / "resolution_debug_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    write_report(summary, docs_dir)
    return summary


def main(argv: Iterable[str] | None = None) -> None:
    parser = argparse.ArgumentParser(description="Run resolution-convergence diagnostics.")
    parser.add_argument("--results-dir", default="results/physical_extension")
    parser.add_argument("--figures-dir", default="figures/physical_extension")
    parser.add_argument("--integration-steps", type=int, default=4096)
    parser.add_argument("--eta", type=float, default=8.0)
    args = parser.parse_args(list(argv) if argv is not None else None)
    config = PhysicalExtensionConfig(
        results_dir=args.results_dir,
        figures_dir=args.figures_dir,
        integration_steps=args.integration_steps,
        stability_eta=args.eta,
    )
    print(json.dumps(run(config), indent=2))


if __name__ == "__main__":
    main()
